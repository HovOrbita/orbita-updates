@echo off
cd /d "%~dp0"
if exist "electron\electron.exe" (start "" "electron\electron.exe" "%~dp0.") else (start "" "node_modules\electron\dist\electron.exe" "%~dp0.")
