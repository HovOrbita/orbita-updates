'use strict';
// Подключение счетов бирж — ТОЛЬКО ЧТЕНИЕ.
// Здесь нет ни одной функции, которая может открыть, изменить или закрыть сделку или вывести деньги:
// модуль делает исключительно GET-запросы (позиции и открытые ордера).
// Ключи хранятся зашифрованными средствами Windows (safeStorage) и никогда не передаются в окно программы.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const EX = {
  binance: { name: 'Binance', base: 'https://fapi.binance.com' },
  bybit: { name: 'Bybit', base: 'https://api.bybit.com' },
  gate: { name: 'Gate', base: 'https://api.gateio.ws' },
};

function register({ ipcMain, app, net, safeStorage }) {
  const file = () => path.join(app.getPath('userData'), 'accounts.dat');
  let keys = null; // { binance: { key, secret }, ... } — только в памяти главного процесса
  const offset = { binance: 0, bybit: 0 }; // разница часов с биржей, мс

  function load() {
    if (keys) return keys;
    keys = {};
    try {
      const buf = fs.readFileSync(file());
      if (safeStorage.isEncryptionAvailable()) keys = JSON.parse(safeStorage.decryptString(buf)) || {};
    } catch { keys = {}; }
    return keys;
  }
  function persist() {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Шифрование Windows недоступно — ключи не сохранены');
    fs.writeFileSync(file(), safeStorage.encryptString(JSON.stringify(keys)));
  }
  const mask = k => (k ? k.slice(0, 4) + '…' + k.slice(-4) : '');

  async function getJSON(url, headers = {}) {
    const r = await net.fetch(url, { method: 'GET', headers, signal: AbortSignal.timeout(12000) });
    const text = await r.text();
    let data; try { data = JSON.parse(text); } catch { data = { raw: text.slice(0, 300) }; }
    return { status: r.status, ok: r.ok, data };
  }
  const hmac = (alg, secret, msg) => crypto.createHmac(alg, secret).update(msg).digest('hex');

  // ---------- подписанные GET-запросы ----------
  async function syncTime(ex) {
    try {
      if (ex === 'binance') { const r = await getJSON(EX.binance.base + '/fapi/v1/time'); if (r.data.serverTime) offset.binance = r.data.serverTime - Date.now(); }
      if (ex === 'bybit') { const r = await getJSON(EX.bybit.base + '/v5/market/time'); const t = r.data && r.data.result && +r.data.result.timeSecond; if (t) offset.bybit = t * 1000 - Date.now(); }
    } catch { /* остаёмся с локальным временем */ }
  }
  function binanceErr(d, status) {
    const c = d && d.code, m = d && d.msg;
    if (c === -2015 || c === -2014 || c === -1022) return 'Ключ не подходит: неверный ключ, IP не в белом списке или не включено чтение фьючерсов';
    if (c === -1021) return 'Время компьютера расходится с биржей — синхронизируйте часы Windows';
    return m ? `Binance: ${m}` : `Binance: ошибка ${status}`;
  }
  async function binanceGet(k, p, params = {}, base = EX.binance.base) {
    const q = new URLSearchParams({ ...params, recvWindow: '10000', timestamp: String(Date.now() + offset.binance) }).toString();
    const sig = hmac('sha256', k.secret, q);
    const r = await getJSON(`${base}${p}?${q}&signature=${sig}`, { 'X-MBX-APIKEY': k.key });
    if (!r.ok || (r.data && r.data.code && r.data.code < 0)) throw new Error(binanceErr(r.data, r.status));
    return r.data;
  }
  async function bybitGet(k, p, params = {}) {
    const q = new URLSearchParams(params).toString(), ts = String(Date.now() + offset.bybit), rw = '10000';
    const sig = hmac('sha256', k.secret, ts + k.key + rw + q);
    const r = await getJSON(`${EX.bybit.base}${p}?${q}`, { 'X-BAPI-API-KEY': k.key, 'X-BAPI-TIMESTAMP': ts, 'X-BAPI-SIGN': sig, 'X-BAPI-RECV-WINDOW': rw });
    const d = r.data || {};
    if (d.retCode !== 0) {
      const c = d.retCode;
      if (c === 10003 || c === 10004 || c === 33004) throw new Error('Ключ не подходит: неверный ключ/секрет или срок ключа истёк');
      if (c === 10002) throw new Error('Время компьютера расходится с биржей — синхронизируйте часы Windows');
      if (c === 10010) throw new Error('IP этого компьютера не в белом списке ключа');
      throw new Error(`Bybit: ${d.retMsg || 'ошибка ' + r.status}`);
    }
    return d.result;
  }
  async function gateGet(k, p, params = {}) {
    const q = new URLSearchParams(params).toString(), ts = String(Math.floor(Date.now() / 1000));
    const bodyHash = crypto.createHash('sha512').update('').digest('hex');
    const sig = hmac('sha512', k.secret, `GET\n/api/v4${p}\n${q}\n${bodyHash}\n${ts}`);
    const r = await getJSON(`${EX.gate.base}/api/v4${p}${q ? '?' + q : ''}`, { KEY: k.key, SIGN: sig, Timestamp: ts, Accept: 'application/json' });
    if (!r.ok) {
      const lab = r.data && r.data.label;
      if (lab === 'INVALID_KEY' || lab === 'INVALID_SIGNATURE' || lab === 'MISSING_REQUIRED_HEADER') throw new Error('Ключ не подходит: неверный ключ или секрет');
      if (lab === 'FORBIDDEN' || lab === 'IP_FORBIDDEN') throw new Error('Нет доступа: IP не в белом списке или нет права читать фьючерсы');
      if (lab === 'REQUEST_EXPIRED') throw new Error('Время компьютера расходится с биржей — синхронизируйте часы Windows');
      throw new Error(`Gate: ${(r.data && (r.data.message || r.data.label)) || 'ошибка ' + r.status}`);
    }
    return r.data;
  }

  // ---------- приведение к общему виду ----------
  // позиция: { sym, id, side:'long'|'short', qty, entry, mark, upnl, notional, lev, liq, tp, sl, openTime }
  // ордер:   { sym, id, side:'buy'|'sell', kind:'limit'|'cond', price, trigger, qty, reduce, tpsl:'tp'|'sl'|'' }
  const num = v => { const n = parseFloat(v); return isFinite(n) ? n : 0; };

  async function fetchBinance(k, withOrders) {
    const pos = await binanceGet(k, '/fapi/v3/positionRisk');
    const positions = (Array.isArray(pos) ? pos : []).filter(p => num(p.positionAmt) !== 0).map(p => {
      const amt = num(p.positionAmt), side = p.positionSide === 'SHORT' || (p.positionSide !== 'LONG' && amt < 0) ? 'short' : 'long';
      return { sym: p.symbol, id: 'BINANCEF:' + p.symbol, side, pside: p.positionSide, qty: Math.abs(amt), entry: num(p.entryPrice), mark: num(p.markPrice), upnl: num(p.unRealizedProfit),
        notional: Math.abs(num(p.notional)) || Math.abs(amt) * num(p.markPrice), lev: num(p.leverage) || 0, liq: num(p.liquidationPrice), tp: 0, sl: 0, openTime: num(p.updateTime) };
    });
    let orders = null;
    if (withOrders) {
      orders = [];
      const oo = await binanceGet(k, '/fapi/v1/openOrders');
      for (const o of Array.isArray(oo) ? oo : []) {
        const cond = /STOP|TAKE_PROFIT/.test(o.type || '');
        orders.push({ sym: o.symbol, id: 'BINANCEF:' + o.symbol, side: (o.side || '').toLowerCase(), kind: cond ? 'cond' : 'limit', price: num(o.price), trigger: num(o.stopPrice),
          qty: num(o.origQty) - num(o.executedQty), reduce: !!(o.reduceOnly || o.closePosition), pside: o.positionSide, tpsl: /TAKE_PROFIT/.test(o.type || '') ? 'tp' : /STOP/.test(o.type || '') ? 'sl' : '' });
      }
      // тейки и стопы с декабря 2025 живут в Algo Service
      try {
        const ao = await binanceGet(k, '/fapi/v1/openAlgoOrders');
        const list = Array.isArray(ao) ? ao : (ao && (ao.orders || ao.rows)) || [];
        for (const o of list) {
          const t = o.orderType || o.type || o.algoOrderType || '';
          orders.push({ sym: o.symbol, id: 'BINANCEF:' + o.symbol, side: (o.side || '').toLowerCase(), kind: 'cond', price: num(o.price), trigger: num(o.triggerPrice || o.stopPrice),
            qty: num(o.quantity || o.totalQty || o.origQty), reduce: !!(o.reduceOnly || o.closePosition), pside: o.positionSide, tpsl: /TAKE_PROFIT/.test(t) ? 'tp' : /STOP/.test(t) ? 'sl' : '' });
        }
      } catch { /* старые аккаунты — условные ордера уже есть в openOrders */ }
    }
    return { positions, orders };
  }

  async function fetchBybit(k, withOrders) {
    const r = await bybitGet(k, '/v5/position/list', { category: 'linear', settleCoin: 'USDT', limit: '200' });
    const positions = ((r && r.list) || []).filter(p => num(p.size) > 0).map(p => ({
      sym: p.symbol, id: 'BYBITF:' + p.symbol, side: p.side === 'Sell' ? 'short' : 'long', qty: num(p.size), entry: num(p.avgPrice), mark: num(p.markPrice),
      upnl: num(p.unrealisedPnl), notional: num(p.positionValue) || num(p.size) * num(p.markPrice), lev: num(p.leverage), liq: num(p.liqPrice),
      tp: num(p.takeProfit), sl: num(p.stopLoss), openTime: num(p.createdTime) }));
    let orders = null;
    if (withOrders) {
      const o = await bybitGet(k, '/v5/order/realtime', { category: 'linear', settleCoin: 'USDT', limit: '50' });
      orders = ((o && o.list) || []).map(x => {
        const st = x.stopOrderType || '', cond = num(x.triggerPrice) > 0 || !!st;
        return { sym: x.symbol, id: 'BYBITF:' + x.symbol, side: (x.side || '').toLowerCase(), kind: cond ? 'cond' : 'limit', price: num(x.price), trigger: num(x.triggerPrice),
          qty: num(x.leavesQty || x.qty), reduce: !!(x.reduceOnly || x.closeOnTrigger), tpsl: /TakeProfit/i.test(st) ? 'tp' : /StopLoss|Stop/i.test(st) ? 'sl' : '' };
      });
    }
    return { positions, orders };
  }

  const gateMult = new Map(); // размер контракта Gate (сколько монет в одном контракте)
  async function gateMultiplier(c) {
    if (gateMult.has(c)) return gateMult.get(c);
    try { const r = await getJSON(`${EX.gate.base}/api/v4/futures/usdt/contracts/${encodeURIComponent(c)}`); const m = num(r.data && r.data.quanto_multiplier) || 1; gateMult.set(c, m); return m; }
    catch { return 1; }
  }
  async function fetchGate(k, withOrders) {
    const pos = await gateGet(k, '/futures/usdt/positions', { holding: 'true' });
    const positions = [];
    for (const p of Array.isArray(pos) ? pos : []) {
      const size = num(p.size); if (!size) continue;
      const m = await gateMultiplier(p.contract);
      positions.push({ sym: p.contract, id: 'GATEF:' + p.contract, side: size < 0 || p.mode === 'dual_short' ? 'short' : 'long', qty: Math.abs(size) * m,
        entry: num(p.entry_price), mark: num(p.mark_price), upnl: num(p.unrealised_pnl), notional: Math.abs(num(p.value)) || Math.abs(size) * m * num(p.mark_price),
        lev: num(p.leverage) || num(p.cross_leverage_limit), liq: num(p.liq_price), tp: 0, sl: 0, openTime: num(p.open_time) * 1000 });
    }
    let orders = null;
    if (withOrders) {
      orders = [];
      const oo = await gateGet(k, '/futures/usdt/orders', { status: 'open' });
      for (const o of Array.isArray(oo) ? oo : []) {
        const m = await gateMultiplier(o.contract), sz = num(o.left || o.size);
        orders.push({ sym: o.contract, id: 'GATEF:' + o.contract, side: num(o.size) < 0 ? 'sell' : 'buy', kind: 'limit', price: num(o.price), trigger: 0, qty: Math.abs(sz) * m, reduce: !!(o.is_reduce_only || o.is_close), tpsl: '' });
      }
      try {
        const po = await gateGet(k, '/futures/usdt/price_orders', { status: 'open' });
        for (const o of Array.isArray(po) ? po : []) {
          const ini = o.initial || {}, trg = o.trigger || {}, m = await gateMultiplier(ini.contract), sz = num(ini.size);
          const ot = o.order_type || '', as = ini.auto_size || '';
          // направление: размер со знаком, тип ордера (close-long / close-short) или auto_size; «закрыть всю позицию» (size 0) — неизвестно, привяжем к позиции
          const side = sz < 0 || /close-long|close_long/.test(ot + ' ' + as) ? 'sell' : sz > 0 || /close-short|close_short/.test(ot + ' ' + as) ? 'buy' : '';
          // тейк или стоп: Gate подсказывает через rule (1: цена ≥ триггера, 2: ≤) и тип ордера
          const rule = num(trg.rule);
          const tpsl = /profit/i.test(ot) ? 'tp' : /loss/i.test(ot) ? 'sl' : (side && rule) ? ((side === 'sell') === (rule === 1) ? 'tp' : 'sl') : '';
          orders.push({ sym: ini.contract, id: 'GATEF:' + ini.contract, side, kind: 'cond', price: num(ini.price), trigger: num(trg.price),
            qty: Math.abs(sz) * m, reduce: !!(ini.is_reduce_only || ini.is_close || /close/.test(ot)), tpsl });
        }
      } catch { /* нет условных ордеров */ }
    }
    return { positions, orders };
  }

  const FETCH = { binance: fetchBinance, bybit: fetchBybit, gate: fetchGate };

  // точное время открытия позиции: идём по истории ваших сделок от новых к старым,
  // пока не «соберём» текущий размер позиции — сделка, с которой он начался, и есть открытие
  async function openTime(ex, k, p) {
    const S = p.qty * (p.side === 'long' ? 1 : -1), eps = Math.max(p.qty * 1e-6, 1e-12);
    let trades = [];
    if (ex === 'binance') {
      const r = await binanceGet(k, '/fapi/v1/userTrades', { symbol: p.sym, limit: '1000' });
      trades = (Array.isArray(r) ? r : []).filter(t => !p.pside || p.pside === 'BOTH' || t.positionSide === p.pside)
        .map(t => ({ t: num(t.time), q: (t.side === 'BUY' ? 1 : -1) * num(t.qty) }));
    } else if (ex === 'bybit') {
      const r = await bybitGet(k, '/v5/execution/list', { category: 'linear', symbol: p.sym, limit: '100' });
      trades = ((r && r.list) || []).filter(t => !t.execType || t.execType === 'Trade')
        .map(t => ({ t: num(t.execTime), q: (t.side === 'Buy' ? 1 : -1) * num(t.execQty) }));
    } else if (ex === 'gate') {
      const m = await gateMultiplier(p.sym);
      const r = await gateGet(k, '/futures/usdt/my_trades', { contract: p.sym, limit: '500' });
      trades = (Array.isArray(r) ? r : []).map(t => ({ t: Math.round(num(t.create_time) * 1000), q: num(t.size) * m }));
    }
    trades = trades.filter(t => t.t > 0 && t.q).sort((a, b) => b.t - a.t);
    let cum = S, t0 = 0;
    for (const tr of trades) {
      cum -= tr.q; t0 = tr.t;
      if (Math.abs(cum) <= eps || Math.sign(cum) !== Math.sign(S)) return t0;
    }
    return trades.length ? t0 : 0; // история короче позиции — берём самую раннюю известную сделку
  }

  // проверка прав ключа: предупредить, если у ключа есть право торговли или вывода
  async function checkPerms(ex, k) {
    try {
      if (ex === 'binance') {
        const r = await binanceGet(k, '/sapi/v1/account/apiRestrictions', {}, 'https://api.binance.com');
        const risky = [];
        if (r.enableWithdrawals) risky.push('вывод средств');
        if (r.enableFutures) risky.push('торговля фьючерсами');
        if (r.enableSpotAndMarginTrading) risky.push('торговля на споте');
        if (r.enableInternalTransfer || r.permitsUniversalTransfer) risky.push('переводы');
        return risky;
      }
      if (ex === 'bybit') {
        const r = await bybitGet(k, '/v5/user/query-api');
        return r && +r.readOnly === 1 ? [] : ['торговля (ключ не «только чтение»)'];
      }
    } catch { /* не удалось проверить — не страшно */ }
    return null; // для Gate проверки прав через API нет
  }

  // ---------- связь с окном программы (секрет наружу не выходит) ----------
  ipcMain.handle('acct-list', () => {
    const k = load();
    return Object.keys(EX).map(ex => ({ ex, name: EX[ex].name, connected: !!(k[ex] && k[ex].key), key: mask(k[ex] && k[ex].key), canSave: safeStorage.isEncryptionAvailable() }));
  });
  ipcMain.handle('acct-save', async (_e, ex, key, secret) => {
    if (!EX[ex]) return { ok: false, error: 'Неизвестная биржа' };
    key = String(key || '').trim(); secret = String(secret || '').trim();
    if (key.length < 8 || secret.length < 8) return { ok: false, error: 'Вставьте API Key и Secret полностью' };
    if (!safeStorage.isEncryptionAvailable()) return { ok: false, error: 'Шифрование Windows недоступно — не могу безопасно сохранить ключ' };
    const k = { key, secret };
    await syncTime(ex);
    try { await FETCH[ex](k, false); } catch (e) { return { ok: false, error: e.message }; }
    const risky = await checkPerms(ex, k);
    load()[ex] = k;
    try { persist(); } catch (e) { return { ok: false, error: e.message }; }
    return { ok: true, key: mask(key), risky };
  });
  ipcMain.handle('acct-del', (_e, ex) => { load(); delete keys[ex]; try { persist(); } catch { /* */ } return { ok: true }; });
  ipcMain.handle('acct-opentime', async (_e, ex, p) => {
    const k = load()[ex]; if (!k || !p) return { ok: false };
    try { return { ok: true, t: await openTime(ex, k, p) }; } catch (e) { return { ok: false, error: e.message }; }
  });
  ipcMain.handle('acct-fetch', async (_e, ex, withOrders) => {
    const k = load()[ex]; if (!k) return { ok: false, error: 'не подключено' };
    try {
      if (ex !== 'gate' && !offset['_' + ex]) { await syncTime(ex); offset['_' + ex] = 1; setTimeout(() => { offset['_' + ex] = 0; }, 10 * 60 * 1000).unref(); }
      const r = await FETCH[ex](k, !!withOrders);
      return { ok: true, ...r, t: Date.now() };
    } catch (e) { return { ok: false, error: e.message || String(e) }; }
  });

  return { _test: { hmac, fetchBinance, fetchBybit, fetchGate } };
}

module.exports = { register, EX };
