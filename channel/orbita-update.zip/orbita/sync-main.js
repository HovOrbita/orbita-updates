'use strict';
// Синхронизация через облачную папку (OneDrive / Google Диск / Dropbox).
// Каждый компьютер работает сам по себе (основной может быть выключен), а рисунки, списки наблюдения,
// оповещения и настройки сходятся через файл в облачной папке. Ключи бирж туда НЕ попадают (они в accounts.dat).
// Рисунки и оповещения сливаются по id: новое с обоих компьютеров сохраняется, удалённое — удаляется.
const fs = require('fs'), path = require('path'), os = require('os');

const KEEP_DEL = 60 * 864e5; // помним удалённые рисунки 60 дней

function meta(s) { const m = s && s._sync; return { mod: (m && m.mod) || {}, del: (m && m.del) || {} }; }
function maxMap(a, b) { const o = { ...a }; for (const [k, v] of Object.entries(b)) if (!(o[k] >= v)) o[k] = v; return o; }

// слить списки с id: A — «главная» сторона (новее), B — другая
function mergeList(la, lb, ma, mb) {
  la = Array.isArray(la) ? la : []; lb = Array.isArray(lb) ? lb : [];
  const ia = new Map(la.filter(d => d && d.id).map(d => [d.id, d])), ib = new Map(lb.filter(d => d && d.id).map(d => [d.id, d]));
  const out = [];
  for (const d of la) {
    if (!d || !d.id) { out.push(d); continue; }
    const e = ib.get(d.id);
    if (e) out.push((mb.mod[d.id] || 0) > (ma.mod[d.id] || 0) ? e : d);
    else if (!((mb.del[d.id] || 0) > (ma.mod[d.id] || 0))) out.push(d); // на другом компьютере не удаляли после нашего изменения
  }
  for (const d of lb) {
    if (!d || !d.id || ia.has(d.id)) continue;
    if (!((ma.del[d.id] || 0) > (mb.mod[d.id] || 0))) out.push(d);
  }
  return out;
}

function merge(A, B) {
  if (!B) return A; if (!A) return B;
  const ma = meta(A), mb = meta(B), out = { ...A };
  const da = A.drawings || {}, db = B.drawings || {};
  out.drawings = {};
  for (const k of new Set([...Object.keys(da), ...Object.keys(db)])) {
    const l = mergeList(da[k], db[k], ma, mb);
    if (l.length) out.drawings[k] = l;
  }
  out.alerts = mergeList(A.alerts, B.alerts, ma, mb);
  const now = Date.now(), mod = maxMap(ma.mod, mb.mod), del = maxMap(ma.del, mb.del);
  for (const [k, t] of Object.entries(del)) if (now - t > KEEP_DEL) delete del[k];
  out._sync = { mod, del };
  out.savedAt = Math.max(A.savedAt || 0, B.savedAt || 0);
  return out;
}

const items = s => {
  const m = new Map();
  for (const arr of Object.values((s && s.drawings) || {})) if (Array.isArray(arr)) for (const d of arr) if (d && d.id) m.set(d.id, JSON.stringify(d));
  for (const a of (s && Array.isArray(s.alerts) ? s.alerts : [])) if (a && a.id) m.set(a.id, JSON.stringify(a));
  return m;
};
// где лежит каждый рисунок/оповещение: id → { k (символ или 'alerts'), d, h }
function locate(s) {
  const m = new Map();
  for (const [k, arr] of Object.entries((s && s.drawings) || {})) if (Array.isArray(arr)) for (const d of arr) if (d && d.id) m.set(d.id, { k, d, h: JSON.stringify(d) });
  for (const a of (s && Array.isArray(s.alerts) ? s.alerts : [])) if (a && a.id) m.set(a.id, { k: 'alerts', d: a, h: JSON.stringify(a) });
  return m;
}
const listOf = (s, k) => k === 'alerts' ? (s.alerts || (s.alerts = [])) : ((s.drawings || (s.drawings = {}))[k] || (s.drawings[k] = []));
const sameItems = (a, b) => { const x = items(a), y = items(b); if (x.size !== y.size) return false; for (const [k, v] of x) if (y.get(k) !== v) return false; return true; };

function register({ ipcMain, app, dialog, BrowserWindow, stateFile, notify }) {
  const cfgFile = () => path.join(app.getPath('userData'), 'sync.json');
  let cfg = null;
  try { cfg = JSON.parse(fs.readFileSync(cfgFile(), 'utf8')); if (!cfg || !cfg.dir) cfg = null; } catch { cfg = null; }
  const host = os.hostname();
  const dir = () => cfg && path.join(cfg.dir, 'Orbita-sync');
  const rfile = () => cfg && path.join(dir(), 'orbita-state.json');
  let meta0 = { mod: {}, del: {} }, prev = new Map(), seenMtime = 0, lastPush = 0, lastPull = 0, err = '', pushT = null, pulled = null;

  const readJSON = f => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
  const readLocal = () => readJSON(stateFile()) || readJSON(stateFile() + '.bak');
  function writeLocal(s) {
    const f = stateFile(), tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(s), 'utf8');
    try { fs.copyFileSync(f, f + '.bak'); } catch { /* первого файла ещё нет */ }
    fs.renameSync(tmp, f);
  }
  function remember(s) { meta0 = meta(s); meta0 = { mod: { ...meta0.mod }, del: { ...meta0.del } }; prev = items(s); }

  // файл в облаке + копии-конфликты, которые облако создаёт, если оба компьютера сохранили одновременно
  function readRemote() {
    if (!cfg) return { s: null, mtime: 0, extra: [] };
    let s = null, mtime = 0;
    try { mtime = fs.statSync(rfile()).mtimeMs; s = readJSON(rfile()); } catch { /* ещё нет */ }
    const extra = [];
    try {
      for (const n of fs.readdirSync(dir())) if (/^orbita-state.+\.json$/i.test(n) && n !== 'orbita-state.json') extra.push(path.join(dir(), n));
    } catch { /* */ }
    return { s, mtime, extra };
  }
  function pullInto(local) {
    const r = readRemote(); let s = local;
    if (r.s) s = (r.s.savedAt || 0) > (s && s.savedAt || 0) ? merge(r.s, s) : merge(s, r.s);
    for (const f of r.extra) { const x = readJSON(f); if (x) { s = (x.savedAt || 0) > (s.savedAt || 0) ? merge(x, s) : merge(s, x); try { fs.unlinkSync(f); } catch { /* */ } } }
    if (r.s) seenMtime = r.mtime;
    return { s, had: !!r.s, extra: r.extra.length };
  }
  function push() {
    pushT = null;
    if (!cfg) return;
    if (metaT || pendingJson) { pushT = setTimeout(push, 1000); return; }
    try {
      fs.mkdirSync(dir(), { recursive: true });
      let L = readLocal(); if (!L) return;
      const r = readRemote();
      if ((r.s && r.mtime !== seenMtime) || r.extra.length) { // в облаке есть новое — сначала забираем
        const p = pullInto(L);
        if (JSON.stringify(p.s) !== JSON.stringify(L)) { pulled = { at: Date.now(), pre: new Map(prev), state: p.s }; writeLocal(p.s); remember(p.s); L = p.s; lastPull = Date.now(); notify(); }
      }
      const tmp = rfile() + '.' + host + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(L), 'utf8');
      fs.renameSync(tmp, rfile());
      seenMtime = fs.statSync(rfile()).mtimeMs; lastPush = Date.now(); err = '';
    } catch (e) { err = String(e.message || e); }
  }
  const schedulePush = () => { if (cfg && !pushT) pushT = setTimeout(push, 2500); };

  function poll() {
    if (!cfg) return;
    try { fs.accessSync(cfg.dir); } catch (e) { err = 'Нет доступа к облачной папке: ' + (e.code || e.message); return; }
    const r = readRemote();
    if (!((r.s && r.mtime !== seenMtime) || r.extra.length)) return;
    const L = readLocal() || {};
    const p = pullInto(L);
    if (JSON.stringify(p.s) !== JSON.stringify(L)) { pulled = { at: Date.now(), pre: new Map(prev), state: p.s }; writeLocal(p.s); remember(p.s); lastPull = Date.now(); notify(); }
    if (p.extra) schedulePush();
  }
  setInterval(poll, 3000);
  const beat = () => { if (cfg) try { fs.mkdirSync(dir(), { recursive: true }); fs.writeFileSync(path.join(dir(), `online-${host.replace(/[^\w.-]/g, '_')}.json`), JSON.stringify({ host, t: Date.now() })); } catch { /* */ } };
  setInterval(beat, 60e3); setTimeout(beat, 3000);

  // ---- то, что вызывает main.js вместо прежнего state-load / state-save ----
  function load() {
    let L = readLocal();
    if (cfg) { try { const p = pullInto(L || null); if (p.s && JSON.stringify(p.s) !== JSON.stringify(L)) { writeLocal(p.s); L = p.s; } } catch (e) { err = String(e.message || e); } }
    remember(L || {});
    return L ? JSON.stringify(L) : null;
  }
  // Сохранение должно быть мгновенным: окно ждёт ответа. Пишем как есть, а метки для облака считаем потом, в фоне.
  let pendingJson = null, metaT = null;
  function writeRaw(json) {
    const f = stateFile(), tmp = f + '.tmp';
    fs.writeFileSync(tmp, json, 'utf8');
    try { fs.copyFileSync(f, f + '.bak'); } catch { /* первого файла ещё нет */ }
    fs.renameSync(tmp, f);
  }
  function save(json) {
    if (typeof json !== 'string' || json.length > 200e6) throw new Error('bad state');
    if (json.charCodeAt(0) !== 123) throw new Error('bad state');
    writeRaw(json);
    if (!cfg) return true; // облако не подключено — как раньше, без лишней работы
    pendingJson = json;
    if (!metaT) metaT = setTimeout(() => { metaT = null; const j = pendingJson; pendingJson = null; try { saveMeta(j); } catch (e) { err = String(e.message || e); } }, 800);
    return true;
  }
  function saveMeta(json) {
    const s = JSON.parse(json), now = Date.now();
    // окно ещё не успело подтянуть то, что пришло из облака секунду назад, — не затираем пришедшее старой копией
    if (pulled && now - pulled.at < 5000) {
      const inc = locate(s), pm = locate(pulled.state);
      for (const [id, x] of pm) {
        const i = inc.get(id);
        if (!i) { if (!pulled.pre.has(id)) listOf(s, x.k).push(x.d); }
        else if (i.h === pulled.pre.get(id) && i.h !== x.h) { const l = listOf(s, i.k), j = l.indexOf(i.d); if (j >= 0) l.splice(j, 1); listOf(s, x.k).push(x.d); }
      }
      for (const [id, h] of pulled.pre) if (!pm.has(id)) { const i = inc.get(id); if (i && i.h === h) { const l = listOf(s, i.k), j = l.indexOf(i.d); if (j >= 0) l.splice(j, 1); } }
    }
    const cur = items(s);
    for (const [id, h] of cur) if (prev.get(id) !== h) meta0.mod[id] = now;
    for (const id of prev.keys()) if (!cur.has(id)) meta0.del[id] = now;
    for (const id of Object.keys(meta0.mod)) if (!cur.has(id) && now - meta0.mod[id] > KEEP_DEL) delete meta0.mod[id];
    for (const [id, t] of Object.entries(meta0.del)) if (now - t > KEEP_DEL || cur.has(id)) delete meta0.del[id];
    s._sync = { mod: meta0.mod, del: meta0.del };
    prev = cur;
    if (!pendingJson) writeLocal(s); // если за это время пришло новое сохранение — метки посчитаются на нём
    schedulePush();
  }

  function suggestions() {
    const out = [], add = (name, p) => { try { if (p && fs.statSync(p).isDirectory() && !out.some(x => x.dir === p)) out.push({ name, dir: p }); } catch { /* */ } };
    add('OneDrive', process.env.OneDrive); add('OneDrive', process.env.OneDriveConsumer); add('OneDrive', path.join(os.homedir(), 'OneDrive'));
    if (process.platform === 'win32') for (const L of 'DEFGHIJKLMNOPQRSTUVWXYZ') for (const n of ['Мой диск', 'My Drive']) add('Google Диск', `${L}:\\${n}`);
    add('Google Диск', path.join(os.homedir(), 'Google Drive', 'My Drive')); add('Dropbox', path.join(os.homedir(), 'Dropbox'));
    return out;
  }
  function status() {
    const others = [];
    if (cfg) try {
      for (const n of fs.readdirSync(dir())) if (/^online-.+\.json$/.test(n)) { const j = readJSON(path.join(dir(), n)); if (j && j.host !== host && Date.now() - j.t < 3 * 60e3) others.push(j.host); }
    } catch { /* */ }
    return { on: !!cfg, dir: cfg ? cfg.dir : '', host, lastPush, lastPull, err, others, suggestions: cfg ? [] : suggestions() };
  }
  function connect(d) {
    if (!d || !fs.existsSync(d) || !fs.statSync(d).isDirectory()) return { ...status(), err: 'Папка не найдена' };
    cfg = { dir: d }; fs.writeFileSync(cfgFile(), JSON.stringify(cfg));
    fs.mkdirSync(dir(), { recursive: true });
    let L = readLocal(), joined = false;
    const r = readRemote();
    if (r.s) { // в облаке уже есть данные (с другого компьютера): берём их, а свои рисунки добавляем
      L = L ? merge({ ...r.s, savedAt: Math.max(r.s.savedAt || 0, (L.savedAt || 0) + 1) }, L) : r.s;
      writeLocal(L); remember(L); seenMtime = r.mtime; joined = true; notify();
    }
    push();
    return { ...status(), joined };
  }

  ipcMain.handle('sync-status', () => status());
  ipcMain.handle('sync-connect', async (e, d) => {
    if (d && !suggestions().some(x => x.dir === d)) d = null; // путь из окна — только из найденных облачных папок
    if (!d) {
      const w = BrowserWindow.fromWebContents(e.sender), sug = suggestions();
      const r = await dialog.showOpenDialog(w, { title: 'Выберите облачную папку (OneDrive / Google Диск)', defaultPath: sug[0] ? sug[0].dir : os.homedir(), properties: ['openDirectory'] });
      if (r.canceled || !r.filePaths[0]) return status();
      d = r.filePaths[0];
    }
    return connect(d);
  });
  ipcMain.handle('sync-off', () => { cfg = null; try { fs.unlinkSync(cfgFile()); } catch { /* */ } return status(); });

  return { load, save };
}

module.exports = { register, merge, mergeList, locate };
