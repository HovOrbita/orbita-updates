'use strict';
// Orbita на телефоне: компьютер раздаёт ту же программу по домашней Wi-Fi сети.
// Телефон подключается по QR-коду (в нём секретный ключ). Цены телефон берёт с бирж сам,
// а рисунки, списки, настройки и позиции с бирж — общие с компьютером (как ещё одно окно).
// Ключи бирж с компьютера не уходят: телефон получает только готовые данные.
const http = require('http');
const os = require('os');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
// что телефону можно вызывать у компьютера (управление ключами бирж, окнами и установкой обновлений — только на компьютере)
const ALLOW = new Set(['fetch-json', 'fetch-text', 'state-load', 'state-save', 'lic-status', 'acct-list', 'acct-fetch', 'acct-opentime', 'upd-check']);

function register({ ipcMain, app, appDir, handlers, onHandlers, getVer }) {
  const cfgFile = () => path.join(app.getPath('userData'), 'phone.json');
  let cfg = null, server = null, port = 0, lastErr = '';
  const clients = new Map(); // ip -> { seen, ua }
  const fails = new Map();   // ip -> { n, until }

  function load() {
    if (cfg) return cfg;
    try { cfg = JSON.parse(fs.readFileSync(cfgFile(), 'utf8')); } catch { cfg = {}; }
    if (!cfg.token) { cfg.token = crypto.randomBytes(24).toString('base64url'); save(); }
    return cfg;
  }
  function save() { try { fs.writeFileSync(cfgFile(), JSON.stringify(cfg)); } catch { /* */ } }

  function lanIPs() {
    const out = [];
    for (const [name, list] of Object.entries(os.networkInterfaces())) for (const a of list || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal || /^169\.254\./.test(a.address)) continue;
      const priv = /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address);
      // Tailscale: адреса 100.64.0.0/10 — работает и дома, и через мобильный интернет
      const ts = /tailscale/i.test(name) || /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(a.address);
      const virt = !ts && /vmware|virtualbox|vbox|hyper-v|vethernet|wsl|docker|zerotier|loopback/i.test(name);
      out.push({ ip: a.address, name: ts ? 'Tailscale — везде' : name, ts, score: ts ? 10 : (priv ? 2 : 0) + (virt ? -3 : 0) + (/^192\.168\./.test(a.address) ? 1 : 0) });
    }
    if (tsName && out.some(x => x.ts)) out.push({ ip: tsName, name: 'Tailscale — везде, включается сам', ts: true, dns: true, score: 12 });
    return out.sort((a, b) => b.score - a.score);
  }

  // имя компьютера в Tailscale (MagicDNS, …ts.net): по нему iPhone может сам включать Tailscale (VPN On Demand)
  let tsName = '', tsAt = 0;
  function refreshTsName() {
    if (Date.now() - tsAt < 60e3) return Promise.resolve(); tsAt = Date.now();
    const { execFile } = require('child_process');
    const cands = process.platform === 'win32'
      ? [path.join(process.env.ProgramFiles || 'C:\\Program Files', 'Tailscale', 'tailscale.exe'), 'tailscale']
      : ['/Applications/Tailscale.app/Contents/MacOS/Tailscale', 'tailscale'];
    return new Promise(done => {
      const tryOne = i => {
        if (i >= cands.length) { tsName = ''; return done(); }
        execFile(cands[i], ['status', '--json'], { timeout: 5000, windowsHide: true, maxBuffer: 8e6 }, (err, out) => {
          if (err) return tryOne(i + 1);
          try { const j = JSON.parse(out), n = String((j.Self && j.Self.DNSName) || '').replace(/\.$/, ''); tsName = /\.ts\.net$/i.test(n) ? n.toLowerCase() : ''; } catch { tsName = ''; }
          done();
        });
      };
      tryOne(0);
    });
  }

  function authOK(req) {
    const k = String(req.headers['x-orbita-key'] || '');
    const t = Buffer.from(load().token), g = Buffer.from(k);
    return g.length === t.length && crypto.timingSafeEqual(g, t);
  }
  function blocked(ip) { const f = fails.get(ip); return f && f.until > Date.now(); }
  function fail(ip) { const f = fails.get(ip) || { n: 0, until: 0 }; f.n++; if (f.n >= 20) { f.until = Date.now() + 10 * 60e3; f.n = 0; } fails.set(ip, f); }

  function send(res, code, body, type = 'application/json; charset=utf-8') {
    res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' });
    res.end(body);
  }
  function readBody(req, max) {
    return new Promise((ok, bad) => {
      const ch = []; let n = 0;
      req.on('data', d => { n += d.length; if (n > max) { bad(new Error('слишком большой запрос')); req.destroy(); } else ch.push(d); });
      req.on('end', () => ok(Buffer.concat(ch).toString('utf8')));
      req.on('error', bad);
    });
  }

  // страница программы для телефона: та же index.html + «мостик» вместо Electron и стили для маленького экрана
  function pageHTML() {
    let h = fs.readFileSync(path.join(appDir, 'src', 'index.html'), 'utf8');
    h = h.replace(/connect-src /, "connect-src 'self' ");
    h = h.replace('<meta charset="utf-8">', `<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Orbita">
  <meta name="theme-color" content="#0b0f17">
  <link rel="apple-touch-icon" href="/phone/icon.png">
  <script src="/phone/bridge.js"></script>`);
    h = h.replace('<link rel="stylesheet" href="styles.css">', '<link rel="stylesheet" href="styles.css">\n  <link rel="stylesheet" href="/phone/phone.css">');
    return h;
  }

  function serveFile(res, base, rel) {
    const root = path.resolve(base), f = path.resolve(root, '.' + path.sep + rel);
    if (!f.startsWith(root + path.sep)) return send(res, 404, 'нет', 'text/plain; charset=utf-8');
    fs.readFile(f, (err, data) => {
      if (err) return send(res, 404, 'нет', 'text/plain; charset=utf-8');
      res.writeHead(200, { 'Content-Type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      res.end(data);
    });
  }

  async function onReq(req, res) {
    const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    let u; try { u = new URL(req.url, 'http://x'); } catch { return send(res, 400, '{}'); }
    const p = decodeURIComponent(u.pathname);
    if (p === '/' ) { res.writeHead(302, { Location: '/app/?w=phone' }); return res.end(); }
    if (p === '/app/' || p === '/app/index.html') return send(res, 200, pageHTML(), MIME['.html']);
    if (p.startsWith('/app/')) return serveFile(res, path.join(appDir, 'src'), p.slice(5));
    if (p.startsWith('/phone/')) return serveFile(res, path.join(appDir, 'phone'), p.slice(7));
    if (p.startsWith('/api/')) {
      if (blocked(ip)) return send(res, 429, JSON.stringify({ ok: false, error: 'слишком много попыток, подождите 10 минут' }));
      if (!authOK(req)) { fail(ip); return send(res, 401, JSON.stringify({ ok: false, error: 'нужно заново отсканировать QR-код на компьютере' })); }
      clients.set(ip, { seen: Date.now(), ua: String(req.headers['user-agent'] || '').slice(0, 160) });
      if (p === '/api/ver') return send(res, 200, JSON.stringify({ v: getVer() }));
      if (p === '/api/call' && req.method === 'POST') {
        try {
          const { ch, args } = JSON.parse(await readBody(req, 220e6));
          if (!ALLOW.has(ch)) return send(res, 403, JSON.stringify({ ok: false, error: 'это можно сделать только на компьютере' }));
          const ev = { sender: { id: -1, send() {} }, returnValue: undefined };
          if (handlers[ch]) { const r = await handlers[ch](ev, ...(Array.isArray(args) ? args : [])); return send(res, 200, JSON.stringify({ ok: true, r })); }
          if (onHandlers[ch]) { onHandlers[ch](ev, ...(Array.isArray(args) ? args : [])); return send(res, 200, JSON.stringify({ ok: true, r: ev.returnValue })); }
          return send(res, 404, JSON.stringify({ ok: false, error: 'нет такой функции' }));
        } catch (e) { return send(res, 500, JSON.stringify({ ok: false, error: String(e.message || e) })); }
      }
      return send(res, 404, '{}');
    }
    send(res, 404, 'нет', 'text/plain; charset=utf-8');
  }

  function start() {
    return new Promise(resolve => {
      if (server) return resolve(true);
      let tryPort = Number(load().port) || 8787, left = 15;
      const go = () => {
        const s = http.createServer((q, r) => { onReq(q, r).catch(() => { try { send(r, 500, '{}'); } catch { /* */ } }); });
        s.once('error', err => {
          if (err.code === 'EADDRINUSE' && left-- > 0) { tryPort++; go(); }
          else { lastErr = err.code === 'EACCES' ? 'Windows не разрешила открыть порт' : String(err.message || err); resolve(false); }
        });
        s.listen(tryPort, '0.0.0.0', () => { server = s; port = tryPort; lastErr = ''; if (cfg.port !== port) { cfg.port = port; save(); } resolve(true); });
      };
      go();
    });
  }
  function stop() { if (server) { try { server.close(); } catch { /* */ } server = null; port = 0; } }

  function qrModules(text) {
    const Q = require('./vendor/qrcode'), L = require('./vendor/qrcode/QRErrorCorrectLevel');
    const q = new Q(-1, L.M); q.addData(text); q.make();
    const n = q.getModuleCount(), rows = [];
    for (let r = 0; r < n; r++) { let s = ''; for (let c = 0; c < n; c++) s += q.isDark(r, c) ? '1' : '0'; rows.push(s); }
    return rows;
  }
  function status(ipPick) {
    const c = load(), ips = lanIPs(), ip = (ips.find(x => x.ip === ipPick) || ips[0] || {}).ip || '';
    const url = server && ip ? `http://${ip}:${port}/app/?w=phone#k=${c.token}` : '';
    const now = Date.now(), cl = [...clients.entries()].filter(([, v]) => now - v.seen < 3 * 60e3).map(([k, v]) => ({ ip: k, seen: v.seen, ua: v.ua }));
    const cur = ips.find(x => x.ip === ip);
    return { on: !!server, enabled: !!c.enabled, port, ips: ips.map(x => ({ ip: x.ip, name: x.name, ts: x.ts, dns: !!x.dns })), ip, remote: !!(cur && cur.ts), auto: !!(cur && cur.dns), hasTs: ips.some(x => x.ts), url, qr: url ? qrModules(url) : null, clients: cl, error: lastErr };
  }

  ipcMain.handle('phone-status', async (_e, ip) => { await refreshTsName(); return status(ip); });
  ipcMain.handle('phone-enable', async (_e, on, ip) => {
    load().enabled = !!on; save();
    if (on) await start(); else stop();
    await refreshTsName();
    return status(ip);
  });
  ipcMain.handle('phone-reset', async (_e, ip) => { // новый ключ — все телефоны отключатся
    load().token = crypto.randomBytes(24).toString('base64url'); save(); clients.clear();
    return status(ip);
  });

  app.whenReady().then(() => { if (load().enabled) start(); });
  app.on('will-quit', stop);
}

module.exports = { register };
