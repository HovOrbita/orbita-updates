'use strict';
const { app, BrowserWindow, shell, Menu, ipcMain, net, safeStorage, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { execSync } = require('child_process');

// запоминаем обработчики, чтобы телефон (через домашнюю сеть) мог вызывать те же функции, что и окна программы
const IPC_H = {}, IPC_ON = {};
let STATE_VER = 1;
{
  const h0 = ipcMain.handle.bind(ipcMain), o0 = ipcMain.on.bind(ipcMain);
  ipcMain.handle = (ch, fn) => { IPC_H[ch] = fn; return h0(ch, fn); };
  ipcMain.on = (ch, fn) => {
    const f = ch === 'state-save' ? (e, ...a) => { fn(e, ...a); if (e.returnValue) STATE_VER++; } : fn;
    IPC_ON[ch] = f; return o0(ch, f);
  };
}

app.setAppUserModelId('com.orbita.terminal');

// Разрешённые адреса публичных API бирж
const ALLOWED_HOSTS = new Set([
  'api.binance.com', 'data-api.binance.vision', 'fapi.binance.com',
  'api.bybit.com', 'www.okx.com', 'api.gateio.ws', 'api.mexc.com',
  // новости (публичные Telegram-каналы) и бесплатный перевод
  't.me', 'translate.googleapis.com', 'api.mymemory.translated.net',
  'api.gdeltproject.org',
]);
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36';

// загрузка страницы как текста (для новостей): только разрешённые адреса, не больше 3 МБ
ipcMain.handle('fetch-text', async (_e, url) => {
  let u;
  try { u = new URL(url); } catch { return { ok: false, status: 0, text: '' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.has(u.hostname)) return { ok: false, status: 0, text: '' };
  try {
    const r = await net.fetch(url, { signal: AbortSignal.timeout(15000), headers: { 'User-Agent': UA, 'Accept-Language': 'en' } });
    const text = (await r.text()).slice(0, 3e6);
    return { ok: r.ok, status: r.status, text };
  } catch (e) {
    return { ok: false, status: 0, text: String(e && e.message || e) };
  }
});

ipcMain.handle('fetch-json', async (_e, url) => {
  let u;
  try { u = new URL(url); } catch { return { ok: false, status: 0, text: 'bad url' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.has(u.hostname)) return { ok: false, status: 0, text: 'host not allowed' };
  try {
    const r = await net.fetch(url, { signal: AbortSignal.timeout(12000), headers: { 'User-Agent': UA } });
    const text = await r.text();
    let data = null;
    try { data = JSON.parse(text); } catch { /* не JSON */ }
    return { ok: r.ok, status: r.status, data, text: data ? undefined : text.slice(0, 300) };
  } catch (e) {
    return { ok: false, status: 0, text: String(e && e.message || e) };
  }
});

// Надёжное сохранение: настройки и рисунки пишутся ещё и в файл (на случай, если хранилище браузера переполнится)
const stateFile = () => path.join(app.getPath('userData'), 'orbita-state.json');
// облачная синхронизация (OneDrive / Google Диск): компьютер и ноутбук работают независимо, данные сходятся через облако
const SYNC = require('./sync-main').register({ ipcMain, app, dialog, BrowserWindow, stateFile, notify: () => {
  STATE_VER++;
  for (const w of BrowserWindow.getAllWindows()) if (!w.isDestroyed()) w.webContents.send('state-changed');
} });
ipcMain.on('state-load', e => { try { e.returnValue = SYNC.load(); } catch { e.returnValue = null; } });
ipcMain.on('state-save', (e, json) => {
  try {
    e.returnValue = SYNC.save(json);
    // остальные окна подтягивают общие данные (рисунки, настройки, алерты)
    for (const w of BrowserWindow.getAllWindows()) if (w.webContents !== e.sender && !w.isDestroyed()) w.webContents.send('state-changed');
  } catch (err) { e.returnValue = false; }
});

// ---------- офлайн-лицензия (без сервера): код привязан к одному компьютеру ----------
const LICENSE_PUB = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAbgmKuijwddW7Ns8Pxzu+bYgGVA48HeJbNrT63dFh2dU=
-----END PUBLIC KEY-----`;
const SALE_FLAG = () => fs.existsSync(path.join(__dirname, 'ПРОДАЖА.on'));
let MID = '';
function machineId() {
  if (MID) return MID;
  let raw = '';
  try {
    const o = execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: 'utf8', timeout: 4000 });
    raw = (o.match(/MachineGuid\s+REG_SZ\s+([\w-]+)/i) || [])[1] || '';
  } catch { /* не Windows или нет доступа */ }
  if (!raw) {
    try { const m = Object.values(os.networkInterfaces()).flat().filter(x => x && !x.internal && x.mac && x.mac !== '00:00:00:00:00:00').map(x => x.mac).sort(); raw = os.hostname() + (m[0] || ''); } catch { /* */ }
  }
  if (!raw) raw = os.hostname() || 'unknown';
  const h = crypto.createHash('sha256').update('orbita:' + raw).digest('hex').slice(0, 12).toUpperCase();
  return (MID = h.replace(/(.{4})(.{4})(.{4})/, '$1-$2-$3'));
}
// Надёжное «сейчас» для пробного ключа без сервера: время биржи из интернета (перевод часов на компьютере не поможет)
// и самое позднее время, которое программа уже видела на этом компьютере (если интернета нет).
const LT_FILE = () => path.join(app.getPath('userData'), 'lt.dat');
const ltSig = t => crypto.createHmac('sha256', 'orbita-lt:' + machineId()).update(String(t)).digest('hex').slice(0, 16);
function lastSeen() {
  try { const [t, h] = fs.readFileSync(LT_FILE(), 'utf8').split('.'); return h === ltSig(+t) ? +t : 0; } catch { return 0; }
}
let netOff = null, netAt = 0;
async function netTime() {
  if (netOff !== null && Date.now() - netAt < 30 * 60e3) return Date.now() + netOff;
  const srcs = [['https://api.binance.com/api/v3/time', j => j.serverTime], ['https://api.bybit.com/v5/market/time', j => +j.time],
    ['https://www.okx.com/api/v5/public/time', j => +j.data[0].ts], ['https://api.gateio.ws/api/v4/spot/time', j => j.server_time]];
  for (const [u, f] of srcs) {
    try {
      const ac = new AbortController(), to = setTimeout(() => ac.abort(), 5000);
      const r = await net.fetch(u, { signal: ac.signal }); clearTimeout(to);
      const t = +f(await r.json());
      if (t > 1.7e12 && t < 4e12) { netOff = t - Date.now(); netAt = Date.now(); return t; }
    } catch { /* следующая биржа */ }
  }
  return 0;
}
async function trustedNow() {
  const t = Math.max(Date.now(), lastSeen(), await netTime());
  try { fs.writeFileSync(LT_FILE(), t + '.' + ltSig(t)); } catch { /* */ }
  return t;
}
function verifyLicense(code, now = Date.now()) {
  try {
    const [p, sg] = String(code || '').trim().split('.');
    if (!p || !sg) return { ok: false, reason: 'неполный код' };
    const payload = Buffer.from(p, 'base64url'), sig = Buffer.from(sg, 'base64url');
    if (!crypto.verify(null, payload, LICENSE_PUB, sig)) return { ok: false, reason: 'код недействителен' };
    const d = JSON.parse(payload.toString('utf8'));
    if (d.m && d.m !== machineId()) return { ok: false, reason: 'код выдан для другого компьютера' };
    if (d.exp && now > d.exp) return { ok: false, expired: true, exp: d.exp, trial: !!d.t, reason: d.t ? 'пробный период закончился' : 'срок лицензии истёк' };
    return { ok: true, name: d.n || '', exp: d.exp || 0, trial: !!d.t, daysLeft: d.exp ? Math.max(0, Math.ceil((d.exp - now) / 864e5)) : null };
  } catch { return { ok: false, reason: 'неверный код' }; }
}
const licFile = () => path.join(app.getPath('userData'), 'license.key');
ipcMain.handle('lic-status', async () => {
  const need = SALE_FLAG();
  if (!need) return { need, ok: true, machine: machineId() };
  let code = ''; try { code = fs.readFileSync(licFile(), 'utf8'); } catch { /* нет файла */ }
  const r = code ? verifyLicense(code, await trustedNow()) : { ok: false, reason: 'нет лицензии' };
  return { need, ...r, machine: machineId() };
});
ipcMain.handle('lic-activate', async (_e, code) => {
  const r = verifyLicense(code, await trustedNow());
  if (r.ok) { try { fs.writeFileSync(licFile(), String(code).trim(), 'utf8'); } catch { /* */ } }
  return { ...r, machine: machineId() };
});

// счета бирж — только чтение (позиции и ордера), ключи зашифрованы
require('./accounts-main').register({ ipcMain, app, net, safeStorage });

// обновление одной кнопкой (GitHub Releases, файлы подписаны ключом владельца)
require('./updater').register({ ipcMain, app, net, pubKey: LICENSE_PUB, appDir: __dirname });

// Orbita на телефоне по QR-коду (домашняя Wi-Fi сеть)
require('./mobile-server').register({ ipcMain, app, appDir: __dirname, handlers: IPC_H, onHandlers: IPC_ON, getVer: () => STATE_VER });

// ---------- окна: главное + дополнительные (их можно унести на другой монитор) ----------
const winFile = () => path.join(app.getPath('userData'), 'windows.json');
let winReg = { main: null, extra: [] }, quitting = false;
const extras = new Map();
function readWins() {
  try { const w = JSON.parse(fs.readFileSync(winFile(), 'utf8')); return { main: w.main || null, extra: Array.isArray(w.extra) ? w.extra : [] }; }
  catch { return { main: null, extra: [] }; }
}
function writeWins() { try { fs.writeFileSync(winFile(), JSON.stringify(winReg), 'utf8'); } catch { /* */ } }
function boundsOk(b) { // окно должно попадать на один из подключённых мониторов
  if (!b || !(b.width > 200) || !(b.height > 150)) return false;
  const { screen } = require('electron');
  return screen.getAllDisplays().some(d => { const a = d.workArea; return b.x < a.x + a.width - 60 && b.x + b.width > a.x + 60 && b.y < a.y + a.height - 40 && b.y + 20 > a.y - 10; });
}
function createWindow(id = 'main', bounds = null) {
  const isMain = id === 'main', b = boundsOk(bounds) ? bounds : null;
  const win = new BrowserWindow({
    ...(b ? { x: b.x, y: b.y, width: b.width, height: b.height } : { width: isMain ? 1480 : 1100, height: isMain ? 920 : 700 }),
    minWidth: isMain ? 1000 : 640,
    minHeight: isMain ? 640 : 420,
    backgroundColor: '#0b0f17',
    title: isMain ? 'Orbita Terminal' : 'Orbita — окно',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      backgroundThrottling: false, // не «замораживать» программу, когда окно в фоне
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  if (b && b.max) win.maximize();
  win.loadFile(path.join(__dirname, 'src', 'index.html'), isMain ? {} : { query: { w: id } });
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
  const saveBounds = () => {
    if (win.isDestroyed()) return;
    const nb = { ...win.getNormalBounds(), max: win.isMaximized() };
    if (isMain) winReg.main = nb; else { const e = winReg.extra.find(x => x.id === id); if (e) e.bounds = nb; }
    writeWins();
  };
  win.on('close', () => {
    saveBounds();
    if (isMain) { quitting = true; for (const w of extras.values()) if (!w.isDestroyed()) w.close(); }
    else if (!quitting) { winReg.extra = winReg.extra.filter(x => x.id !== id); writeWins(); } // закрыли вручную — больше не открываем
  });
  win.on('closed', () => { if (!isMain) extras.delete(id); });
  if (!isMain) extras.set(id, win);
  return win;
}
ipcMain.handle('win-new', e => {
  const src = BrowserWindow.fromWebContents(e.sender);
  const id = 'w' + Date.now().toString(36);
  let bounds = null;
  if (src && !src.isDestroyed()) { const s = src.getBounds(); bounds = { x: s.x + 48, y: s.y + 48, width: Math.min(s.width, 1200), height: Math.min(s.height, 760) }; }
  winReg.extra.push({ id, bounds });
  writeWins();
  createWindow(id, bounds);
  return id;
});

// ---------- второй компьютер (ноутбук): Orbita показывает аккаунт основного компьютера ----------
const REMOTE_FILE = () => path.join(app.getPath('userData'), 'remote.json');
const REMOTE_RE = /^http:\/\/[A-Za-z0-9.-]+:\d{2,5}\/app\/\?w=\w+#k=[\w-]{16,}$/;
function remoteCfg() {
  try { const j = JSON.parse(fs.readFileSync(REMOTE_FILE(), 'utf8')); if (REMOTE_RE.test(j.url)) return j; } catch { /* нет */ }
  return null;
}
function remoteDisconnect(win) {
  const r = dialog.showMessageBoxSync(win, { type: 'question', buttons: ['Отмена', 'Отключиться'], defaultId: 0, cancelId: 0, title: 'Orbita',
    message: 'Отключить этот компьютер от основной Orbita?', detail: 'Orbita запустится как отдельная программа со своими графиками. Подключиться снова можно в окне «Телефон и ноутбук».' });
  if (r !== 1) return;
  try { fs.unlinkSync(REMOTE_FILE()); } catch { /* */ }
  app.relaunch(); app.exit(0);
}
function createRemoteWindow(cfg) {
  const b = cfg.bounds && boundsOk(cfg.bounds) ? cfg.bounds : { width: 1400, height: 860 };
  const win = new BrowserWindow({ ...b, minWidth: 900, minHeight: 560, backgroundColor: '#0b0f17', title: 'Orbita', autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, sandbox: true, nodeIntegration: false } }); // без доступа к этому компьютеру: только страница основной Orbita
  if (cfg.max) win.maximize();
  const origin = new URL(cfg.url).origin;
  const errPage = msg => 'data:text/html;charset=utf-8,' + encodeURIComponent(`<!doctype html><meta charset="utf-8"><body style="margin:0;height:100vh;display:grid;place-items:center;background:#0b0f17;color:#e6ebf2;font:15px/1.5 system-ui,Segoe UI,sans-serif"><div style="max-width:460px;text-align:center"><div style="font-size:42px">🛰</div><h2 style="margin:8px 0">Нет связи с основным компьютером</h2><p style="color:#9aa4b2">${msg}</p><p><a href="orbita-remote://retry" style="display:inline-block;margin:6px;padding:10px 18px;border-radius:8px;background:#2f6fed;color:#fff;text-decoration:none">Повторить</a><a href="orbita-remote://disconnect" style="display:inline-block;margin:6px;padding:10px 18px;border-radius:8px;background:#1b2230;color:#e6ebf2;text-decoration:none">Отключиться</a></p></div></body>`);
  win.webContents.on('will-navigate', (e, u) => {
    if (u.startsWith('orbita-remote://')) { e.preventDefault(); if (u.includes('disconnect')) remoteDisconnect(win); else win.loadURL(cfg.url); return; }
    if (!u.startsWith(origin) && !u.startsWith('data:')) { e.preventDefault(); if (/^https:\/\//.test(u)) shell.openExternal(u); }
  });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('did-fail-load', (_e, code, _d, url, isMain) => {
    if (isMain && code !== -3 && !String(url).startsWith('data:'))
      win.loadURL(errPage('Проверьте: основной компьютер включён и Orbita на нём открыта; если вы не дома — Tailscale включён на обоих компьютерах.'));
  });
  win.webContents.on('before-input-event', (e, input) => { // Ctrl+Shift+L — отключиться от основного компьютера
    if (input.type === 'keyDown' && input.control && input.shift && String(input.key).toLowerCase() === 'l') { e.preventDefault(); remoteDisconnect(win); }
  });
  const keep = () => { try { const c = remoteCfg() || cfg; c.max = win.isMaximized(); if (!c.max) c.bounds = win.getBounds(); fs.writeFileSync(REMOTE_FILE(), JSON.stringify(c)); } catch { /* */ } };
  win.on('close', keep);
  win.loadURL(cfg.url);
}
ipcMain.handle('remote-connect', (_e, url) => {
  url = String(url || '').trim().replace(/([?&]w=)phone\b/, '$1laptop');
  if (!REMOTE_RE.test(url)) return { ok: false, error: 'Это не похоже на ссылку Orbita. Скопируйте её на основном компьютере: кнопка «Телефон и ноутбук» → «Скопировать ссылку для ноутбука».' };
  fs.writeFileSync(REMOTE_FILE(), JSON.stringify({ url }));
  setTimeout(() => { app.relaunch(); app.exit(0); }, 300);
  return { ok: true };
});

app.whenReady().then(() => {
  // На macOS оставляем стандартное меню (нужно для Cmd+C / Cmd+V в полях ввода)
  if (process.platform !== 'darwin') Menu.setApplicationMenu(null);
  const rc = remoteCfg();
  if (rc) { createRemoteWindow(rc); return; } // этот компьютер подключён к основной Orbita
  winReg = readWins();
  createWindow('main', winReg.main);
  for (const x of winReg.extra.slice(0, 8)) createWindow(x.id, x.bounds); // дополнительные окна — там же, где их оставили
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
