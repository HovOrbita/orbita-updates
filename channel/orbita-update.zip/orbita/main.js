'use strict';
const { app, BrowserWindow, shell, Menu, ipcMain, net, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { execSync } = require('child_process');

app.setAppUserModelId('com.orbita.terminal');

// Разрешённые адреса публичных API бирж
const ALLOWED_HOSTS = new Set([
  'api.binance.com', 'data-api.binance.vision', 'fapi.binance.com',
  'api.bybit.com', 'www.okx.com', 'api.gateio.ws', 'api.mexc.com',
  // новости (публичные Telegram-каналы) и бесплатный перевод
  't.me', 'translate.googleapis.com', 'api.mymemory.translated.net',
  'api.gdeltproject.org',
]);
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36';

// загрузка страницы как текста (для новостей): только разрешённые адреса, не больше 3 МБ
ipcMain.handle('fetch-text', async (_e, url) => {
  let u;
  try { u = new URL(url); } catch { return { ok: false, status: 0, text: '' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.has(u.hostname)) return { ok: false, status: 0, text: '' };
  try {
    const r = await net.fetch(url, { signal: AbortSignal.timeout(15000), headers: { 'User-Agent': UA, 'Accept-Language': 'en' } });
    const text = (await r.text()).slice(0, 3e6);
    return { ok: r.ok, status: r.status, text };
  } catch (e) {
    return { ok: false, status: 0, text: String(e && e.message || e) };
  }
});

ipcMain.handle('fetch-json', async (_e, url) => {
  let u;
  try { u = new URL(url); } catch { return { ok: false, status: 0, text: 'bad url' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.has(u.hostname)) return { ok: false, status: 0, text: 'host not allowed' };
  try {
    const r = await net.fetch(url, { signal: AbortSignal.timeout(12000), headers: { 'User-Agent': UA } });
    const text = await r.text();
    let data = null;
    try { data = JSON.parse(text); } catch { /* не JSON */ }
    return { ok: r.ok, status: r.status, data, text: data ? undefined : text.slice(0, 300) };
  } catch (e) {
    return { ok: false, status: 0, text: String(e && e.message || e) };
  }
});

// Надёжное сохранение: настройки и рисунки пишутся ещё и в файл (на случай, если хранилище браузера переполнится)
const stateFile = () => path.join(app.getPath('userData'), 'orbita-state.json');
ipcMain.on('state-load', e => {
  for (const f of [stateFile(), stateFile() + '.bak']) {
    try { e.returnValue = fs.readFileSync(f, 'utf8'); return; } catch { /* нет файла */ }
  }
  e.returnValue = null;
});
ipcMain.on('state-save', (e, json) => {
  try {
    if (typeof json !== 'string' || json.length > 200e6) throw new Error('bad state');
    JSON.parse(json);
    const f = stateFile(), tmp = f + '.tmp';
    fs.writeFileSync(tmp, json, 'utf8');
    try { fs.copyFileSync(f, f + '.bak'); } catch { /* первого файла ещё нет */ }
    fs.renameSync(tmp, f);
    e.returnValue = true;
    // остальные окна подтягивают общие данные (рисунки, настройки, алерты)
    for (const w of BrowserWindow.getAllWindows()) if (w.webContents !== e.sender && !w.isDestroyed()) w.webContents.send('state-changed');
  } catch (err) { e.returnValue = false; }
});

// ---------- офлайн-лицензия (без сервера): код привязан к одному компьютеру ----------
const LICENSE_PUB = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAbgmKuijwddW7Ns8Pxzu+bYgGVA48HeJbNrT63dFh2dU=
-----END PUBLIC KEY-----`;
const SALE_FLAG = () => fs.existsSync(path.join(__dirname, 'ПРОДАЖА.on'));
function machineId() {
  let raw = '';
  try {
    const o = execSync('reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid', { encoding: 'utf8', timeout: 4000 });
    raw = (o.match(/MachineGuid\s+REG_SZ\s+([\w-]+)/i) || [])[1] || '';
  } catch { /* не Windows или нет доступа */ }
  if (!raw) {
    try { const m = Object.values(os.networkInterfaces()).flat().filter(x => x && !x.internal && x.mac && x.mac !== '00:00:00:00:00:00').map(x => x.mac).sort(); raw = os.hostname() + (m[0] || ''); } catch { /* */ }
  }
  if (!raw) raw = os.hostname() || 'unknown';
  const h = crypto.createHash('sha256').update('orbita:' + raw).digest('hex').slice(0, 12).toUpperCase();
  return h.replace(/(.{4})(.{4})(.{4})/, '$1-$2-$3');
}
function verifyLicense(code) {
  try {
    const [p, sg] = String(code || '').trim().split('.');
    if (!p || !sg) return { ok: false, reason: 'неполный код' };
    const payload = Buffer.from(p, 'base64url'), sig = Buffer.from(sg, 'base64url');
    if (!crypto.verify(null, payload, LICENSE_PUB, sig)) return { ok: false, reason: 'код недействителен' };
    const d = JSON.parse(payload.toString('utf8'));
    if (d.m && d.m !== machineId()) return { ok: false, reason: 'код выдан для другого компьютера' };
    if (d.exp && Date.now() > d.exp) return { ok: false, reason: 'срок лицензии истёк' };
    return { ok: true, name: d.n || '', exp: d.exp || 0 };
  } catch { return { ok: false, reason: 'неверный код' }; }
}
const licFile = () => path.join(app.getPath('userData'), 'license.key');
ipcMain.handle('lic-status', () => {
  const need = SALE_FLAG();
  let code = ''; try { code = fs.readFileSync(licFile(), 'utf8'); } catch { /* нет файла */ }
  const r = code ? verifyLicense(code) : { ok: false, reason: 'нет лицензии' };
  return { need, ...r, machine: machineId() };
});
ipcMain.handle('lic-activate', (_e, code) => {
  const r = verifyLicense(code);
  if (r.ok) { try { fs.writeFileSync(licFile(), String(code).trim(), 'utf8'); } catch { /* */ } }
  return { ...r, machine: machineId() };
});

// счета бирж — только чтение (позиции и ордера), ключи зашифрованы
require('./accounts-main').register({ ipcMain, app, net, safeStorage });

// обновление одной кнопкой (GitHub Releases, файлы подписаны ключом владельца)
require('./updater').register({ ipcMain, app, net, pubKey: LICENSE_PUB, appDir: __dirname });

// ---------- окна: главное + дополнительные (их можно унести на другой монитор) ----------
const winFile = () => path.join(app.getPath('userData'), 'windows.json');
let winReg = { main: null, extra: [] }, quitting = false;
const extras = new Map();
function readWins() {
  try { const w = JSON.parse(fs.readFileSync(winFile(), 'utf8')); return { main: w.main || null, extra: Array.isArray(w.extra) ? w.extra : [] }; }
  catch { return { main: null, extra: [] }; }
}
function writeWins() { try { fs.writeFileSync(winFile(), JSON.stringify(winReg), 'utf8'); } catch { /* */ } }
function boundsOk(b) { // окно должно попадать на один из подключённых мониторов
  if (!b || !(b.width > 200) || !(b.height > 150)) return false;
  const { screen } = require('electron');
  return screen.getAllDisplays().some(d => { const a = d.workArea; return b.x < a.x + a.width - 60 && b.x + b.width > a.x + 60 && b.y < a.y + a.height - 40 && b.y + 20 > a.y - 10; });
}
function createWindow(id = 'main', bounds = null) {
  const isMain = id === 'main', b = boundsOk(bounds) ? bounds : null;
  const win = new BrowserWindow({
    ...(b ? { x: b.x, y: b.y, width: b.width, height: b.height } : { width: isMain ? 1480 : 1100, height: isMain ? 920 : 700 }),
    minWidth: isMain ? 1000 : 640,
    minHeight: isMain ? 640 : 420,
    backgroundColor: '#0b0f17',
    title: isMain ? 'Orbita Terminal' : 'Orbita — окно',
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      backgroundThrottling: false, // не «замораживать» программу, когда окно в фоне
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  if (b && b.max) win.maximize();
  win.loadFile(path.join(__dirname, 'src', 'index.html'), isMain ? {} : { query: { w: id } });
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
  const saveBounds = () => {
    if (win.isDestroyed()) return;
    const nb = { ...win.getNormalBounds(), max: win.isMaximized() };
    if (isMain) winReg.main = nb; else { const e = winReg.extra.find(x => x.id === id); if (e) e.bounds = nb; }
    writeWins();
  };
  win.on('close', () => {
    saveBounds();
    if (isMain) { quitting = true; for (const w of extras.values()) if (!w.isDestroyed()) w.close(); }
    else if (!quitting) { winReg.extra = winReg.extra.filter(x => x.id !== id); writeWins(); } // закрыли вручную — больше не открываем
  });
  win.on('closed', () => { if (!isMain) extras.delete(id); });
  if (!isMain) extras.set(id, win);
  return win;
}
ipcMain.handle('win-new', e => {
  const src = BrowserWindow.fromWebContents(e.sender);
  const id = 'w' + Date.now().toString(36);
  let bounds = null;
  if (src && !src.isDestroyed()) { const s = src.getBounds(); bounds = { x: s.x + 48, y: s.y + 48, width: Math.min(s.width, 1200), height: Math.min(s.height, 760) }; }
  winReg.extra.push({ id, bounds });
  writeWins();
  createWindow(id, bounds);
  return id;
});

app.whenReady().then(() => {
  // На macOS оставляем стандартное меню (нужно для Cmd+C / Cmd+V в полях ввода)
  if (process.platform !== 'darwin') Menu.setApplicationMenu(null);
  winReg = readWins();
  createWindow('main', winReg.main);
  for (const x of winReg.extra.slice(0, 8)) createWindow(x.id, x.bounds); // дополнительные окна — там же, где их оставили
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
