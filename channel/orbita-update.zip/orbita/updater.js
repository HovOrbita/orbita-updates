'use strict';
// Обновление программы одной кнопкой.
// Источник — GitHub Releases (бесплатно): в последнем выпуске лежат latest.json и orbita-update.zip.
// Каждое обновление подписано секретным ключом владельца (Ed25519) — чужой или испорченный файл не установится.
const path = require('path');
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');

const MAX_ZIP = 60e6;

function pkg(dir) {
  try { return JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')); } catch { return {}; }
}
function manifestUrl(p) {
  const src = String(p.orbitaUpdates || '').trim();
  if (!src) return '';
  if (/^https:\/\//.test(src)) return src;
  if (/^[\w.-]+\/[\w.-]+$/.test(src)) return `https://github.com/${src}/releases/latest/download/latest.json`;
  return '';
}

// ---------- маленький распаковщик zip (только чтение, без сторонних библиотек) ----------
function unzip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('файл обновления повреждён');
  const n = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const out = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('файл обновления повреждён');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32);
    const flags = buf.readUInt16LE(p + 8), lho = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nl).toString(flags & 0x800 ? 'utf8' : 'latin1').replace(/\\/g, '/');
    p += 46 + nl + xl + cl;
    if (name.endsWith('/')) continue;
    if (buf.readUInt32LE(lho) !== 0x04034b50) throw new Error('файл обновления повреждён');
    const ds = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
    const raw = buf.slice(ds, ds + csize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8) data = zlib.inflateRawSync(raw);
    else throw new Error('неизвестное сжатие в архиве');
    if (data.length !== usize) throw new Error('файл обновления повреждён');
    out.push({ name, data });
  }
  return out;
}

// безопасный путь внутри папки программы: только orbita/…, без «..» и абсолютных путей
function safeRel(name) {
  if (!name.startsWith('orbita/')) return null;
  const rel = name.slice(7);
  if (!rel || rel.includes('\0')) return null;
  const parts = rel.split('/');
  if (parts.some(s => !s || s === '.' || s === '..' || /[:<>|"?*]/.test(s))) return null;
  if (/^(electron|node_modules)$/i.test(parts[0])) return null; // сам Electron не трогаем
  if (/\.(bat|cmd|exe|dll|ps1|vbs|lnk|on|pem|dat|key)$/i.test(rel)) return null; // ни запускаемых файлов, ни флагов/ключей
  return rel;
}

function register({ ipcMain, app, net, pubKey, appDir }) {
  const UA = 'OrbitaTerminal-Updater';
  let busy = false;

  async function getJSON(url) {
    const r = await net.fetch(url, { signal: AbortSignal.timeout(15000), headers: { 'User-Agent': UA, 'Cache-Control': 'no-cache' } });
    if (r.status === 404) return { none: true };
    if (!r.ok) throw new Error('сервер обновлений ответил ' + r.status);
    return JSON.parse(await r.text());
  }
  function checkSig(m) {
    const msg = Buffer.from(`orbita-update|${m.build}|${m.sha256}|${m.size}`);
    try { return crypto.verify(null, msg, pubKey, Buffer.from(String(m.sig || ''), 'base64')); } catch { return false; }
  }

  async function check() {
    const p = pkg(appDir), cur = Number(p.orbitaBuild) || 0, url = manifestUrl(p);
    const base = { cur, curLabel: p.orbitaBuildLabel || '' };
    if (!url) return { ...base, ok: false, notConfigured: true, error: 'Источник обновлений ещё не настроен' };
    let m;
    try { m = await getJSON(url); } catch (e) { return { ...base, ok: false, error: 'Нет связи с сервером обновлений' }; }
    if (m.none) return { ...base, ok: true, available: false };
    if (!(Number(m.build) > 0) || !/^[0-9a-f]{64}$/.test(m.sha256 || '') || !checkSig(m)) return { ...base, ok: false, error: 'Обновление на сервере не прошло проверку подписи — устанавливать нельзя' };
    return { ...base, ok: true, available: Number(m.build) > cur, build: Number(m.build), label: m.label || '', notes: Array.isArray(m.notes) ? m.notes.slice(0, 20).map(String) : [], size: m.size, _m: m, _url: url };
  }

  ipcMain.handle('upd-check', async () => { const r = await check(); delete r._m; delete r._url; return r; });

  ipcMain.handle('upd-install', async e => {
    if (busy) return { ok: false, error: 'Обновление уже идёт' };
    busy = true;
    const send = (stage, pct) => { try { e.sender.send('upd-progress', { stage, pct }); } catch { /* окно закрыто */ } };
    try {
      const c = await check();
      if (!c.ok) return { ok: false, error: c.error };
      if (!c.available) return { ok: false, error: 'У вас уже последняя версия' };
      const m = c._m;
      const zurl = new URL(m.file || 'orbita-update.zip', c._url).toString();
      if (!/^https:\/\//.test(zurl)) throw new Error('небезопасный адрес');
      send('download', 0);
      const r = await net.fetch(zurl, { signal: AbortSignal.timeout(180000), headers: { 'User-Agent': UA } });
      if (!r.ok) throw new Error('не удалось скачать (' + r.status + ')');
      const total = Number(r.headers.get('content-length')) || m.size || 0;
      const chunks = []; let got = 0;
      const rd = r.body.getReader();
      for (;;) {
        const { done, value } = await rd.read();
        if (done) break;
        got += value.length;
        if (got > MAX_ZIP) throw new Error('файл обновления слишком большой');
        chunks.push(Buffer.from(value));
        if (total) send('download', Math.min(99, Math.round(got / total * 100)));
      }
      const zip = Buffer.concat(chunks);
      send('verify', 100);
      const sha = crypto.createHash('sha256').update(zip).digest('hex');
      if (sha !== m.sha256 || zip.length !== Number(m.size)) throw new Error('скачанный файл не совпадает с подписанным — обновление отменено');
      const files = unzip(zip);
      const plan = [];
      for (const f of files) { const rel = safeRel(f.name); if (rel) plan.push({ rel, data: f.data }); }
      if (!plan.some(x => x.rel === 'main.js') || !plan.some(x => x.rel === 'src/index.html')) throw new Error('в архиве нет файлов программы');
      // проверим, что новый package.json действительно новее
      const np = plan.find(x => x.rel === 'package.json');
      if (np) { const v = JSON.parse(np.data.toString('utf8')); if (Number(v.orbitaBuild) !== Number(m.build)) throw new Error('номер сборки в архиве не совпадает'); }

      send('install', 100);
      // резервная копия текущих файлов — если что-то пойдёт не так, вернём как было
      const bak = path.join(app.getPath('userData'), 'update-backup');
      fs.rmSync(bak, { recursive: true, force: true });
      const done = [];
      try {
        for (const x of plan) {
          const dst = path.join(appDir, ...x.rel.split('/'));
          if (!dst.startsWith(appDir + path.sep)) throw new Error('недопустимый путь в архиве');
          let had = false;
          try { fs.mkdirSync(path.dirname(path.join(bak, x.rel)), { recursive: true }); fs.copyFileSync(dst, path.join(bak, x.rel)); had = true; } catch { /* новый файл */ }
          fs.mkdirSync(path.dirname(dst), { recursive: true });
          const tmp = dst + '.upd';
          fs.writeFileSync(tmp, x.data);
          fs.renameSync(tmp, dst);
          done.push({ x, dst, had });
        }
      } catch (err) {
        for (const d of done.reverse()) { try { if (d.had) fs.copyFileSync(path.join(bak, d.x.rel), d.dst); else fs.rmSync(d.dst, { force: true }); } catch { /* */ } }
        throw new Error('не удалось записать файлы (' + (err.message || err) + '). Всё возвращено как было.');
      }
      send('restart', 100);
      setTimeout(() => { app.relaunch(); app.exit(0); }, 1200);
      return { ok: true, build: m.build, label: m.label || '' };
    } catch (err) {
      return { ok: false, error: String(err && err.message || err) };
    } finally { busy = false; }
  });
}

module.exports = { register, unzip, safeRel, manifestUrl };
