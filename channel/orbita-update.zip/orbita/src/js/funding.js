'use strict';
// Фандинг (ставка финансирования бессрочных фьючерсов): карточка на графике.
// Сравнение 4 бирж, обратный отсчёт до списания, среднее за 3 дня, расшифровка и сколько заплатит/получит ваша позиция.
const Funding = (() => {
  const EX = [
    { k: 'binance', n: 'Binance', ids: ['BINANCE', 'BINANCEF'] },
    { k: 'bybit', n: 'Bybit', ids: ['BYBIT', 'BYBITF'] },
    { k: 'okx', n: 'OKX', ids: ['OKX'] },
    { k: 'gate', n: 'Gate', ids: ['GATE', 'GATEF'] },
  ];
  async function getJSON(url) {
    if (window.orbita && window.orbita.fetchJSON) {
      const r = await window.orbita.fetchJSON(url);
      if (!r.ok) throw new Error(r.status === 400 || r.status === 404 ? 'нет фьючерса' : 'нет связи');
      return r.data;
    }
    const r = await fetch(url); if (!r.ok) throw new Error('нет связи'); return r.json();
  }
  const H8 = 8 * 36e5;
  const FETCH = {
    async binance(b) {
      const s = b + 'USDT';
      const [p, h] = await Promise.all([
        getJSON(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${s}`),
        getJSON(`https://fapi.binance.com/fapi/v1/fundingRate?symbol=${s}&limit=40`).catch(() => []),
      ]);
      const hist = (h || []).map(x => ({ t: +x.fundingTime, r: +x.fundingRate })).filter(x => isFinite(x.r)).sort((a, c) => a.t - c.t);
      const iv = hist.length >= 2 ? hist[hist.length - 1].t - hist[hist.length - 2].t : H8;
      return { rate: +p.lastFundingRate, next: +p.nextFundingTime, iv: Math.round(iv / 36e5) * 36e5 || H8, hist };
    },
    async bybit(b) {
      const d = await getJSON(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${b}USDT`);
      const x = d && d.result && d.result.list && d.result.list[0]; if (!x || x.fundingRate === '') throw new Error('нет фьючерса');
      return { rate: +x.fundingRate, next: +x.nextFundingTime, iv: (+x.fundingIntervalHour || 8) * 36e5 };
    },
    async okx(b) {
      const d = await getJSON(`https://www.okx.com/api/v5/public/funding-rate?instId=${b}-USDT-SWAP`);
      const x = d && d.data && d.data[0]; if (!x) throw new Error('нет фьючерса');
      const t1 = +x.fundingTime, t2 = +x.nextFundingTime;
      return { rate: +x.fundingRate, next: t1, iv: t2 > t1 ? t2 - t1 : H8 };
    },
    async gate(b) {
      const x = await getJSON(`https://api.gateio.ws/api/v4/futures/usdt/contracts/${b}_USDT`);
      if (!x || x.funding_rate == null) throw new Error('нет фьючерса');
      return { rate: +x.funding_rate, next: +x.funding_next_apply * 1000, iv: (+x.funding_interval || 28800) * 1000 };
    },
  };

  const cache = new Map(); // base -> { t, data:{k:..}, busy }
  async function load(base, force) {
    let c = cache.get(base);
    if (c && !force && Date.now() - c.t < 55e3) return c;
    if (c && c.busy) return c.busy;
    const busy = (async () => {
      const data = {};
      await Promise.all(EX.map(async e => { try { data[e.k] = await FETCH[e.k](base); } catch (err) { data[e.k] = { err: err.message }; } }));
      const res = { t: Date.now(), data };
      cache.set(base, res);
      return res;
    })();
    cache.set(base, Object.assign(c || { t: 0, data: {} }, { busy }));
    try { return await busy; } finally { const cc = cache.get(base); if (cc) delete cc.busy; }
  }

  const pct = (r, d = 4) => `${r > 0 ? '+' : r < 0 ? '−' : ''}${Math.abs(r * 100).toFixed(d)}%`;
  const per8 = x => x.rate * (H8 / (x.iv || H8)); // приводим к 8 часам, чтобы сравнивать
  function left(ms) {
    if (!(ms > 0)) return 'сейчас';
    const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, ss = s % 60;
    return `${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`;
  }
  function read(r8) { // r8 — ставка за 8 часов
    const v = r8 * 100;
    if (v >= 0.05) return { k: 'r', t: 'Сильный перекос в лонги: лонги дорого платят шортам. Рынок перегрет — возможен резкий слив (лонг-сквиз).' };
    if (v >= 0.02) return { k: 'w', t: 'Лонгов заметно больше — платят выше обычного. Рост на плече, осторожно с лонгами на хаях.' };
    if (v > 0.003) return { k: 'n', t: 'Обычная ставка: лонги немного платят шортам. Перекоса нет.' };
    if (v >= -0.003) return { k: 'n', t: 'Около нуля — силы лонгов и шортов равны.' };
    if (v > -0.03) return { k: 'w', t: 'Шорты платят лонгам — шортистов больше. На росте их могут выносить.' };
    return { k: 'g', t: 'Сильный перекос в шорты: шорты дорого платят. Возможен резкий вынос вверх (шорт-сквиз).' };
  }
  // ваша открытая позиция по этой монете (с подключённой биржи)
  function myPos(base) {
    try {
      const k = App.dKey(base + 'USDT'), arr = (App.state.drawings[k] || []).filter(d => d.acct && d.acct.open && d.acct.notional > 0);
      return arr.map(d => ({ ex: d.acct.ex, long: d.type === 'long', usd: d.acct.notional }));
    } catch { return []; }
  }

  function exOf(ch) { const id = Data.parse(ch.sym).ex; const e = EX.find(x => x.ids.includes(id)); return e ? e.k : 'binance'; }

  function render(ch) {
    let el = ch.cell.querySelector('.fr-card');
    if (!ch.cfg.frCard) { if (el) el.remove(); return; }
    const box = ch.cardsBox();
    if (!el) { el = U.h('<div class="fr-card oi-card"></div>'); el.onclick = () => refresh(ch, true); el.title = 'Фандинг бессрочных USDT-фьючерсов. Клик — обновить'; }
    if (el.parentNode !== box) box.appendChild(el);
    const base = Data.label(ch.sym).base.toUpperCase(), c = cache.get(base), main = exOf(ch);
    const head = `<div class="oi-h"><b class="fr-b">Фандинг</b> ${U.esc(base)}`;
    if (!c || !c.t) { el.innerHTML = head + '</div><div class="oi-note">загрузка…</div>'; return; }
    const d = c.data, okList = EX.filter(e => d[e.k] && !d[e.k].err);
    if (!okList.length) { el.innerHTML = head + '</div><div class="oi-note">для этой монеты нет бессрочных фьючерсов</div>'; return; }
    const m = d[main] && !d[main].err ? main : okList[0].k, M = d[m], mName = EX.find(e => e.k === m).n;
    const ivH = Math.round((M.iv || H8) / 36e5), cls = r => r > 0.00003 ? 'up' : r < -0.00003 ? 'dn' : '';
    const r8 = per8(M), rd = read(r8);
    const yr = M.rate * (365 * 24 * 36e5 / (M.iv || H8)) * 100;
    let avg = '';
    if (M.hist && M.hist.length >= 3) {
      const from = Date.now() - 3 * 864e5, h = M.hist.filter(x => x.t >= from);
      if (h.length) { const a = h.reduce((s, x) => s + x.r, 0) / h.length; avg = `<span class="fr-avg">среднее за 3 дня <b class="${cls(a)}">${pct(a)}</b></span>`; }
    }
    const cells = EX.map(e => { const x = d[e.k]; if (!x || x.err) return `<div class="oi-c fr-c"><span class="oi-k">${e.n}</span><span class="oi-v fr-v dim">—</span></div>`;
      return `<div class="oi-c fr-c${e.k === m ? ' main' : ''}"><span class="oi-k">${e.n}${Math.round(x.iv / 36e5) !== 8 ? ` · ${Math.round(x.iv / 36e5)}ч` : ''}</span><span class="oi-v fr-v ${cls(x.rate)}">${pct(x.rate, 3)}</span></div>`; }).join('');
    const mine = myPos(base).map(p => {
      const x = d[p.ex] && !d[p.ex].err ? d[p.ex] : M, pay = (p.long ? 1 : -1) * x.rate * p.usd; // >0 — вы платите
      const v = Math.abs(pay), s = v >= 1 ? v.toFixed(2) : v.toFixed(3);
      return `<div class="fr-my ${pay > 0 ? 'dn' : 'up'}">Ваш ${p.long ? 'лонг' : 'шорт'} $${U.fmtNum(p.usd, 0)}: ${pay > 0 ? 'заплатите' : 'получите'} ≈ $${s}</div>`;
    }).join('');
    el.innerHTML = `${head}<span class="oi-sum"><span class="${cls(M.rate)}">${pct(M.rate)}</span> <span class="oi-dim">${mName}${ivH !== 8 ? ` / ${ivH}ч` : ''}</span></span></div>
      <div class="fr-t">до списания <b class="fr-left">${left(M.next - Date.now())}</b><span class="oi-dim"> · в год ≈ ${yr >= 0 ? '+' : '−'}${Math.abs(yr).toFixed(1)}%</span></div>
      <div class="oi-grid fr-grid">${cells}</div>${avg}${mine}
      <div class="oi-read ${rd.k}">${rd.t}</div>`;
    el._next = M.next;
  }
  async function refresh(ch, force) {
    if (!ch.cfg.frCard) { render(ch); return; }
    const base = Data.label(ch.sym).base.toUpperCase(), tok = ch.tok;
    if (!cache.get(base)) render(ch);
    await load(base, force);
    if (tok === ch.tok) render(ch);
  }
  // обратный отсчёт — раз в секунду, только текст
  setInterval(() => {
    document.querySelectorAll('.fr-card').forEach(el => { const t = el.querySelector('.fr-left'); if (t && el._next) t.textContent = left(el._next - Date.now()); });
  }, 1000);
  return { refresh, render, read, per8, _cache: cache };
})();
