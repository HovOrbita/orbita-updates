'use strict';
const LAYOUTS = {
  '1': { n: 1, cols: '1fr', rows: '1fr', name: '1 график', ic: 'M3 4h18v16H3z' },
  '2v': { n: 2, cols: '1fr 1fr', rows: '1fr', name: '2 рядом', ic: 'M3 4h18v16H3zM12 4v16' },
  '2h': { n: 2, cols: '1fr', rows: '1fr 1fr', name: '2 друг над другом', ic: 'M3 4h18v16H3zM3 12h18' },
  '3': { n: 3, cols: '1.6fr 1fr', rows: '1fr 1fr', span: true, name: '3: большой + 2', ic: 'M3 4h18v16H3zM13 4v16M13 12h8' },
  '4': { n: 4, cols: '1fr 1fr', rows: '1fr 1fr', name: '4 сеткой', ic: 'M3 4h18v16H3zM12 4v16M3 12h18' },
  '5': { n: 5, cols: 'repeat(6, 1fr)', rows: '1fr 1fr', spans: [2, 2, 2, 3, 3], name: '5: три сверху + два снизу', ic: 'M3 4h18v16H3zM3 12h18M9 4v8M15 4v8M12 12v8' },
  '6': { n: 6, cols: '1fr 1fr 1fr', rows: '1fr 1fr', name: '6 сеткой', ic: 'M3 4h18v16H3zM9 4v16M15 4v16M3 12h18' },
  '8': { n: 8, cols: 'repeat(4, 1fr)', rows: '1fr 1fr', name: '8 сеткой (4 × 2)', ic: 'M3 4h18v16H3zM7.5 4v16M12 4v16M16.5 4v16M3 12h18' },
  '10': { n: 10, cols: 'repeat(5, 1fr)', rows: '1fr 1fr', name: '10 сеткой (5 × 2)', ic: 'M3 4h18v16H3zM6.6 4v16M10.2 4v16M13.8 4v16M17.4 4v16M3 12h18' },
};
const MAX_CHARTS = 10;
// какое это окно: главное или дополнительное (у каждого своя раскладка, остальное общее)
const WIN_ID = (() => { try { return new URLSearchParams(location.search).get('w') || 'main'; } catch { return 'main'; } })();
const PER_WIN = ['layout', 'active', 'charts', 'curLayout'];
// на телефоне боковая панель открывается/закрывается сама по себе — компьютеру это не передаём
const PHONE_LOCAL = ['sideOpen', 'sidePanel'];
// Темы оформления: интерфейс + цвета графика. «Мой стиль» — снимок пользовательских настроек.
const STYLE_KEYS = ['theme', 'bgColor', 'gridColor', 'axisColor', 'crossColor', 'upColor', 'downColor', 'wickUp', 'wickDn', 'borderUp', 'borderDn', 'candleBorder', 'volAlpha'];
const THEMES = [
  { id: 'calm', name: 'Тяжёлый день', ui: 'calm', bg: '#1e1d20', up: '#8fbf9f', dn: '#cc8f8f', bu: '#8fbf9f', bd: '#cc8f8f', calm: true },
  { id: 'dark', name: 'Классика тёмная', ui: 'dark', bg: '#0c1119', up: '#1fb386', dn: '#ee4d63' },
  { id: 'light', name: 'Светлая', ui: 'light', bg: '#ffffff', up: '#12a37f', dn: '#e04359' },
  { id: 'midnight', name: 'Полночь', ui: 'midnight', bg: '#060a18', up: '#3ddc97', dn: '#ff5c7a' },
  { id: 'graphite', name: 'Графит', ui: 'graphite', bg: '#121212', up: '#d9d9d9', dn: '#6e6e6e', bu: '#d9d9d9', bd: '#9a9a9a' },
  { id: 'ocean', name: 'Океан', ui: 'ocean', bg: '#021118', up: '#2fd3c6', dn: '#ff7a6b' },
  { id: 'matrix', name: 'Матрица', ui: 'matrix', bg: '#000000', up: '#39ff6a', dn: '#000000', bu: '#39ff6a', bd: '#2fae4f' },
  { id: 'sunset', name: 'Закат', ui: 'sunset', bg: '#120b10', up: '#ffb35a', dn: '#d0507e' },
];
const CANDLE_PRESETS = [
  { name: 'Классика', up: '#1fb386', dn: '#ee4d63', bu: '#1fb386', bd: '#ee4d63' },
  { name: 'Пустые растущие', up: 'bg', dn: '#ee4d63', bu: '#1fb386', bd: '#ee4d63' },
  { name: 'Мягкая', up: '#4f9f8d', dn: '#c9616e', bu: '#4f9f8d', bd: '#c9616e' },
  { name: 'Монохром', up: '#e4e7ee', dn: '#5a6373', bu: '#e4e7ee', bd: '#8a93a5' },
  { name: 'Синий / оранжевый', up: '#3b8cf5', dn: '#f08b3a', bu: '#3b8cf5', bd: '#f08b3a' },
  { name: 'Яркая', up: '#00d18b', dn: '#ff3d5e', bu: '#00d18b', bd: '#ff3d5e' },
];
const CHART_TYPES = [['candles', 'Японские свечи'], ['hollow', 'Полые свечи'], ['heikin', 'Хайкин-Аши'], ['bars', 'Бары (OHLC)'], ['line', 'Линия'], ['area', 'Область']];
const ALL_IV = ['1m', '3m', '5m', '15m', '30m', '1h', '2h', '4h', '6h', '8h', '12h', '1d', '3d', '1w', '1M'];
const CURSORS = { cross: { name: 'Перекрестие', icon: 'cross' }, dot: { name: 'Точка', icon: 'dot' }, arrow: { name: 'Курсор-стрелка', icon: 'arrow' }, eraser: { name: 'Ластик', icon: 'eraser' } };

const App = {
  win: WIN_ID, isMain: WIN_ID === 'main', isPhone: !!window.ORBITA_PHONE, mainPer: {},
  state: null, charts: [], prices: {}, changes: {}, tool: 'cross', th: {}, undoStack: [], redoStack: [],

  defaults() {
    const mk = (symbol, interval) => ({ symbol, interval, type: 'candles', log: false, mainWeight: 3, indicators: [IND.make('VOL'), IND.make('EMA', { params: { length: 21, source: 'close' } })] });
    return {
      v: 1, layout: '1', active: 0,
      charts: [mk('BTCUSDT', '1h'), mk('ETHUSDT', '1h'), mk('SOLUSDT', '1h'), mk('BNBUSDT', '1h'), mk('XRPUSDT', '1h'), mk('DOGEUSDT', '1h'),
        mk('ADAUSDT', '1h'), mk('LINKUSDT', '1h'), mk('AVAXUSDT', '1h'), mk('TONUSDT', '1h')],
      watchlist: ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'TONUSDT', 'LINKUSDT', 'AVAXUSDT', 'TRXUSDT', 'DOTUSDT', 'LTCUSDT', 'SUIUSDT'],
      favIntervals: ['1m', '5m', '15m', '1h', '4h', '1d', '1w'],
      favTools: ['hray', 'trend', 'curve', 'rect', 'channel', 'hline', 'pitchfork', 'path', 'brush', 'highlighter'],
      alerts: [], alertLog: [], drawings: {}, toolStyles: {}, layouts: [], curLayout: null,
      settings: { theme: 'dark', syncSymbol: false, syncInterval: false, syncCross: true, magnet: false, stay: false, hideDrawings: false, sidePanel: 'watch', sideOpen: true, grid: true, watermark: true, countdown: true, sound: true, groupSel: {} },
    };
  },

  init() {
    const def = this.defaults(), saved = U.Store.load();
    this.state = def;
    if (saved && saved.v === 1) {
      Object.assign(this.state, saved);
      this.state.settings = { ...def.settings, ...saved.settings };
      while (this.state.charts.length < MAX_CHARTS) this.state.charts.push(def.charts[this.state.charts.length]);
      this.state.toolStyles = saved.toolStyles || {};
      this.state.layouts = saved.layouts || [];
      if (!saved.favTools) this.state.favTools = def.favTools;
      if (!this.state.settings.brushFav) { ['brush', 'highlighter'].forEach(t => { if (!this.state.favTools.includes(t)) this.state.favTools.push(t); }); this.state.settings.brushFav = true; }
    }
    // дополнительное окно: своя раскладка и свои графики
    PER_WIN.forEach(k => { this.mainPer[k] = this.state[k]; });
    if (!this.isMain) {
      const w = saved && saved.wins && saved.wins[WIN_ID];
      if (w && Array.isArray(w.charts) && w.charts.length) {
        this.state.layout = w.layout || '1'; this.state.active = w.active || 0; this.state.charts = w.charts; this.state.curLayout = w.curLayout || null;
      } else { // новое окно открывается с активным графиком главного окна
        const cs = JSON.parse(JSON.stringify(this.state.charts)), a = Math.min(this.state.active || 0, cs.length - 1);
        cs.unshift(cs.splice(a, 1)[0]);
        this.state.charts = cs; this.state.layout = '1'; this.state.active = 0; this.state.curLayout = null;
      }
      while (this.state.charts.length < MAX_CHARTS) this.state.charts.push(def.charts[this.state.charts.length]);
      document.body.classList.add('secondary');
      document.title = this.isPhone ? 'Orbita' : 'Orbita — дополнительное окно';
      if (this.isPhone) { this.state.settings.sideOpen = false; this.state.settings.sidePanel = 'watch'; }
    }
    delete this.state.wins;
    this.migrateDrawings();
    // ОИ панелью больше не показываем — вместо неё карточка
    for (const c of this.state.charts) if (c && c.indicators && c.indicators.some(i => i.type === 'OI')) { c.indicators = c.indicators.filter(i => i.type !== 'OI'); c.oiCard = true; }
    this.applyTheme();
    this.buildTopbar();
    this.buildTools();
    Panels.init();
    this.buildLayout();
    this.buildFavBar();
    this.bindKeys();
    Data.onMode(m => this.onMode(m));
    this.onMode(Data.mode);
    this.restartTicker();
    Calendar.init();
    Acct.init();
    Upd.init();
    Phone.init();
    if (this.isMain) Voice.init(); // голос, музыка и мысли — только в главном окне, чтобы не звучало дважды
    if (window.orbita && window.orbita.onStateChanged) {
      const sync = U.debounce(() => this.onExternalState(), 120);
      window.orbita.onStateChanged(sync);
    }
    setInterval(() => this.charts.forEach(c => c.invalidate()), 1000);
    setInterval(() => this.charts.forEach(c => { if (c.cfg.liq && !c.replay) c.liqLoad(); if (c.hasOI()) c.oiLoad(true); }), 5 * 60 * 1000);
    setInterval(() => this.charts.forEach(c => c.oiTick()), 60 * 1000);
    setInterval(() => this.charts.forEach(c => { if (c.cfg.frCard && !c.replay) Funding.refresh(c); }), 60 * 1000);
    setInterval(() => { this.charts.forEach(c => c.corrUpdate()); Corr.refreshWatch(); }, 5 * 60 * 1000);
    window.addEventListener('beforeunload', () => this.save());
    const resyncAll = () => this.charts.forEach(c => c.resync());
    document.addEventListener('visibilitychange', () => { if (!document.hidden) resyncAll(); });
    window.addEventListener('online', () => { this.tickKey = null; this.restartTicker(); resyncAll(); });
    window.addEventListener('focus', () => { if (Date.now() - (this._lastResync || 0) > 20000) { this._lastResync = Date.now(); resyncAll(); } });
    // страховка: раз в 2 минуты сверяем последние свечи; если таймер «проспал» (сон ПК) — полная докачка
    let lastBeat = Date.now();
    setInterval(() => {
      const now = Date.now(), slept = now - lastBeat > 30000; lastBeat = now;
      if (slept) { this.tickKey = null; this.restartTicker(); resyncAll(); }
    }, 5000);
    setInterval(() => this.charts.forEach(c => c.resync(5)), 120000);
    setInterval(() => {
      const now = Date.now();
      for (const c of this.charts) {
        c.updateFresh && c.updateFresh();
        if (!c.bars.length || c.replay || c.resyncing) continue;
        if (now - (c.lastData || 0) > 1800 && now - (c.lastFetch || 0) > 900) { c.lastFetch = now; c.resync(c.lastData && now - c.lastData > 120000 ? 300 : 3); }
        // если сокет молчит долго — пересоздаём подписку
        if (now - (c.lastData || 0) > 45000 && now - (c.lastResub || 0) > 45000) {
          c.lastResub = now; const tok = c.tok;
          try { c.sub && c.sub.close(); } catch { /* */ }
          c.sub = Data.subscribe(c.sym, c.iv, k => { if (tok === c.tok) c.onKline(k); }, () => { if (tok === c.tok) c.resync(); }, (pr, q, T) => { if (tok === c.tok) c.onTrade(pr, q, T); });
        }
      }
      // список наблюдения: если цены не приходят 30 с — переподключаем
      if (now - (this._lastTick || now) > 30000) { this._lastTick = now; this.tickKey = null; this.restartTicker(); }
    }, 1000);
    window.addEventListener('resize', () => this.updateDrawbar());
    this.saveSoon = U.debounce(() => this.save(), 400);
  },
  // сохраняем так, чтобы не затереть раскладки других окон
  save() {
    const disk = U.Store.load() || {}, out = Object.assign({}, this.state);
    if (this.isMain) out.wins = disk.wins || {};
    else {
      PER_WIN.forEach(k => { out[k] = disk[k] !== undefined ? disk[k] : this.mainPer[k]; });
      if (this.isPhone) { const ds = disk.settings || {}; out.settings = Object.assign({}, this.state.settings); PHONE_LOCAL.forEach(k => { if (k in ds) out.settings[k] = ds[k]; else delete out.settings[k]; }); }
      out.wins = Object.assign({}, disk.wins || {}, { [WIN_ID]: { layout: this.state.layout, active: this.state.active, charts: this.state.charts, curLayout: this.state.curLayout } });
    }
    U.Store.save(out);
  },
  // другое окно что-то сохранило — подтягиваем общие данные (рисунки, алерты, настройки, список наблюдения)
  onExternalState() {
    if (this.charts.some(c => c.drag || c.creating)) { setTimeout(() => this.onExternalState(), 400); return; }
    const disk = U.Store.load(); if (!disk) return;
    const skip = new Set([...PER_WIN, 'wins', 'savedAt', 'v']);
    const before = JSON.stringify([this.state.settings.theme, this.state.watchlist, this.state.alerts.length]);
    for (const k of Object.keys(disk)) if (!skip.has(k)) this.state[k] = disk[k];
    const keep = this.isPhone ? Object.fromEntries(PHONE_LOCAL.map(k => [k, this.state.settings[k]])) : null;
    this.state.settings = { ...this.defaults().settings, ...(disk.settings || {}), ...(keep || {}) };
    this.migrateDrawings();
    for (const c of this.charts) { if (c.selected && !this.getDrawings(c.sym).includes(c.selected)) c.selected = null; c.invalidate(); }
    if (before !== JSON.stringify([this.state.settings.theme, this.state.watchlist, this.state.alerts.length])) { this.applyTheme(); this.restartTicker(); }
    try { Panels.render(); } catch { /* */ }
    this.buildFavBar(); this.buildTools(); this.updateDrawbar();
  },
  // быстрый переход по списку наблюдения стрелками
  watchStep(dir, repeat) {
    const list = this.state.watchlist || [], n = list.length, ch = this.active(); if (!n || !ch) return;
    const now = Date.now(); if (repeat && now - (this._wsT || 0) < 140) return; this._wsT = now;
    let i = list.indexOf(ch.sym);
    if (i < 0) { const k = this.dKey(ch.sym); i = list.findIndex(s => this.dKey(s) === k); }
    const next = list[i < 0 ? (dir > 0 ? 0 : n - 1) : (i + dir + n) % n];
    if (!next || next === ch.sym) return;
    this.setSymbol(next, ch);
    requestAnimationFrame(() => { const r = document.querySelector(`.wl-row[data-s="${CSS.escape(next)}"]`); if (r) r.scrollIntoView({ block: 'nearest' }); });
  },
  newWindow() {
    if (!(window.orbita && window.orbita.newWindow)) { U.toast('Новое окно доступно в программе для Windows', 'info'); return; }
    this.save();
    window.orbita.newWindow();
  },
  saveSoon() { /* заменяется в init */ },

  // ---------- тема ----------
  applyTheme() {
    const st = this.state.settings, root = document.documentElement;
    root.dataset.theme = st.theme;
    root.style.removeProperty('--chart-bg');
    const cs = getComputedStyle(root), v = n => cs.getPropertyValue(n).trim();
    this.th = { bg: v('--bg'), chartBg: v('--chart-bg'), grid: v('--grid'), text: v('--text'), textDim: v('--text-dim'), border: v('--border'), up: v('--up'), down: v('--down'), cross: v('--cross'), labelBg: v('--label-bg'), labelText: v('--label-text'), watermark: v('--watermark'), line: v('--line'), accent: v('--accent') };
    if (st.bgColor) { this.th.chartBg = st.bgColor; root.style.setProperty('--chart-bg', st.bgColor); }
    if (st.gridColor) this.th.grid = U.hexA(st.gridColor, 0.35);
    if (st.axisColor) this.th.textDim = st.axisColor;
    if (st.crossColor) this.th.cross = st.crossColor;
    this.charts.forEach(c => { c.legendDirty = true; c.invalidate(); });
    const tb = $('#themeBtn'); if (tb) tb.innerHTML = U.icon(this.state.settings.theme === 'light' ? 'moon' : 'sun');
  },
  styleSnapshot() { const st = this.state.settings, o = {}; STYLE_KEYS.forEach(k => { o[k] = st[k]; }); return o; },
  applyStyle(snap) { const st = this.state.settings; STYLE_KEYS.forEach(k => { if (snap[k] === undefined) delete st[k]; else st[k] = snap[k]; }); if (!st.theme) st.theme = 'dark'; this.applyTheme(); this.saveSoon(); },
  setThemePreset(id) {
    const st = this.state.settings;
    if (!st.myStyle) { st.myStyle = this.styleSnapshot(); U.toast('Ваше текущее оформление сохранено как «Мой стиль» — вернуть можно в любой момент', 'info', 4500); }
    if (id === 'mine') { this.applyStyle(st.myStyle); st.themeId = 'mine'; return; }
    const T = THEMES.find(t => t.id === id); if (!T) return;
    STYLE_KEYS.forEach(k => { if (k !== 'theme') delete st[k]; });
    st.theme = T.ui;
    if (T.bu) { Object.assign(st, { upColor: T.up, downColor: T.dn, borderUp: T.bu, borderDn: T.bd, wickUp: T.bu, wickDn: T.bd, candleBorder: true }); }
    st.volAlpha = T.calm ? 0.22 : undefined; if (!T.calm) delete st.volAlpha;
    st.themeId = id;
    this.applyTheme(); this.saveSoon();
    if (T.calm) U.toast('Тяжёлый день. Выдохните — здесь всё мягко и спокойно.', 'info', 4000);
  },
  toggleTheme() { this.setThemePreset(this.state.settings.theme === 'light' ? (this.state.settings.myStyle && this.state.settings.myStyle.theme !== 'light' ? 'mine' : 'dark') : 'light'); },
  onMode(m) {
    const el = $('#netStatus');
    el.className = 'net ' + m;
    el.innerHTML = m === 'live' ? `<span class="dot"></span>Онлайн` : m === 'demo' ? `<span class="dot"></span>Демо-данные` : `<span class="dot"></span>Подключение…`;
    el.title = m === 'demo' ? 'Binance недоступен — показываются сгенерированные котировки. Нажмите, чтобы переподключиться.' : 'Источник данных: публичный API Binance';
    if (m === 'demo' || m === 'live') { this.tickKey = null; this.restartTicker(); }
  },

  // ---------- верхняя панель ----------
  buildTopbar() {
    $('#symBtn').onclick = () => this.openSymbolSearch();
    $('#ivMore').onclick = e => this.intervalMenu(e.currentTarget);
    $('#typeBtn').onclick = e => this.typeMenu(e.currentTarget);
    $('#indBtn').onclick = () => this.openIndicatorPicker();
    $('#alertBtn').onclick = () => Alerts.openDialog();
    $('#layoutBtn').onclick = e => this.layoutMenu(e.currentTarget);
    $('#winBtn').innerHTML = U.icon('newWin', 18);
    $('#winBtn').onclick = () => this.newWindow();
    $('#replayBtn').onclick = () => this.replayToggle();
    $('#voiceBtn').onclick = () => Voice.openSettings();
    $('#savedBtn').onclick = e => this.savedMenu(e.currentTarget);
    $('#undoBtn').onclick = () => this.undo();
    $('#redoBtn').onclick = () => this.redo();
    $('#shotBtn').onclick = () => this.screenshot();
    $('#fsBtn').onclick = () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {}); };
    $('#themeBtn').onclick = () => this.toggleTheme();
    $('#setBtn').onclick = () => this.openChartSettings();
    $('#netStatus').onclick = () => { if (Data.mode === 'demo') { Data.retry(); this.charts.forEach(c => c.load()); } };
    this.renderIntervals();
  },
  renderIntervals() {
    const box = $('#intervals'), cur = this.active() ? this.active().iv : '1h';
    if (this.isPhone) { // телефон: одна кнопка-«папка» с текущим таймфреймом, список открывается по нажатию
      box.innerHTML = `<button class="tb iv on tf-fold" title="Таймфрейм">${U.ivShort(cur)}<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>`;
      box.firstChild.onclick = e => this.intervalMenu(e.currentTarget);
      return;
    }
    const favs = ALL_IV.filter(iv => this.state.favIntervals.includes(iv));
    box.innerHTML = favs.map(iv => `<button class="tb iv${iv === cur ? ' on' : ''}" data-iv="${iv}" title="${U.IV_NAMES[iv]}">${U.ivShort(iv)}</button>`).join('');
    if (!favs.includes(cur)) box.innerHTML += `<button class="tb iv on" data-iv="${cur}">${U.ivShort(cur)}</button>`;
    $$('button', box).forEach(b => b.onclick = () => this.setInterval(b.dataset.iv));
  },
  intervalMenu(anchor) {
    const cur = this.active().iv;
    if (this.isPhone) { // телефон: избранные сверху, потом все — листаются пальцем
      const fav = ALL_IV.filter(iv => this.state.favIntervals.includes(iv)), rest = ALL_IV.filter(iv => !fav.includes(iv));
      const row = iv => ({ label: U.IV_NAMES[iv], active: iv === cur, action: () => this.setInterval(iv) });
      const el = U.dropdown(anchor, [...(fav.length ? [{ header: 'Избранные' }, ...fav.map(row), '-'] : []), { header: 'Все таймфреймы' }, ...rest.map(row)]);
      if (el) { el.classList.add('tf-menu'); const a = el.querySelector('.menu-item.active'); if (a) a.scrollIntoView({ block: 'center' }); }
      return;
    }
    U.dropdown(anchor, [{ header: 'Интервалы' }, ...ALL_IV.map(iv => ({
      label: U.IV_NAMES[iv], active: iv === cur, action: () => this.setInterval(iv),
      side: { icon: 'star', active: this.state.favIntervals.includes(iv), keepOpen: true, action: () => {
        const f = this.state.favIntervals;
        this.state.favIntervals = f.includes(iv) ? f.filter(x => x !== iv) : [...f, iv];
        this.renderIntervals(); this.saveSoon();
      } },
    }))]);
  },
  typeMenu(anchor) {
    const ch = this.active();
    U.dropdown(anchor, [...CHART_TYPES.map(([t, n]) => ({ label: n, icon: t, active: ch.cfg.type === t, action: () => this.setType(t) })), '-',
      { label: 'Логарифмическая шкала', checked: !!ch.cfg.log, icon: 'line', action: () => this.toggleLog(ch) }]);
  },
  layoutMenu(anchor) {
    const st = this.state.settings;
    const items = [{ header: 'Раскладка' }, ...Object.entries(LAYOUTS).map(([k, L]) => ({ label: L.name, icon: null, active: this.state.layout === k, action: () => this.setLayout(k), _ic: L.ic })), '-',
      { label: 'Синхронизировать символ', checked: st.syncSymbol, action: () => { st.syncSymbol = !st.syncSymbol; this.saveSoon(); } },
      { label: 'Синхронизировать интервал', checked: st.syncInterval, action: () => { st.syncInterval = !st.syncInterval; this.saveSoon(); } },
      { label: 'Синхронизировать перекрестие', checked: st.syncCross, action: () => { st.syncCross = !st.syncCross; this.saveSoon(); } }];
    const el = U.dropdown(anchor, items);
    // иконки раскладок
    let k = 0;
    $$('.menu-item', el).forEach(row => {
      const it = items.filter(x => x !== '-' && !x.header)[k++];
      if (it && it._ic) row.querySelector('.mi-ic').innerHTML = `<svg class="ic" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="${it._ic}"/></svg>`;
    });
  },
  updateTopbar() {
    const ch = this.active(); if (!ch) return;
    const lb = Data.label(ch.sym);
    $('#symBtn').innerHTML = `${U.icon('search', 16)}<span>${lb.base}<span class="q">${lb.quote}</span></span><span class="ex-tag">${lb.exName}${lb.kind === 'Фьючерсы' ? ' F' : ''}</span>`;
    this.renderIntervals();
    $('#typeBtn').innerHTML = U.icon(ch.cfg.type === 'heikin' ? 'heikin' : ch.cfg.type);
    $('#typeBtn').title = 'Тип графика: ' + (CHART_TYPES.find(x => x[0] === ch.cfg.type) || [0, ''])[1];
    const LL = LAYOUTS[this.state.layout] || LAYOUTS['1'];
    $('#layoutBtn').innerHTML = `<svg class="ic" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="${LL.ic}"/></svg><span>${LL.n}</span>`;
    const cur = this.state.layouts.find(l => l.id === this.state.curLayout);
    $('#savedBtn').innerHTML = `${U.icon('save', 17)}<span>${U.esc(cur ? cur.name : 'Раскладки')}</span>`;
    document.title = `${lb.short} · ${lb.exName} · ${U.ivShort(ch.iv)} — Orbita Terminal`;
  },

  // ---------- левая панель инструментов ----------
  buildTools() {
    const nav = $('#tools'); nav.innerHTML = '';
    const st = this.state.settings, gs = st.groupSel || (st.groupSel = {});
    const groups = [{ id: 'cursor', name: 'Курсоры', tools: Object.keys(CURSORS), sec: [['Курсоры', Object.keys(CURSORS)]] }, ...DRAW.GROUPS];
    const info = t => CURSORS[t] || DRAW.TOOLS[t];
    for (const g of groups) {
      const cur = g.tools.includes(gs[g.id]) ? gs[g.id] : g.tools[0];
      const el = U.h(`<div class="tgroup" data-g="${g.id}"><button class="tbtn" title="${U.esc(info(cur).name)}">${U.icon(info(cur).icon, 20)}</button><button class="tmore" title="${U.esc(g.name)}"></button></div>`);
      el.querySelector('.tbtn').onclick = () => this.setTool(g.tools.includes(gs[g.id]) ? gs[g.id] : g.tools[0]);
      el.querySelector('.tmore').onclick = () => {
        const list = U.h(`<div class="fly"></div>`);
        for (const [secName, secTools] of g.sec) {
          list.appendChild(U.h(`<div class="menu-head">${U.esc(secName)}</div>`));
          for (const t of secTools) {
          const T = info(t);
          const fav = this.state.favTools.includes(t), canFav = !CURSORS[t];
          const row = U.h(`<div class="menu-item${this.tool === t ? ' active' : ''}"><span class="mi-ic">${U.icon(T.icon, 18)}</span><span class="mi-label">${U.esc(T.name)}</span>${T.key ? `<span class="mi-sc">${T.key}</span>` : ''}${canFav ? `<button class="mi-side${fav ? ' on' : ''}" title="В избранное">${U.icon('star', 14)}</button>` : ''}</div>`);
          row.onclick = e => {
            const st2 = e.target.closest('.mi-side');
            if (st2) { e.stopPropagation(); this.toggleFavTool(t); st2.classList.toggle('on'); return; }
            gs[g.id] = t; this.setTool(t); U.closeMenus(); this.buildTools(); this.saveSoon();
          };
          list.appendChild(row);
          }
        }
        U.popover(el, list, this.isPhone ? 'top' : 'right');
      };
      nav.appendChild(el);
    }
    nav.appendChild(U.h('<div class="tsep"></div>'));
    const aiB = U.h(`<button class="tbtn ai-btn" id="tAI" title="AI-разметка: уровни и трендовые линии (Alt+L)
Правый клик — убрать разметку"><span>AI</span></button>`);
    const aiRun = async () => { if (aiB.classList.contains('busy')) return; aiB.classList.add('busy'); try { await AI.run(this, this.active()); } finally { aiB.classList.remove('busy'); } };
    aiB.onclick = () => {
      const ch = this.active();
      // телефон: правой кнопки нет — если разметка уже есть, предлагаем обновить или убрать
      if (this.isPhone && ch && this.getDrawings(ch.sym).some(d => d.ai)) {
        const list = U.h(`<div class="fly"><div class="menu-head">AI-разметка</div><div class="menu-item" data-a="run"><span class="mi-label">Обновить разметку</span></div><div class="menu-item" data-a="clear"><span class="mi-label">Убрать разметку</span></div></div>`);
        list.onclick = e => { const a = e.target.closest('[data-a]'); if (!a) return; U.closeMenus(); if (a.dataset.a === 'run') aiRun(); else AI.clear(this, ch); };
        U.popover(aiB, list, 'top');
        return;
      }
      aiRun();
    };
    aiB.oncontextmenu = e => { e.preventDefault(); AI.clear(this, this.active()); };
    nav.appendChild(aiB);
    const tog = (id, icon, title, on, fn) => { const b = U.h(`<button class="tbtn${on ? ' on' : ''}" id="${id}" title="${title}">${U.icon(icon, 20)}</button>`); b.onclick = fn; nav.appendChild(b); };
    tog('tLiq', 'flame', 'Карта ликвидаций (модель по открытому интересу)', !!(this.active() && this.active().cfg.liq), () => this.toggleLiq());
    const oiOn = !!(this.active() && this.active().hasOI());
    const oiB = U.h(`<button class="tbtn oi-btn${oiOn ? ' on' : ''}" id="tOI" title="Открытый интерес (ОИ) — Binance фьючерсы"><span>ОИ</span></button>`);
    oiB.onclick = () => this.toggleOI(); nav.appendChild(oiB);
    const frOn = !!(this.active() && this.active().cfg.frCard);
    const frB = U.h(`<button class="tbtn fr-btn${frOn ? ' on' : ''}" id="tFR" title="Фандинг — ставка финансирования фьючерсов: Binance, Bybit, OKX, Gate"><span>F%</span></button>`);
    frB.onclick = () => this.toggleFR(); nav.appendChild(frB);
    tog('tNews', 'news', 'Свежие новости по этой монете', typeof News !== 'undefined' && News.open, () => News.toggle());
    tog('tRuler', 'priceRange', 'Линейка (или Shift + перетаскивание)', this.tool === 'dprange', () => this.setTool(this.tool === 'dprange' ? 'cross' : 'dprange'));
    tog('tZoomIn', 'zoomIn', 'Приблизить', false, () => this.active().zoom(1.25));
    nav.appendChild(U.h('<div class="tsep"></div>'));
    tog('tFav', 'star', 'Панель избранных инструментов', st.favShow !== false, () => { st.favShow = st.favShow === false; this.saveSoon(); this.buildTools(); this.buildFavBar(); });
    tog('tMagnet', 'magnet', 'Магнит: привязка к ценам OHLC', st.magnet, () => { st.magnet = !st.magnet; this.saveSoon(); this.buildTools(); });
    tog('tStay', 'stay', 'Оставаться в режиме рисования', st.stay, () => { st.stay = !st.stay; this.saveSoon(); this.buildTools(); });
    const ds = this.active() ? this.getDrawings(this.active().sym) : [];
    const allLocked = ds.length && ds.every(d => d.locked);
    tog('tLock', allLocked ? 'lock' : 'unlock', 'Заблокировать все рисунки', allLocked, () => {
      const ch = this.active(); this.pushUndo(ch.sym);
      const arr = this.getDrawings(ch.sym), v = !arr.every(d => d.locked); arr.forEach(d => d.locked = v);
      this.drawingsChanged(ch.sym, true); this.buildTools();
    });
    tog('tHide', st.hideDrawings ? 'eyeOff' : 'eye', 'Скрыть все рисунки', st.hideDrawings, () => { st.hideDrawings = !st.hideDrawings; this.charts.forEach(c => c.invalidate()); this.saveSoon(); this.buildTools(); });
    tog('tTrash', 'trash', 'Удалить все рисунки', false, () => this.deleteAllDrawings());
    nav.appendChild(U.h('<div class="grow"></div>'));
    tog('tZoomOut', 'zoomOut', 'Отдалить', false, () => this.active().zoom(0.8));
    this.highlightTool();
  },
  toggleFavTool(t) {
    const f = this.state.favTools;
    this.state.favTools = f.includes(t) ? f.filter(x => x !== t) : [...f, t];
    if (this.state.favTools.length && this.state.settings.favShow === false) this.state.settings.favShow = true;
    this.saveSoon(); this.buildFavBar(); this.buildTools();
  },
  buildFavBar() {
    let bar = $('#favbar');
    const st = this.state.settings, list = this.state.favTools.filter(t => DRAW.TOOLS[t]);
    if (!bar) { bar = U.h('<div id="favbar"></div>'); $('#center').appendChild(bar); }
    if (st.favShow === false || !list.length) { bar.hidden = true; return; }
    bar.hidden = false;
    bar.innerHTML = `<span class="fav-grip" title="Перетащите, чтобы переместить">${U.icon('grip', 16)}</span>` +
      list.map(t => `<button class="fav-btn${this.tool === t ? ' on' : ''}" data-t="${t}" title="${U.esc(DRAW.TOOLS[t].name)} (правый клик — убрать из избранного)">${U.icon(DRAW.TOOLS[t].icon, 20)}</button>`).join('');
    const place = () => {
      const c = $('#center').getBoundingClientRect(), b = bar.getBoundingClientRect();
      const pos = st.favPos || { x: (c.width - b.width) / 2, y: 60 };
      bar.style.left = U.clamp(pos.x, 0, Math.max(0, c.width - b.width)) + 'px';
      bar.style.top = U.clamp(pos.y, 0, Math.max(0, c.height - b.height)) + 'px';
    };
    place();
    bar.onclick = e => { const b = e.target.closest('[data-t]'); if (b) this.setTool(this.tool === b.dataset.t ? 'cross' : b.dataset.t); };
    bar.oncontextmenu = e => { e.preventDefault(); const b = e.target.closest('[data-t]'); if (b) this.toggleFavTool(b.dataset.t); };
    const grip = $('.fav-grip', bar);
    grip.onpointerdown = e => {
      grip.setPointerCapture(e.pointerId);
      const c = $('#center').getBoundingClientRect(), b0 = bar.getBoundingClientRect(), dx = e.clientX - b0.left, dy = e.clientY - b0.top;
      grip.onpointermove = ev => { st.favPos = { x: ev.clientX - c.left - dx, y: ev.clientY - c.top - dy }; place(); };
      grip.onpointerup = () => { grip.onpointermove = null; this.saveSoon(); };
    };
    if (!this._favRO) { this._favRO = true; window.addEventListener('resize', () => this.buildFavBar()); }
  },
  highlightTool() {
    const gs = this.state.settings.groupSel || {};
    $$('#tools .tgroup').forEach(el => {
      const g = el.dataset.g;
      const tools = g === 'cursor' ? Object.keys(CURSORS) : DRAW.GROUPS.find(x => x.id === g).tools;
      el.classList.toggle('on', tools.includes(this.tool));
      const cur = tools.includes(this.tool) ? this.tool : (tools.includes(gs[g]) ? gs[g] : tools[0]);
      const T = CURSORS[cur] || DRAW.TOOLS[cur];
      el.querySelector('.tbtn').innerHTML = U.icon(T.icon, 20);
      el.querySelector('.tbtn').title = T.name;
    });
    $$('#favbar .fav-btn').forEach(b => b.classList.toggle('on', b.dataset.t === this.tool));
    const rb = $('#tRuler'); if (rb) rb.classList.toggle('on', this.tool === 'dprange');
  },
  setTool(t) {
    this.tool = t;
    const g = t in CURSORS ? 'cursor' : (DRAW.GROUPS.find(x => x.tools.includes(t)) || {}).id;
    if (g) this.state.settings.groupSel[g] = t;
    this.charts.forEach(c => { if (c.creating && c.creating.d.type !== t) c.creating = null; c.invalidate(); });
    this.highlightTool();
  },

  // ---------- раскладка и графики ----------
  buildLayout() {
    this.charts.forEach(c => c.destroy());
    this.charts = [];
    const L = LAYOUTS[this.state.layout] || LAYOUTS['1'], g = $('#charts');
    g.innerHTML = '';
    g.style.gridTemplateColumns = L.cols; g.style.gridTemplateRows = L.rows;
    g.classList.toggle('n8', L.n === 8); g.classList.toggle('n10', L.n === 10);
    for (let i = 0; i < L.n; i++) {
      const cell = U.h('<div class="cell"></div>');
      g.appendChild(cell);
      this.charts.push(new Chart(this, cell, this.state.charts[i], i));
    }
    this.applySpans(L);
    if (this.state.active >= L.n) this.state.active = 0;
    this.maxed = null; g.classList.remove('maxed');
    this.sideForce = false;
    this.updateMaxButtons();
    this.applySideAuto();
    this._activeShown = null;
    this.setActive(this.charts[this.state.active]);
  },
  // растягивание ячеек: «большой + 2» и «3 сверху + 2 снизу»
  applySpans(L, off) {
    this.charts.forEach((c, i) => {
      c.cell.style.gridRow = !off && L.span && i === 0 ? 'span 2' : '';
      c.cell.style.gridColumn = !off && L.spans ? `span ${L.spans[i]}` : '';
    });
  },
  // развернуть один график на весь экран и вернуть обратно
  toggleMax(ch) {
    if (this.charts.length < 2) return;
    const g = $('#charts'), L = LAYOUTS[this.state.layout] || LAYOUTS['1'];
    if (this.maxed) {
      this.maxed.cell.classList.remove('maxed');
      g.classList.remove('maxed');
      g.style.gridTemplateColumns = L.cols; g.style.gridTemplateRows = L.rows;
      this.applySpans(L);
      this.maxed = null;
    } else {
      this.maxed = ch;
      g.classList.add('maxed'); ch.cell.classList.add('maxed');
      g.style.gridTemplateColumns = '1fr'; g.style.gridTemplateRows = '1fr';
      this.applySpans(L, true);
      this.setActive(ch);
    }
    this.updateMaxButtons();
    this.applySideAuto();
    this.updateDrawbar();
    requestAnimationFrame(() => this.charts.forEach(c => { c.resize(); }));
  },
  // при 4, 6, 8 и 10 графиках список наблюдения прячется; при развёрнутом графике возвращается
  applySideAuto() {
    const hide = this.charts.length >= 4 && !this.maxed && !this.sideForce && this.state.settings.autoHideSide !== false;
    const side = $('#side'), was = side.classList.contains('auto-hidden');
    side.classList.toggle('auto-hidden', hide);
    if (was && !hide) Panels.render();
  },
  updateMaxButtons() {
    const multi = this.charts.length > 1;
    this.charts.forEach(c => {
      const b = c.cell.querySelector('.cell-max'); if (!b) return;
      b.hidden = !multi;
      b.innerHTML = U.icon(this.maxed === c ? 'minimize' : 'fullscreen', 15);
      b.title = this.maxed === c ? `Вернуть ${this.charts.length} графиков (двойной клик или Esc)` : 'Развернуть на весь экран (или двойной клик по графику)';
    });
  },
  setLayout(k) { if (this.replayChart) this.replayStop(this.replayChart); this.state.layout = k; this.buildLayout(); this.restartTicker(); this.saveSoon(); },

  // ---------- сохранённые раскладки ----------
  snapshotLayout() { return { layout: this.state.layout, active: this.state.active, charts: JSON.parse(JSON.stringify(this.state.charts)) }; },
  savedMenu(anchor) {
    const L = this.state.layouts, cur = L.find(l => l.id === this.state.curLayout);
    const items = [
      { label: cur ? `Сохранить «${cur.name}»` : 'Сохранить раскладку…', icon: 'save', shortcut: 'Ctrl+S', action: () => this.saveLayout() },
      { label: 'Сохранить как новую…', icon: 'plus', action: () => this.saveLayout(true) },
    ];
    if (cur) items.push({ label: 'Переименовать…', icon: 'edit', action: async () => { const n = await U.prompt('Название раскладки', cur.name); if (n) { cur.name = n.trim() || cur.name; this.saveSoon(); this.updateTopbar(); } } });
    items.push('-', { header: L.length ? 'Мои раскладки' : 'Сохранённых раскладок пока нет' });
    for (const l of L.slice().sort((a, b) => b.time - a.time)) {
      const LL = LAYOUTS[l.layout] || LAYOUTS['1'];
      items.push({ label: `${l.name}  ·  ${LL.n} гр. · ${l.charts.slice(0, LL.n).map(c => Data.label(c.symbol).base).join(', ')}`, active: l.id === this.state.curLayout, action: () => this.loadLayout(l.id),
        side: { icon: 'trash', action: async () => { if (await U.confirm(`Удалить раскладку «${l.name}»?`, 'Удалить')) { this.state.layouts = this.state.layouts.filter(x => x !== l); if (this.state.curLayout === l.id) this.state.curLayout = null; this.saveSoon(); this.updateTopbar(); } } } });
    }
    U.dropdown(anchor, items);
  },
  async saveLayout(asNew) {
    let cur = !asNew && this.state.layouts.find(l => l.id === this.state.curLayout);
    if (!cur) {
      const def = `Раскладка ${this.state.layouts.length + 1}`;
      const n = await U.prompt('Название раскладки', def);
      if (n == null) return;
      cur = { id: U.uid(), name: n.trim() || def };
      this.state.layouts.push(cur);
    }
    Object.assign(cur, this.snapshotLayout(), { time: Date.now() });
    this.state.curLayout = cur.id;
    this.save(); this.updateTopbar();
    U.toast(`Раскладка «${cur.name}» сохранена`, 'info', 2000);
  },
  loadLayout(id) {
    const l = this.state.layouts.find(x => x.id === id); if (!l) return;
    if (this.replayChart) this.replayStop(this.replayChart);
    const snap = JSON.parse(JSON.stringify(l.charts));
    const def = this.defaults().charts;
    while (snap.length < MAX_CHARTS) snap.push(def[snap.length]);
    this.state.charts = snap; this.state.layout = l.layout; this.state.active = l.active || 0; this.state.curLayout = l.id;
    this.buildLayout(); this.restartTicker(); this.saveSoon();
    U.toast(`Открыта раскладка «${l.name}»`, 'info', 1800);
  },

  // ---------- повтор истории ----------
  replayToggle() {
    if (this.replayChart || this.replayPick) { this.replayStop(this.replayChart || this.replayPick); return; }
    const ch = this.active(); if (!ch || ch.bars.length < 50) { U.toast('Подождите, пока загрузится график'); return; }
    this.replayPick = ch;
    U.toast('Кликните по графику там, откуда начать повтор', 'info', 3500);
    this.renderReplayBar(); ch.invalidate();
  },
  replayBegin(ch, idx) {
    this.replayPick = null;
    if (this.replayChart && this.replayChart !== ch) this.replayStop(this.replayChart);
    this.replayPause();
    ch.replayStart(idx);
    this.replayChart = ch;
    this.renderReplayBar();
  },
  replayPlay() {
    const ch = this.replayChart; if (!ch) return;
    this.replayPause();
    const sp = this.state.settings.replaySpeed || 2;
    this._rpTimer = setInterval(() => { if (!ch.replayStep(1)) { this.replayPause(); U.toast('Повтор дошёл до текущего момента', 'info', 2500); } this.renderReplayBar(true); }, 1000 / sp);
    this.renderReplayBar();
  },
  replayPause() { clearInterval(this._rpTimer); this._rpTimer = null; this.renderReplayBar(true); },
  replayStop(ch, silent) {
    this.replayPause();
    if (this.replayPick) { const p = this.replayPick; this.replayPick = null; p.invalidate(); }
    if (ch && ch.replay && !silent) ch.replayEnd();
    else if (ch && silent) ch.replay = null;
    this.replayChart = null;
    this.renderReplayBar();
  },
  renderReplayBar(light) {
    let bar = $('#replaybar');
    if (!bar) { bar = U.h('<div id="replaybar"></div>'); $('#center').appendChild(bar); }
    const on = this.replayChart || this.replayPick;
    $('#replayBtn').classList.toggle('on', !!on);
    if (!on) { bar.hidden = true; return; }
    bar.hidden = false;
    const ch = this.replayChart, playing = !!this._rpTimer, sp = this.state.settings.replaySpeed || 2;
    const info = ch && ch.replay ? `${Data.label(ch.sym).short} · ${U.fmtTimeFull(ch.replay.full[ch.replay.idx].t, ch.ivMs)} · осталось ${ch.replay.full.length - 1 - ch.replay.idx} бар.` : 'Выберите на графике точку старта';
    if (light && bar.dataset.built && ch) { $('.rp-info', bar).textContent = info; $('[data-a=play]', bar).innerHTML = U.icon(playing ? 'pause' : 'play', 18); return; }
    bar.dataset.built = ch ? '1' : '';
    bar.innerHTML = `<span class="rp-title">${U.icon('replay', 16)} Повтор</span>
      <button class="ib" data-a="pick" title="Выбрать точку старта">${U.icon('pick', 18)}</button>
      <button class="ib" data-a="play" title="Старт / пауза (пробел)"${ch ? '' : ' disabled'}>${U.icon(playing ? 'pause' : 'play', 18)}</button>
      <button class="ib" data-a="step" title="Следующий бар (Shift + →)"${ch ? '' : ' disabled'}>${U.icon('stepFwd', 18)}</button>
      <select class="rp-speed" title="Скорость">${[0.5, 1, 2, 3, 5, 10].map(v => `<option value="${v}"${v === sp ? ' selected' : ''}>${v} бар/с</option>`).join('')}</select>
      <span class="rp-info">${U.esc(info)}</span>
      <button class="btn ghost sm" data-a="live" title="Вернуться к реальному времени">В реальное время</button>
      <button class="ib" data-a="exit" title="Выйти из повтора">${U.icon('close', 16)}</button>`;
    bar.onclick = e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a, c = this.replayChart;
      if (a === 'pick') { this.replayPause(); this.replayPick = c || this.active(); this.renderReplayBar(); U.toast('Кликните по графику — новая точка старта', 'info', 2500); }
      if (a === 'play' && c) { this._rpTimer ? this.replayPause() : this.replayPlay(); }
      if (a === 'step' && c) { this.replayPause(); c.replayStep(1); this.renderReplayBar(true); }
      if (a === 'live' || a === 'exit') this.replayStop(c || this.replayPick);
    };
    $('.rp-speed', bar).onchange = e => { this.state.settings.replaySpeed = +e.target.value; this.saveSoon(); if (this._rpTimer) this.replayPlay(); };
  },
  active() { return this.charts[this.state.active] || this.charts[0]; },
  setActive(ch) {
    const i = this.charts.indexOf(ch); if (i < 0) return;
    if (this._activeShown === ch) return;
    this._activeShown = ch;
    if (this.state.active !== i) { this.state.active = i; this.saveSoon(); }
    this.charts.forEach((c, k) => c.cell.classList.toggle('active', k === i && this.charts.length > 1));
    this.updateTopbar();
    Panels.markCurrent(); Panels.refreshObjects();
    this.buildTools();
    this.updateDrawbar();
    if (typeof News !== 'undefined') News.setSym(ch.sym);
  },
  onChartLoaded(ch) { if (ch === this.active()) this.updateTopbar(); ch.corrUpdate(); },
  invalidateSym(sym) { const k = this.dKey(sym); this.charts.forEach(c => { if (this.dKey(c.sym) === k) c.invalidate(); }); },
  crossFrom(src, t) {
    if (!this.state.settings.syncCross) return;
    for (const c of this.charts) if (c !== src) { c.extCross = t; c.invalidate(); }
  },
  setSymbol(sym, ch = this.active()) {
    if (this.replayChart) this.replayStop(this.replayChart, true);
    sym = String(sym).toUpperCase().replace(/[^A-Z0-9:_-]/g, '');
    if (!sym) return;
    const targets = this.state.settings.syncSymbol ? this.charts : [ch];
    for (const t of targets) { t.cfg.symbol = sym; t.load(); }
    this._activeShown = null; this.setActive(this.active());
    this.restartTicker(); this.saveSoon();
  },
  setInterval(iv, ch = this.active()) {
    if (this.replayChart) this.replayStop(this.replayChart, true);
    const targets = this.state.settings.syncInterval ? this.charts : [ch];
    for (const t of targets) { t.cfg.interval = iv; t.load(); }
    this.updateTopbar(); this.saveSoon();
  },
  setType(type, ch = this.active()) { ch.cfg.type = type; ch.recalc(); ch.invalidate(); this.updateTopbar(); this.saveSoon(); },
  toggleLog(ch = this.active()) { ch.cfg.log = !ch.cfg.log; ch.priceAuto = true; ch.invalidate(); this.saveSoon(); },

  // ---------- цены ----------
  restartTicker() {
    clearTimeout(this._tt);
    this._tt = setTimeout(() => {
      const s = this.state;
      const set = new Set([...s.watchlist, ...s.alerts.filter(a => a.active).map(a => a.sym), ...this.charts.map(c => c.sym)]);
      const list = [...set].sort(), key = Data.mode + '|' + list.join(',');
      if (key === this.tickKey) return;
      this.tickKey = key;
      this.ticker && this.ticker.close();
      this.ticker = Data.miniTicker(list, (sym, c, chg) => this.onTick(sym, c, chg));
    }, 300);
  },
  onTick(sym, c, chg) {
    this._lastTick = Date.now();
    this.changes[sym] = chg;
    const driven = this.charts.some(x => x.sym === sym && x.bars.length);
    Panels.updateWatchRow(sym, driven ? (this.prices[sym] ?? c) : c, chg);
    if (!driven) this.onPrice(sym, c);
  },
  onPrice(sym, p) {
    const prev = this.prices[sym];
    this.prices[sym] = p;
    if (prev === undefined || prev === p) return;
    if (!this.isMain) return; // алерты и голос срабатывают только в главном окне
    Alerts.check(sym, prev, p);
    Voice.checkPositions(sym, prev, p);
  },
  priceLinesFor(sym) { return Alerts.lines(sym); },

  // ---------- индикаторы ----------
  toggleFR(ch = this.active()) {
    if (!ch) return;
    ch.cfg.frCard = !ch.cfg.frCard;
    Funding.refresh(ch, true);
    this.saveSoon(); this.buildTools();
  },
  toggleOI(ch = this.active()) {
    if (!ch) return;
    ch.cfg.oiCard = !ch.cfg.oiCard;
    if (ch.cfg.oiCard) ch.oiLoad(); else ch.oiRender();
    this.saveSoon(); this.buildTools();
  },
  addIndicator(type, ch = this.active()) {
    ch.cfg.indicators.push(IND.make(type));
    ch.recalc(); ch.layoutDirty = true; ch.invalidate();
    Panels.refreshObjects(); this.saveSoon();
  },
  indAction(ch, inst, a) {
    if (a === 'vis') inst.visible = inst.visible === false;
    else if (a === 'del') { ch.cfg.indicators = ch.cfg.indicators.filter(i => i !== inst); if (ch.selInd === inst) ch.selInd = null; }
    else if (a === 'set') { this.openIndSettings(ch, inst); return; }
    ch.recalc(); ch.layoutDirty = true; ch.invalidate();
    Panels.refreshObjects(); this.saveSoon(); this.updateDrawbar();
  },
  openIndicatorPicker() {
    const ch = this.active();
    const m = U.modal({ title: 'Индикаторы и стратегии', width: 560 });
    m.body.innerHTML = `<div class="search-box">${U.icon('search', 16)}<input class="inp" placeholder="Поиск: RSI, Боллинджер, MACD…"></div><div class="ind-list"></div>`;
    const inp = $('input', m.body), list = $('.ind-list', m.body);
    const render = () => {
      const q = inp.value.trim().toLowerCase();
      const defs = Object.values(IND.defs).filter(d => !q || d.name.toLowerCase().includes(q) || d.short.toLowerCase().includes(q) || d.id.toLowerCase().includes(q));
      const cats = [...new Set(defs.map(d => d.cat))];
      list.innerHTML = cats.map(c => `<div class="ind-cat">${U.esc(c)}</div>` + defs.filter(d => d.cat === c).map(d => {
        const n = ch.cfg.indicators.filter(i => i.type === d.id).length;
        return `<div class="ind-row" data-id="${d.id}"><span class="ind-short">${U.esc(d.short)}</span><span class="ind-name">${U.esc(d.name)}</span><span class="ind-where muted">${d.overlay ? 'на графике' : 'отдельная панель'}</span>${n ? `<span class="badge">${n}</span>` : ''}</div>`;
      }).join('')).join('') || '<div class="empty">Ничего не найдено</div>';
    };
    list.onclick = e => { const r = e.target.closest('.ind-row'); if (!r) return; this.addIndicator(r.dataset.id, ch); render(); U.toast(`Добавлен: ${IND.defs[r.dataset.id].name}`, 'info', 1800); };
    inp.oninput = render; render();
    setTimeout(() => inp.focus(), 0);
  },
  openIndSettings(ch, inst) {
    const d = IND.defs[inst.type];
    const m = U.modal({ title: `${d.name} (${d.short})`, width: 420 });
    const params = d.p.map(([k, label, def, opts]) => opts
      ? `<label>${U.esc(label)}<select class="inp" data-p="${k}">${opts.map(o => `<option value="${o}"${inst.params[k] === o ? ' selected' : ''}>${o}</option>`).join('')}</select></label>`
      : `<label>${U.esc(label)}<input class="inp" type="number" step="any" data-p="${k}" value="${inst.params[k] ?? def}"></label>`).join('');
    const colors = d.o.filter(o => o.t !== 'vol').map(o => `<label class="color-row"><input type="color" data-c="${o.k}" value="${U.toHex(inst.colors[o.k] || o.c)}"> ${U.esc(o.n)}</label>`).join('');
    m.body.innerHTML = `<div class="tabs2"><span class="on">Параметры и стиль</span></div><div class="form">${params || '<div class="muted">Без параметров</div>'}</div>${colors ? `<div class="form-title">Цвета</div><div class="colors">${colors}</div>` : ''}
      <div class="modal-actions"><button class="btn ghost" data-a="def">По умолчанию</button><span class="grow"></span><button class="btn ghost" data-a="cancel">Отмена</button><button class="btn primary" data-a="ok">OK</button></div>`;
    m.body.onclick = e => {
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'cancel') { m.close(); return; }
      if (a.dataset.a === 'def') { inst.params = IND.make(inst.type).params; inst.colors = {}; }
      else {
        $$('[data-p]', m.body).forEach(el => { const def = d.p.find(x => x[0] === el.dataset.p); inst.params[el.dataset.p] = def[3] ? el.value : (parseFloat(el.value) || def[2]); });
        $$('[data-c]', m.body).forEach(el => { const o = d.o.find(x => x.k === el.dataset.c); if (U.toHex(o.c) !== el.value) inst.colors[el.dataset.c] = el.value; else delete inst.colors[el.dataset.c]; });
      }
      ch.recalc(); ch.legendDirty = true; ch.invalidate(); Panels.refreshObjects(); this.saveSoon(); m.close();
    };
  },

  // ---------- рисунки ----------
  // рисунки привязаны к монете (BTCUSDT), а не к бирже: на Binance, Bybit, споте и фьючерсах — одни и те же
  dKey(sym) { try { const l = Data.label(sym); return (l.base + l.quote).toUpperCase() || sym; } catch { return sym; } },
  getDrawings(sym) { const k = this.dKey(sym); return this.state.drawings[k] || (this.state.drawings[k] = []); },
  migrateDrawings() {
    const src = this.state.drawings || {}, out = {};
    for (const [sym, arr] of Object.entries(src)) {
      if (!Array.isArray(arr) || !arr.length) continue;
      const k = this.dKey(sym), seen = new Set((out[k] || []).map(d => d.id));
      out[k] = (out[k] || []).concat(arr.filter(d => !d.id || !seen.has(d.id)));
    }
    this.state.drawings = out;
  },
  drawingsChanged(sym, persist) {
    this.invalidateSym(sym);
    if (persist) { this.saveSoon(); Panels.refreshObjects(); this.updateDrawbar(); }
  },
  addDrawing(sym, d, ch) {
    this.pushUndo(sym);
    this.getDrawings(sym).push(d);
    ch.selected = d;
    this.drawingsChanged(sym, true);
    if (!this.state.settings.stay) this.setTool('cross');
    if (d.type === 'text') this.editText(sym, d);
    this.onSelect(ch);
  },
  deleteDrawing(sym, d) {
    this.pushUndo(sym);
    const arr = this.getDrawings(sym), i = arr.indexOf(d);
    if (i >= 0) arr.splice(i, 1);
    this.charts.forEach(c => { if (c.selected === d) c.selected = null; if (c.hover === d) c.hover = null; });
    this.drawingsChanged(sym, true);
  },
  // сдвиг выбранного рисунка стрелками: на 1 свечу (с Shift — на 10)
  nudgeDrawing(ch, d, bars) {
    const now = Date.now();
    if (this._nudge !== d || now - (this._nudgeT || 0) > 1200) this.pushUndo(ch.sym); // серия нажатий = одна отмена Ctrl+Z
    this._nudge = d; this._nudgeT = now;
    d.pts = d.pts.map(p => ({ ...p, t: ch.idxToTime(ch.timeToIdx(p.t) + bars) }));
    this.drawingsChanged(ch.sym, true);
  },
  async deleteAllDrawings() {
    const ch = this.active(), arr = this.getDrawings(ch.sym);
    if (!arr.length) { U.toast('На графике нет рисунков'); return; }
    if (!(await U.confirm(`Удалить все рисунки (${arr.length}) на ${ch.sym}?`, 'Удалить'))) return;
    this.pushUndo(ch.sym);
    this.state.drawings[this.dKey(ch.sym)] = [];
    this.charts.forEach(c => { if (this.dKey(c.sym) === this.dKey(ch.sym)) { c.selected = null; c.hover = null; } });
    this.drawingsChanged(ch.sym, true);
  },
  async editText(sym, d) {
    const v = await U.prompt('Текст надписи', d.text || '', { multiline: true });
    if (v == null) return;
    this.pushUndo(sym); d.text = v || 'Текст'; this.drawingsChanged(sym, true);
  },
  pushUndo(sym) {
    this.undoStack.push({ sym, data: JSON.stringify(this.getDrawings(sym)) });
    if (this.undoStack.length > 100) this.undoStack.shift();
    this.redoStack = [];
    this.undoUI();
  },
  popUndo() { this.undoStack.pop(); this.undoUI(); },
  // телефон: большие кнопки «Назад / Вперёд» поверх графика
  undoUI() {
    if (!this.isPhone) return;
    let b = document.getElementById('phUndo');
    if (!b) {
      b = U.h(`<div id="phUndo"><button data-u="undo" title="Отменить последнее действие с рисунком"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3"/></svg><span>Назад</span></button><button data-u="redo" title="Вернуть отменённое"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 14l5-5-5-5M20 9H10a6 6 0 0 0 0 12h3"/></svg></button></div>`);
      b.onclick = e => { const k = e.target.closest('[data-u]'); if (k) { k.dataset.u === 'undo' ? this.undo() : this.redo(); } };
      document.body.appendChild(b);
    }
    b.querySelector('[data-u="undo"]').disabled = !this.undoStack.length;
    b.querySelector('[data-u="redo"]').disabled = !this.redoStack.length;
    b.classList.toggle('show', !!(this.undoStack.length || this.redoStack.length));
  },
  restoreSnap(from, to) {
    const u = from.pop(); if (!u) return;
    to.push({ sym: u.sym, data: JSON.stringify(this.getDrawings(u.sym)) });
    this.state.drawings[this.dKey(u.sym)] = JSON.parse(u.data);
    this.charts.forEach(c => { if (c.sym === u.sym) { c.selected = null; c.hover = null; } });
    this.drawingsChanged(u.sym, true);
  },
  undo() { if (!this.undoStack.length) { U.toast('Нечего отменять', 'info', 1500); return; } this.restoreSnap(this.undoStack, this.redoStack); this.undoUI(); },
  redo() { this.restoreSnap(this.redoStack, this.undoStack); this.undoUI(); },
  onSelect(ch) { if (ch === this.active()) { this.updateDrawbar(); Panels.refreshObjects(); } },

  updateDrawbar() {
    const bar = $('#drawbar'), ch = this.active(), d = ch && ch.selected;
    if (ch && ch.selInd && !d && ch.cfg.indicators.includes(ch.selInd)) {
      const inst = ch.selInd, r = ch.cell.getBoundingClientRect();
      bar.hidden = false;
      bar.innerHTML = `<span class="db-name">${U.icon('fx', 16)} ${U.esc(IND.defs[inst.type].name)} · ${U.esc(IND.title(inst))}</span>
        <button class="ib" data-a="set" title="Настройки">${U.icon('gear', 16)}</button>
        <button class="ib" data-a="vis" title="Скрыть/показать">${U.icon(inst.visible === false ? 'eyeOff' : 'eye', 16)}</button>
        <button class="ib danger" data-a="del" title="Удалить (Del)">${U.icon('trash', 16)}</button>`;
      bar.style.left = (r.left + r.width / 2) + 'px';
      bar.style.top = Math.max(r.top + 8, r.bottom - 74) + 'px';
      bar.onclick = e => { const b = e.target.closest('[data-a]'); if (!b) return; this.indAction(ch, inst, b.dataset.a); if (b.dataset.a === 'vis') this.updateDrawbar(); };
      return;
    }
    if (!d || !this.getDrawings(ch.sym).includes(d)) { bar.hidden = true; return; }
    const T = DRAW.TOOLS[d.type], s = d.style || (d.style = {});
    const r = ch.cell.getBoundingClientRect();
    bar.hidden = false;
    const fib = ['fib', 'fibext'].includes(d.type), vp = d.type === 'vprofile', noColor = ['long', 'short', 'vprofile'].includes(d.type);
    bar.innerHTML = `<span class="db-name">${U.icon(T.icon, 16)} ${U.esc(T.name)}</span>
      ${noColor ? '' : `<label class="db-color" title="Цвет"><input type="color" value="${U.toHex(s.color || this.th.text)}"></label>`}
      ${vp ? `<button class="ib wtxt" data-a="rows" title="Количество строк">${s.rows || 24} стр.</button><button class="ib wtxt" data-a="va" title="Зона стоимости">VA ${s.va || 70}%</button>` : d.type === 'text' ? `<button class="ib" data-a="text" title="Изменить текст">${U.icon('edit', 16)}</button><button class="ib wtxt" data-a="size" title="Размер шрифта">${s.size || 14}px</button>`
        : `<button class="ib wtxt" data-a="w" title="Толщина линии">${s.width || 1.5}px</button><button class="ib" data-a="dash" title="Стиль линии">${U.icon(['solid', 'dash', 'dotted'][s.dash || 0], 16)}</button>`}
      ${DRAW.FILLABLE.includes(d.type) ? `<button class="ib${s.fill ? ' on' : ''}" data-a="fill" title="Заливка">${U.icon('fill', 16)}</button>` : ''}
      ${fib ? `<button class="ib${s.extend ? ' on' : ''}" data-a="extend" title="Продлить уровни вправо">${U.icon('extend', 16)}</button>` : ''}
      <button class="ib" data-a="set" title="Все настройки (двойной клик)">${U.icon('gear', 16)}</button>
      <span class="db-sep"></span>
      <button class="ib${d.locked ? ' on' : ''}" data-a="lock" title="Заблокировать">${U.icon(d.locked ? 'lock' : 'unlock', 16)}</button>
      <button class="ib" data-a="clone" title="Клонировать">${U.icon('clone', 16)}</button>
      <button class="ib" data-a="del" title="Удалить (Del)">${U.icon('trash', 16)}</button>`;
    bar.style.left = (r.left + r.width / 2) + 'px';
    bar.style.top = Math.max(r.top + 8, r.bottom - 74) + 'px';
    const ci = $('input[type=color]', bar);
    if (ci) {
      ci.onfocus = () => this.pushUndo(ch.sym);
      ci.oninput = () => { s.color = ci.value; if (['fib', 'fibext', 'fibfan', 'fibtime'].includes(d.type)) s.mono = true; this.state.toolStyles[d.type] = { ...s }; this.drawingsChanged(ch.sym, false); };
      ci.onchange = () => this.saveSoon();
    }
    bar.onclick = e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const a = b.dataset.a;
      if (a === 'del') { this.deleteDrawing(ch.sym, d); return; }
      if (a === 'text') { this.editText(ch.sym, d); return; }
      if (a === 'set') { this.openDrawingSettings(ch.sym, d); return; }
      this.pushUndo(ch.sym);
      if (a === 'w') { const ws = d.type === 'highlighter' ? [8, 14, 20, 30] : d.type === 'brush' ? [1, 2, 3, 5, 8] : [1, 1.5, 2, 3, 4]; const i = ws.indexOf(s.width); s.width = ws[(i + 1) % ws.length]; }
      if (a === 'size') { const ss = [11, 14, 18, 24, 32]; s.size = ss[(ss.indexOf(s.size || 14) + 1) % ss.length]; }
      if (a === 'dash') s.dash = ((s.dash || 0) + 1) % 3;
      if (a === 'rows') { const rs = [12, 24, 48, 96]; s.rows = rs[(rs.indexOf(s.rows || 24) + 1) % rs.length]; }
      if (a === 'va') { const vs = [60, 68, 70, 80]; s.va = vs[(vs.indexOf(s.va || 70) + 1) % vs.length]; }
      if (a === 'fill') s.fill = !s.fill;
      if (a === 'extend') s.extend = !s.extend;
      if (a === 'lock') d.locked = !d.locked;
      if (a === 'clone') {
        const c = JSON.parse(JSON.stringify(d)); c.id = U.uid(); c.locked = false;
        c.pts = c.pts.map(p => ({ t: ch.idxToTime(ch.timeToIdx(p.t) + 5), p: p.p }));
        this.getDrawings(ch.sym).push(c); ch.selected = c;
      }
      if (['w', 'size', 'dash', 'fill', 'extend', 'rows', 'va'].includes(a)) this.state.toolStyles[d.type] = { ...s };
      this.drawingsChanged(ch.sym, true);
    };
  },

  // ---------- контекстное меню графика ----------
  showChartMenu(ch, cx, cy, hit) {
    const items = [];
    if (hit.ind && !hit.drawing) {
      const inst = hit.ind;
      items.push({ header: IND.defs[inst.type].name },
        { label: 'Настройки…', icon: 'gear', action: () => this.openIndSettings(ch, inst) },
        { label: inst.visible === false ? 'Показать' : 'Скрыть', icon: inst.visible === false ? 'eye' : 'eyeOff', action: () => this.indAction(ch, inst, 'vis') },
        '-', { label: 'Удалить индикатор', icon: 'trash', danger: true, shortcut: 'Del', action: () => this.indAction(ch, inst, 'del') });
      U.menu(cx, cy, items);
      return;
    }
    if (hit.drawing) {
      const d = hit.drawing; ch.selected = d; this.onSelect(ch); ch.invalidate();
      items.push({ header: DRAW.TOOLS[d.type].name },
        { label: 'Клонировать', icon: 'clone', action: () => { $('#drawbar [data-a=clone]') && $('#drawbar [data-a=clone]').click(); } },
        { label: d.locked ? 'Разблокировать' : 'Заблокировать', icon: d.locked ? 'unlock' : 'lock', action: () => { this.pushUndo(ch.sym); d.locked = !d.locked; this.drawingsChanged(ch.sym, true); } },
        { label: 'Скрыть', icon: 'eyeOff', action: () => { this.pushUndo(ch.sym); d.hidden = true; ch.selected = null; this.drawingsChanged(ch.sym, true); } },
        { label: 'На передний план', icon: 'front', action: () => { this.pushUndo(ch.sym); const a = this.getDrawings(ch.sym); a.splice(a.indexOf(d), 1); a.push(d); this.drawingsChanged(ch.sym, true); } },
        { label: 'Настройки…', icon: 'gear', action: () => this.openDrawingSettings(ch.sym, d) },
        '-', { label: 'Удалить', icon: 'trash', danger: true, shortcut: 'Del', action: () => this.deleteDrawing(ch.sym, d) });
    } else {
      if (hit.price != null && hit.price > 0) {
        const p = hit.price, f = U.fmt(p, ch.ref);
        items.push({ label: `Оповещение на ${f}`, icon: 'bell', shortcut: 'Alt+A', action: () => Alerts.quickAdd(ch.sym, p) });
        items.push({ label: `Горизонтальная линия ${f}`, icon: 'hline', shortcut: 'Alt+H', action: () => this.quickHLine(ch, p) }, '-');
      }
      items.push({ label: 'Сбросить вид графика', icon: 'sync', action: () => { ch.resetView(); ch.invalidate(); } },
        { label: 'Логарифмическая шкала', checked: !!ch.cfg.log, action: () => this.toggleLog(ch) },
        { label: 'Автомасштаб цены', checked: ch.priceAuto, action: () => { ch.priceAuto = true; ch.invalidate(); } },
        { label: 'Торговые сессии', checked: !!this.state.settings.sessions, action: () => { this.state.settings.sessions = !this.state.settings.sessions; this.charts.forEach(c => c.invalidate()); this.saveSoon(); } },
        '-', { label: 'Добавить индикатор…', icon: 'fx', action: () => this.openIndicatorPicker() },
        { label: 'Удалить все индикаторы', icon: 'close', action: () => { ch.cfg.indicators = []; ch.recalc(); ch.layoutDirty = true; ch.invalidate(); Panels.refreshObjects(); this.saveSoon(); } },
        { label: 'Удалить все рисунки', icon: 'trash', danger: true, action: () => this.deleteAllDrawings() },
        '-', { label: 'Снимок графика', icon: 'camera', action: () => this.screenshot(ch) },
        { label: 'Настройки графика…', icon: 'gear', action: () => this.openChartSettings() });
    }
    U.menu(cx, cy, items);
  },
  quickHLine(ch, price) {
    const d = { id: U.uid(), type: 'hline', pts: [{ t: ch.idxToTime(ch.bars.length - 1), p: price }], style: { ...(this.state.toolStyles.hline || DRAW.defaultStyle('hline')) } };
    this.addDrawing(ch.sym, d, ch);
  },

  // ---------- поиск символа ----------
  async openSymbolSearch(prefill = '', mode = 'set') {
    const m = U.modal({ title: mode === 'add' ? 'Добавить в список наблюдения' : 'Поиск символа', width: 640 });
    const exs = [['', 'Все'], ...Data.EXCHANGES.map(e => [e.ex, `${e.name}${e.kind === 'Фьючерсы' ? ' фьюч.' : ''}`])];
    m.body.innerHTML = `<div class="search-box">${U.icon('search', 16)}<input class="inp" placeholder="Название монеты: BTC, PEPE, INFI…"></div>
      <div class="ex-tabs">${exs.map(([k, n]) => `<button data-ex="${k}"${k === '' ? ' class="on"' : ''}>${n}</button>`).join('')}</div>
      <div class="sym-list"><div class="empty">Загрузка списков бирж…</div></div><div class="sym-foot muted" id="symFoot"></div>`;
    const inp = $('input', m.body), list = $('.sym-list', m.body), foot = $('#symFoot', m.body);
    inp.value = prefill;
    const phoneWL = this.isPhone && mode === 'set'; // на телефоне: пустой поиск = ваш список наблюдения
    if (!phoneWL || prefill) setTimeout(() => { inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }, 0);
    let all = [], sel = 0, items = [], exF = '';
    const choose = id => {
      if (!id) return;
      if (mode === 'add') Panels.addToWatch(id); else this.setSymbol(id);
      m.close();
    };
    const exRank = { BINANCE: 0, BYBIT: 1, OKX: 2, GATE: 3, MEXC: 4, BINANCEF: 5, BYBITF: 6, GATEF: 7 };
    const wlRender = () => {
      const wl = this.state.watchlist, cur = this.active() && this.active().sym;
      items = wl.map(id => ({ id }));
      list.innerHTML = `<div class="wlm-h">Список наблюдения<span class="muted"> · начните печатать, чтобы найти другую монету</span></div>` + (wl.map(id => {
        const lb = Data.label(id), av = coinAvatar(lb.base), c = this.prices[id], ch = this.changes[id];
        return `<div class="sym-row wlm${id === cur ? ' sel' : ''}" data-s="${U.esc(id)}"><span class="s"><span class="wl-av" style="background:${av.bg};color:${av.fg}">${U.esc(av.t)}</span>${U.esc(lb.base)}<span class="q">${U.esc(lb.quote)}</span>${lb.ex !== 'BINANCE' ? `<span class="ex-badge ex-${lb.ex}">${lb.exName}</span>` : ''}</span><span class="p">${c != null ? U.fmt(c, c) : '—'}</span><span class="${(ch || 0) >= 0 ? 'up' : 'dn'}">${ch != null ? `${ch >= 0 ? '+' : ''}${(+ch).toFixed(2)}%` : '—'}</span><button class="ib xs wlm-x" data-x="${U.esc(id)}" title="Убрать из списка">${U.icon('close', 12)}</button></div>`;
      }).join('') || '<div class="empty">Список пуст — найдите монету и нажмите «+»</div>');
      foot.textContent = '';
    };
    const render = () => {
      const q = inp.value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (phoneWL && !q && !exF) { wlRender(); return; }
      let f = all.filter(x => (!exF || x.ex === exF));
      if (q) {
        f = f.filter(x => x.key.includes(q) || x.base.includes(q));
        const score = x => x.base === q ? 0 : x.key === q ? 0 : x.base.startsWith(q) ? 1 : x.key.startsWith(q) ? 2 : 3;
        f.sort((a, b) => (score(a) - score(b)) || ((a.quote === 'USDT' ? 0 : 1) - (b.quote === 'USDT' ? 0 : 1)) || (exRank[a.ex] - exRank[b.ex]) || (b.qv - a.qv));
      } else f.sort((a, b) => (exRank[a.ex] - exRank[b.ex]) || (b.qv - a.qv));
      items = f.slice(0, 200);
      sel = Math.min(sel, Math.max(0, items.length - 1));
      list.innerHTML = items.map((x, i) => {
        const lb = Data.label(x.id);
        const inWl = phoneWL && this.state.watchlist.includes(x.id);
        return `<div class="sym-row${i === sel ? ' sel' : ''}" data-s="${U.esc(x.id)}"><span class="s">${U.esc(x.base)}<span class="q">${U.esc(x.quote)}</span></span><span class="ex-badge ex-${x.ex}">${lb.exName}</span><span class="muted">${lb.kind}</span><span class="p">${U.fmt(x.c, x.c)}</span><span class="${x.ch >= 0 ? 'up' : 'dn'}">${x.ch >= 0 ? '+' : ''}${(+x.ch || 0).toFixed(2)}%</span>${phoneWL ? `<button class="ib xs wlm-add${inWl ? ' on' : ''}" data-add="${U.esc(x.id)}" title="${inWl ? 'Уже в списке' : 'Добавить в список наблюдения'}">${inWl ? '✓' : '+'}</button>` : ''}</div>`;
      }).join('') || `<div class="empty">${all.length ? 'Не найдено' : 'Загрузка…'}${q.length >= 3 && all.length ? ` — Enter, чтобы открыть ${q} на Binance` : ''}</div>`;
      foot.textContent = all.length ? `Найдено: ${f.length} · бирж загружено: ${new Set(all.map(x => x.ex)).size} из ${Data.EXCHANGES.length}` : '';
      const se = $('.sym-row.sel', list); se && se.scrollIntoView({ block: 'nearest' });
    };
    list.onclick = e => {
      const x = e.target.closest('[data-x]'); if (x) { e.stopPropagation(); Panels.removeFromWatch(x.dataset.x); render(); return; }
      const a = e.target.closest('[data-add]'); if (a) { e.stopPropagation(); if (!this.state.watchlist.includes(a.dataset.add)) { Panels.addToWatch(a.dataset.add); U.toast('Добавлено в список наблюдения', 'info', 1500); } render(); return; }
      const r = e.target.closest('.sym-row'); if (r) choose(r.dataset.s);
    };
    if (phoneWL) {
      m.el && m.el.classList.add('sym-phone'); render();
      const live = setInterval(() => { if (m.closed) { clearInterval(live); return; } if (!inp.value.trim() && !exF) wlRender(); }, 1500); // цены в списке живые
    }
    $('.ex-tabs', m.body).onclick = e => {
      const b = e.target.closest('[data-ex]'); if (!b) return;
      exF = b.dataset.ex; $$('.ex-tabs button', m.body).forEach(x => x.classList.toggle('on', x === b));
      sel = 0; render(); inp.focus();
    };
    inp.oninput = () => { sel = 0; render(); };
    inp.onkeydown = e => {
      if (e.key === 'ArrowDown') { sel = Math.min(sel + 1, items.length - 1); render(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(sel - 1, 0); render(); e.preventDefault(); }
      else if (e.key === 'Enter') { e.preventDefault(); choose(items[sel] ? items[sel].id : inp.value.trim().toUpperCase()); }
    };
    const rr = U.throttle(() => { if (!m.closed) render(); }, 250);
    await Data.searchList(part => { all = part; rr(); });
    if (!m.closed) render();
  },

  // ---------- настройки ----------
  openChartSettings() {
    const st = this.state.settings;
    const m = U.modal({ title: 'Настройки внешнего вида', width: 460 });
    const cur = (k, d) => U.toHex(st[k] || d);
    const row = (id, label, k, d) => `<label class="color-row"><input type="color" id="${id}" value="${cur(k, d)}"> ${label}</label>`;
    const card = (id, name, bg, up, dn, cls = '') => `<button class="th-card ${cls}${(st.themeId || '') === id ? ' on' : ''}" data-theme-id="${id}"><span class="th-prev" style="background:${bg}">${[14, 22, 12, 26, 18, 10].map((hh, i) => `<i style="height:${hh}px;background:${i % 2 ? dn : up}${dn === '#000000' && i % 2 ? `;border:1px solid ${up}` : ''}"></i>`).join('')}</span><span class="th-name">${name}</span></button>`;
    const mine = st.myStyle;
    m.body.innerHTML = `<div class="form">
      <div class="form-title">Темы</div>
      <div class="themes">${mine ? card('mine', 'Мой стиль', mine.bgColor || '#0c1119', mine.upColor || '#1fb386', mine.downColor || '#ee4d63', 'th-mine') : ''}${THEMES.map(t => card(t.id, t.name, t.bg, t.up, t.dn)).join('')}</div>
      <div class="th-actions"><button class="btn ghost sm" data-a="savemine">${mine ? 'Перезаписать «Мой стиль» текущим видом' : 'Запомнить текущий вид как «Мой стиль»'}</button>${mine ? '<button class="btn ghost sm" data-a="mine">Вернуть мой стиль</button>' : ''}</div>
      <div class="form-title">Свечи</div>
      <div class="colors">${row('csUp', 'Тело растущей', 'upColor', this.th.up)}${row('csDn', 'Тело падающей', 'downColor', this.th.down)}${row('csWu', 'Фитиль растущей', 'wickUp', st.upColor || this.th.up)}${row('csWd', 'Фитиль падающей', 'wickDn', st.downColor || this.th.down)}${row('csBu', 'Граница растущей', 'borderUp', st.upColor || this.th.up)}${row('csBd', 'Граница падающей', 'borderDn', st.downColor || this.th.down)}</div>
      <div class="presets"><span class="muted">Готовые стили:</span>${CANDLE_PRESETS.map((p, i) => `<button class="cp" data-cp="${i}" title="${p.name}"><i style="background:${p.up === 'bg' ? 'transparent' : p.up};border-color:${p.bu}"></i><i style="background:${p.dn};border-color:${p.bd}"></i><span>${p.name}</span></button>`).join('')}</div>
      <label class="chk"><input type="checkbox" id="csBorder"${st.candleBorder !== false ? ' checked' : ''}> Показывать границы свечей</label>
      <div class="form-title">Фон и шкалы</div>
      <div class="colors">${row('csBg', 'Фон графика', 'bgColor', this.th.chartBg)}${row('csGrid2', 'Сетка', 'gridColor', '#7f8aa1')}${row('csAxis', 'Текст шкал', 'axisColor', this.th.textDim)}${row('csCross', 'Перекрестие', 'crossColor', this.th.cross)}</div>
      <div class="presets"><span class="muted">Готовые фоны:</span>${['#0c1119', '#000000', '#131722', '#1e1e1e', '#0b1a2a', '#ffffff', '#f5f1e6'].map(c => `<button class="sw" data-bg="${c}" style="background:${c}"></button>`).join('')}</div>
      <div class="form-title">Отображение</div>
      <label class="chk"><input type="checkbox" id="csGrid"${st.grid !== false ? ' checked' : ''}> Сетка</label>
      <label class="chk"><input type="checkbox" id="csRound"${st.roundLevels !== false ? ' checked' : ''}> Выделять круглые цены на шкале</label>
      <label class="chk"><input type="checkbox" id="csSess"${st.sessions ? ' checked' : ''}> Торговые сессии (Азия, Европа, Америка) на графиках до 1h</label>
      <label class="chk"><input type="checkbox" id="csWm"${st.watermark !== false ? ' checked' : ''}> Водяной знак символа</label>
      <label class="chk"><input type="checkbox" id="csCd"${st.countdown !== false ? ' checked' : ''}> Таймер до закрытия бара</label>
      <label class="chk"><input type="checkbox" id="csLast"${st.lastLine !== false ? ' checked' : ''}> Линия последней цены</label>
      <label>Скорость зума и прокрутки: <b id="csSpV">${Math.round((st.speed ?? 0.5) * 100)}%</b><input type="range" id="csSp" min="0.15" max="1.5" step="0.05" value="${st.speed ?? 0.5}"></label>
      <label class="chk"><input type="checkbox" id="csIn"${st.inertia !== false ? ' checked' : ''}> Прокрутка по инерции</label>
      <label class="chk"><input type="checkbox" id="csAuto"${st.autoHideSide !== false ? ' checked' : ''}> Прятать список наблюдения при 4 и 6 графиках</label>
      <label class="chk"><input type="checkbox" id="csSnd"${st.sound !== false ? ' checked' : ''}> Звук оповещений</label>
    </div><div class="modal-actions"><button class="btn ghost" data-a="reset">Сбросить цвета</button><span class="grow"></span><button class="btn primary" data-a="ok">Готово</button></div>`;
    const map = { csUp: 'upColor', csDn: 'downColor', csWu: 'wickUp', csWd: 'wickDn', csBu: 'borderUp', csBd: 'borderDn', csBg: 'bgColor', csGrid2: 'gridColor', csAxis: 'axisColor', csCross: 'crossColor' };
    const apply = e => {
      if (e && e.target && map[e.target.id]) { st[map[e.target.id]] = e.target.value; st.themeId = ''; }
      st.candleBorder = $('#csBorder', m.body).checked; st.inertia = $('#csIn', m.body).checked; st.autoHideSide = $('#csAuto', m.body).checked; this.applySideAuto(); st.speed = +$('#csSp', m.body).value; $('#csSpV', m.body).textContent = Math.round(st.speed * 100) + '%';
      st.roundLevels = $('#csRound', m.body).checked; st.sessions = $('#csSess', m.body).checked;
      st.grid = $('#csGrid', m.body).checked; st.watermark = $('#csWm', m.body).checked; st.countdown = $('#csCd', m.body).checked;
      st.lastLine = $('#csLast', m.body).checked; st.sound = $('#csSnd', m.body).checked;
      this.applyTheme(); this.saveSoon();
    };
    m.body.oninput = apply; m.body.onchange = apply;
    m.body.onclick = e => {
      const tc = e.target.closest('[data-theme-id]');
      if (tc) { this.setThemePreset(tc.dataset.themeId); m.close(); this.openChartSettings(); return; }
      const sa = e.target.closest('[data-a=savemine]');
      if (sa) { st.myStyle = this.styleSnapshot(); st.themeId = 'mine'; this.saveSoon(); U.toast('Текущий вид сохранён как «Мой стиль»', 'info', 2500); m.close(); this.openChartSettings(); return; }
      const mn = e.target.closest('[data-a=mine]');
      if (mn) { this.setThemePreset('mine'); m.close(); this.openChartSettings(); return; }
      const cp = e.target.closest('[data-cp]');
      if (cp) {
        const P = CANDLE_PRESETS[+cp.dataset.cp], bg = this.th.chartBg;
        Object.assign(st, { upColor: P.up === 'bg' ? bg : P.up, downColor: P.dn, wickUp: P.wu || P.bu, wickDn: P.wd || P.bd, borderUp: P.bu, borderDn: P.bd, candleBorder: true });
        m.close(); this.applyTheme(); this.saveSoon(); this.openChartSettings(); return;
      }
      const sw = e.target.closest('[data-bg]');
      if (sw) { st.bgColor = sw.dataset.bg; $('#csBg', m.body).value = sw.dataset.bg; this.applyTheme(); this.saveSoon(); return; }
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'reset') { Object.values(map).forEach(k => delete st[k]); this.applyTheme(); this.saveSoon(); m.close(); return; }
      m.close();
    };
  },

  // ---------- настройки рисунка ----------
  // поля цен для окна настроек: подписи и какие точки они меняют
  coordSpec(d) {
    const P = d.pts || [], t = d.type;
    const one = { hline: 'Цена', hray: 'Цена', crossline: 'Цена', pricelabel: 'Цена', arrowup: 'Цена', arrowdown: 'Цена', text: 'Цена (высота текста)' };
    if (one[t] && P[0]) return [{ label: one[t], get: () => P[0].p, set: v => { P[0].p = v; } }];
    // верх / низ (прямоугольник и похожие) — подписи по смыслу, независимо от того, в какую сторону рисовали
    if (['rect', 'prange', 'dprange', 'vprofile', 'ellipse'].includes(t) && P.length >= 2) {
      const hiI = P[0].p >= P[1].p ? 0 : 1, loI = 1 - hiI;
      const spec = [{ label: 'Верхняя граница', get: () => P[hiI].p, set: v => { P[hiI].p = v; } }, { label: 'Нижняя граница', get: () => P[loI].p, set: v => { P[loI].p = v; } }];
      spec.range = true; return spec;
    }
    if (t === 'fib' && P.length >= 2) { const spec = [{ label: 'Начало (100%)', get: () => P[0].p, set: v => { P[0].p = v; } }, { label: 'Конец (0%)', get: () => P[1].p, set: v => { P[1].p = v; } }]; spec.range = true; return spec; }
    if (['vline', 'drange', 'fibtime', 'brush', 'highlighter', 'path'].includes(t) || !P.length) return null;
    return P.slice(0, 3).map((pt, i) => ({ label: `Цена точки ${i + 1}`, get: () => pt.p, set: v => { pt.p = v; } }));
  },
  openDrawingSettings(sym, d) {
    const T = DRAW.TOOLS[d.type], s = d.style || (d.style = {}), th = this.th;
    const isPos = d.type === 'long' || d.type === 'short', isFib = ['fib', 'fibext', 'fibfan', 'fibtime'].includes(d.type);
    const ch = this.charts.find(c => c.sym === sym) || this.active(), ref = ch.ref, f = v => U.fmt(v, ref);
    const m = U.modal({ title: T.name, width: isPos ? 520 : 420 });
    const color = (id, label, val) => `<label class="color-row"><input type="color" id="${id}" value="${U.toHex(val)}"> ${label}</label>`;
    let html = '<div class="form">';
    if (isPos) {
      const ens = d.entries && d.entries.length ? d.entries : [{ p: d.pts[0].p, w: 100 }];
      const tps = d.tps && d.tps.length ? d.tps : [{ p: d.pts[1].p, w: 100 }];
      const rd = this.state.settings.riskDef || {};
      const row = (kind, p, w) => `<div class="en-row" data-kind="${kind}"><input class="inp" type="number" step="any" data-ep value="${p != null ? f(p) : ''}" placeholder="Цена"><input class="inp" type="number" step="any" data-ew value="${w ?? 100}" placeholder="Доля"><span class="muted">%</span><button class="ib xs" data-del title="Убрать">${U.icon('close', 14)}</button></div>`;
      html += `<label>Направление<select class="inp" id="dsDir"><option value="long">Лонг (покупка)</option><option value="short">Шорт (продажа)</option></select></label>
        <div class="form-title">Входы (лимитные ордера)</div>
        <div id="dsEns">${ens.map(en => row('en', en.p, en.w)).join('')}</div>
        <button class="btn ghost sm" data-add="en">+ Добавить лимитку</button>
        <div class="form-title">Тейк-профиты (доля позиции на каждом)</div>
        <div id="dsTps">${tps.map(t => row('tp', t.p, t.w)).join('')}</div>
        <button class="btn ghost sm" data-add="tp">+ Добавить тейк</button>
        <div class="two"><label>Стоп-лосс<input class="inp" type="number" step="any" id="dsSl" value="${f(d.pts[2].p)}"></label><label>Комиссия за сделку, %<input class="inp" type="number" step="any" id="dsFee" value="${s.fee || 0}" placeholder="0.1"></label></div>
        <div class="form-title">Калькулятор</div>
        <label>Сумма входа, USDT<input class="inp" type="number" step="any" id="dsAmt" value="${s.amount ?? rd.amount ?? ''}" placeholder="на сколько USDT заходите, например 500"></label>
        <div class="calc" id="dsCalc"></div>
        <label class="chk"><input type="checkbox" id="dsAlways"${s.alwaysLabels ? ' checked' : ''}> Всегда показывать цифры (иначе — только когда позиция выделена)</label>
        <div class="form-title">Цвета</div>
        <div class="colors">${color('dsTpC', 'Зона тейка', s.tpColor || th.up)}${color('dsSlC', 'Зона стопа', s.slColor || th.down)}</div>`;
      this._posRow = row;
    } else if (d.type === 'vprofile') {
      html += `<div class="two"><label>Строк<select class="inp" id="dsRows">${[12, 24, 48, 96].map(r => `<option${(s.rows || 24) === r ? ' selected' : ''}>${r}</option>`).join('')}</select></label><label>Зона стоимости, %<input class="inp" type="number" id="dsVa" value="${s.va || 70}"></label></div>
        <div class="colors">${color('dsUpC', 'Объём покупок', s.upColor || th.up)}${color('dsDnC', 'Объём продаж', s.dnColor || th.down)}${color('dsPocC', 'Линия POC', s.pocColor || '#e8c547')}</div>`;
    } else if (d.type === 'text') {
      html += `<label>Текст<textarea class="inp" rows="3" id="dsText">${U.esc(d.text || '')}</textarea></label>
        <div class="two"><label>Размер<select class="inp" id="dsSize">${[11, 14, 18, 24, 32, 48].map(r => `<option${(s.size || 14) === r ? ' selected' : ''}>${r}</option>`).join('')}</select></label><span></span></div>
        <div class="colors">${color('dsColor', 'Цвет', s.color || th.text)}</div>
        <label class="chk"><input type="checkbox" id="dsBold"${s.bold ? ' checked' : ''}> Жирный</label>
        <label class="chk"><input type="checkbox" id="dsBg"${s.bg ? ' checked' : ''}> Подложка</label>`;
    } else {
      html += `<div class="colors">${color('dsColor', isFib ? 'Цвет' : 'Цвет линии', s.color || th.text)}</div>
        <div class="two"><label>Толщина<select class="inp" id="dsW">${(d.type === 'highlighter' ? [8, 14, 20, 30] : d.type === 'brush' ? [1, 2, 3, 5, 8] : [1, 1.5, 2, 3, 4]).map(r => `<option${(s.width || 1.5) === r ? ' selected' : ''}>${r}</option>`).join('')}</select></label>
        <label>Стиль<select class="inp" id="dsDash"><option value="0">Сплошная</option><option value="1">Штрихи</option><option value="2">Точки</option></select></label></div>`;
      if (isFib) html += `<label class="chk"><input type="checkbox" id="dsMono"${s.mono ? ' checked' : ''}> Один цвет для всех уровней</label>`;
      if (['fib', 'fibext'].includes(d.type)) html += `<label class="chk"><input type="checkbox" id="dsExt"${s.extend ? ' checked' : ''}> Продлить уровни вправо</label>`;
      if (DRAW.FILLABLE.includes(d.type)) html += `<label class="chk"><input type="checkbox" id="dsFill"${s.fill ? ' checked' : ''}> Заливка</label>`;
    }
    // координаты: цены точек — можно вписать вручную
    const coord = isPos ? null : this.coordSpec(d);
    if (coord) {
      html += `<div class="form-title">Цены</div><div class="${coord.length > 1 ? 'two' : ''}">` +
        coord.map((c, i) => `<label>${c.label}<input class="inp" type="number" step="any" data-cp="${i}" value="${f(c.get())}"></label>`).join('') + '</div>';
      if (coord.range) html += `<div class="muted sm" id="dsRange"></div>`;
    }
    html += `<label class="chk"><input type="checkbox" id="dsDef"> Использовать как стиль по умолчанию для этого инструмента</label></div>
      <div class="modal-actions"><button class="btn ghost" data-a="cancel">Отмена</button><button class="btn primary" data-a="ok">OK</button></div>`;
    m.body.innerHTML = html;
    const q = id => $('#' + id, m.body);
    const readRows = kind => $$(`.en-row[data-kind=${kind}]`, m.body).map(r => ({ p: parseFloat($('[data-ep]', r).value), w: parseFloat($('[data-ew]', r).value) || 0 })).filter(en => en.p > 0);
    const wavg = arr => { const tw = arr.reduce((a, x) => a + x.w, 0); return tw > 0 ? arr.reduce((a, x) => a + x.p * x.w, 0) / tw : arr.reduce((a, x) => a + x.p, 0) / arr.length; };
    const share = (arr, i) => { const tw = arr.reduce((a, x) => a + x.w, 0); return tw > 0 ? arr[i].w / tw : 1 / arr.length; };
    const base = Data.label(sym).base;
    const calc = () => {
      if (!isPos) return;
      const ens = readRows('en'), tps = readRows('tp'), sl = parseFloat(q('dsSl').value), fee = (parseFloat(q('dsFee').value) || 0) / 100, lg = q('dsDir').value === 'long', dir = lg ? 1 : -1;
      const out = q('dsCalc');
      if (!ens.length) { out.innerHTML = '<span class="dn">Укажите хотя бы одну цену входа</span>'; return null; }
      if (!tps.length) { out.innerHTML = '<span class="dn">Укажите хотя бы один тейк-профит</span>'; return null; }
      const avg = wavg(ens), exit = wavg(tps);
      const be = fee ? (lg ? avg * (1 + fee) / (1 - fee) : avg * (1 - fee) / (1 + fee)) : avg;
      const far = lg ? Math.max(...tps.map(t => t.p)) : Math.min(...tps.map(t => t.p));
      const ok = tps.every(t => lg ? t.p > avg : t.p < avg) && (lg ? sl < avg : sl > avg);
      const prof = (exit - be) / be * 100 * dir, risk = (be - sl) / be * 100 * dir, rr = risk ? prof / risk : 0;
      let html = `<div><span class="muted">Средняя цена входа (нулевая точка):</span> <b>${f(avg)}</b></div>`;
      if (fee) html += `<div><span class="muted">Безубыток с комиссией:</span> <b>${f(be)}</b></div>`;
      html += `<div><span class="muted">Средняя цена выхода по тейкам:</span> <b>${f(exit)}</b></div>
        <div><span class="muted">Прибыль:</span> <b class="up">${isFinite(prof) ? prof.toFixed(2) : '—'}%</b> · <span class="muted">Риск:</span> <b class="dn">${isFinite(risk) ? risk.toFixed(2) : '—'}%</b> · <span class="muted">R/R:</span> <b>${isFinite(rr) ? rr.toFixed(2) : '—'}</b></div>`;
      // калькулятор по сумме входа
      const amt = parseFloat(q('dsAmt').value);
      if (amt > 0) {
        const qty = amt / avg, fu = v => '$' + U.fmtNum(Math.abs(v), Math.abs(v) >= 100 ? 0 : 2), fq = v => U.fmtQty(v);
        const pc = v => `${v >= 0 ? '+' : '−'}${Math.abs(v).toFixed(2)}%`;
        const lossUsd = qty * (be - sl) * dir, winUsd = qty * (exit - be) * dir;
        html += `<div class="calc-sep"></div>
          <div><span class="muted">Сумма входа:</span> <b>${fu(amt)}</b> · <span class="muted">это</span> <b>${fq(qty)} ${U.esc(base)}</b></div>
          ${ens.length > 1 ? ens.map((en, i) => `<div class="muted sm">Лимитка ${i + 1} по ${f(en.p)}: <b>${fu(amt * share(ens, i))}</b> (${fq(qty * share(ens, i))} ${U.esc(base)})</div>`).join('') : ''}
          ${tps.map((t, i) => { const pr = qty * share(tps, i) * (t.p - be) * dir, pp = (t.p - be) / be * 100 * dir; return `<div class="sm">Тейк ${i + 1} по ${f(t.p)} (${pc(pp)}${tps.length > 1 ? `, ${(share(tps, i) * 100).toFixed(0)}% позиции` : ''}): <b class="up">+${fu(pr)}</b></div>`; }).join('')}
          <div class="calc-big"><span>В плюсе, если все тейки: <b class="up">+${fu(winUsd)}</b> <span class="muted">(${pc(prof)})</span></span>
          <span>В минусе, если стоп: <b class="dn">−${fu(lossUsd)}</b> <span class="muted">(${pc(-risk)})</span></span></div>`;
      } else html += `<div class="muted sm">Впишите сумму входа в USDT — посчитаю, сколько будет в плюсе на каждом тейке и сколько в минусе на стопе.</div>`;
      if (!ok) html += `<div class="dn">Для ${lg ? 'лонга тейки должны быть выше, а стоп ниже' : 'шорта тейки должны быть ниже, а стоп выше'} средней цены входа</div>`;
      out.innerHTML = html;
      return { ens, tps, avg, far, sl, ok };
    };
    if (isPos) {
      q('dsDir').value = d.type;
      m.body.addEventListener('click', e => {
        const ad = e.target.closest('[data-add]');
        if (ad) { const r = U.h(this._posRow(ad.dataset.add, null, 100)); q(ad.dataset.add === 'en' ? 'dsEns' : 'dsTps').appendChild(r); $('[data-ep]', r).focus(); calc(); return; }
        const x = e.target.closest('[data-del]'); if (!x) return;
        const rr = x.closest('.en-row'), kind = rr.dataset.kind;
        if ($$(`.en-row[data-kind=${kind}]`, m.body).length > 1) { rr.remove(); calc(); }
      });
      m.body.addEventListener('input', calc);
      calc();
    }
    if (q('dsDash')) q('dsDash').value = String(s.dash || 0);
    const cps = () => $$('[data-cp]', m.body).map(inp => parseFloat(inp.value));
    const showRange = () => {
      const el = q('dsRange'); if (!el) return;
      const [a, b] = cps(); if (!(a > 0 && b > 0)) { el.textContent = ''; return; }
      const hi = Math.max(a, b), lo = Math.min(a, b);
      el.innerHTML = `Диапазон: <b>${f(hi - lo)}</b> · <b>${((hi - lo) / lo * 100).toFixed(2)}%</b> от нижней границы`;
    };
    if (coord) { showRange(); m.body.addEventListener('input', e => { if (e.target.matches('[data-cp]')) showRange(); }); }
    // фокус сразу в поле цены — можно просто напечатать и нажать Enter
    if (coord) setTimeout(() => { const i = $('[data-cp]', m.body); if (i) { i.focus(); i.select(); } }, 30);
    m.body.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.matches('[data-cp]')) { e.preventDefault(); $('[data-a=ok]', m.body).click(); } });
    m.body.addEventListener('click', e => {
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'cancel') { m.close(); return; }
      this.pushUndo(sym);
      if (isPos) {
        const r = calc(); if (!r) { this.popUndo(); return; }
        if (!(r.far > 0 && r.sl > 0)) { U.toast('Укажите тейк и стоп', 'dn'); this.popUndo(); return; }
        d.type = q('dsDir').value;
        d.pts[0].p = r.avg; d.pts[1].p = r.far; d.pts[2].p = r.sl;
        d.entries = r.ens.length > 1 ? r.ens : undefined;
        d.tps = r.tps.length > 1 ? r.tps : undefined;
        d.fills = []; d.tpHits = []; d.closed = undefined;
        const amt = parseFloat(q('dsAmt').value);
        s.amount = amt > 0 ? amt : undefined;
        this.state.settings.riskDef = { amount: s.amount };
        s.fee = parseFloat(q('dsFee').value) || 0;
        s.tpColor = q('dsTpC').value; s.slColor = q('dsSlC').value;
        s.alwaysLabels = q('dsAlways').checked;
      } else if (d.type === 'vprofile') {
        s.rows = +q('dsRows').value; s.va = U.clamp(+q('dsVa').value || 70, 10, 100);
        s.upColor = q('dsUpC').value; s.dnColor = q('dsDnC').value; s.pocColor = q('dsPocC').value;
      } else if (d.type === 'text') {
        d.text = q('dsText').value || 'Текст'; s.size = +q('dsSize').value; s.color = q('dsColor').value; s.bold = q('dsBold').checked; s.bg = q('dsBg').checked;
      } else {
        s.color = q('dsColor').value; s.width = +q('dsW').value; s.dash = +q('dsDash').value;
        if (q('dsMono')) s.mono = q('dsMono').checked;
        if (q('dsExt')) s.extend = q('dsExt').checked;
        if (q('dsFill')) s.fill = q('dsFill').checked;
      }
      if (coord) {
        const v = cps();
        if (v.some(x => !(x > 0))) { U.toast('Цена должна быть больше нуля', 'error'); this.popUndo(); return; }
        coord.forEach((c, i) => c.set(v[i]));
      }
      if (q('dsDef').checked) { const c = { ...s }; delete c.fee; this.state.toolStyles[d.type] = c; }
      this.drawingsChanged(sym, true);
      m.close();
    });
  },

  // ---------- карта ликвидаций ----------
  toggleLiq(ch = this.active()) {
    ch.cfg.liq = !ch.cfg.liq;
    if (ch.cfg.liq) { if (!ch.liqOI) ch.liqLoad(); else ch.liqCompute(); U.toast('Карта ликвидаций — это оценка по открытому интересу Binance, а не точные данные', 'info', 3500); }
    ch.legendDirty = true; ch.invalidate();
    this.buildTools(); this.saveSoon();
  },
  openLiqSettings(ch) {
    const st = ch.cfg.liqSet || (ch.cfg.liqSet = { tiers: { 10: 30, 25: 30, 50: 25, 100: 15 }, thr: 12, profile: true });
    const m = U.modal({ title: 'Карта ликвидаций', width: 420 });
    m.body.innerHTML = `<div class="form">
      <div class="muted sm">Оценка: где ликвидируются позиции, открытые на каждой свече (по росту открытого интереса на фьючерсах Binance). Уровни, через которые прошла цена, гаснут.</div>
      <div class="form-title">Доля позиций по плечу, %</div>
      <div class="two">${[10, 25, 50, 100].map(l => `<label>${l}x<input class="inp" type="number" min="0" max="100" data-lev="${l}" value="${st.tiers[l] ?? 0}"></label>`).join('')}</div>
      <label>Цвета<select class="inp" id="lqPal"><option value="aurora">Синий → бирюза → жёлтый (по умолчанию)</option><option value="fire">Огонь: фиолетовый → красный → жёлтый</option><option value="ice">Лёд: синий → белый</option></select></label>
      <label>Толщина линий<select class="inp" id="lqTh">${[2, 3, 4, 6].map(v => `<option value="${v}"${(st.thick || 3) === v ? ' selected' : ''}>${v} px</option>`).join('')}</select></label>
      <label>Скрывать слабые уровни: <b id="lqThrV">${st.thr}%</b><input type="range" id="lqThr" min="0" max="50" step="1" value="${st.thr}"></label>
      <label class="chk"><input type="checkbox" id="lqProf"${st.profile !== false ? ' checked' : ''}> Профиль ликвидаций справа</label>
    </div><div class="modal-actions"><button class="btn primary" data-a="ok">Готово</button></div>`;
    const apply = () => {
      $$('[data-lev]', m.body).forEach(i => { st.tiers[i.dataset.lev] = U.clamp(+i.value || 0, 0, 100); });
      st.thr = +$('#lqThr', m.body).value; $('#lqThrV', m.body).textContent = st.thr + '%';
      st.profile = $('#lqProf', m.body).checked;
      st.pal = $('#lqPal', m.body).value; st.thick = +$('#lqTh', m.body).value;
      ch.liqCompute(); ch.invalidate(); this.saveSoon();
    };
    $('#lqPal', m.body).value = st.pal || 'aurora';
    m.body.oninput = apply; m.body.onchange = apply;
    m.body.onclick = e => { if (e.target.closest('[data-a]')) m.close(); };
  },

  // ---------- выбор индикатора ----------
  selectIndicator(ch, inst) {
    if (ch.selInd === inst) return;
    this.charts.forEach(c => { if (c.selInd) { c.selInd = null; c.legendDirty = true; c.invalidate(); } });
    ch.selInd = inst;
    if (inst) { ch.selected = null; }
    ch.legendDirty = true; ch.invalidate();
    this.updateDrawbar();
  },

  // снимок графика со своими рисунками + шапка с монетой, ценой, датой и вашей подписью
  async screenshot(ch = this.active(), ask = true) {
    if (!ch || !ch.cv) return;
    let note = '';
    if (ask) { note = await U.prompt('Подпись к снимку (можно оставить пустой — нажмите OK)', this._lastNote || ''); if (note === null) return; note = note.trim(); this._lastNote = note; }
    const d = DPR(), W = ch.cv.width / d, th = this.th, lb = Data.label(ch.sym), b = ch.bars[ch.bars.length - 1];
    const lines = []; // перенос подписи по словам
    const mc = document.createElement('canvas').getContext('2d'); mc.font = `500 14px ${U.FF}`;
    if (note) { let cur = ''; for (const w of note.split(/\s+/)) { const t = cur ? cur + ' ' + w : w; if (mc.measureText(t).width > W - 32 && cur) { lines.push(cur); cur = w; } else cur = t; } if (cur) lines.push(cur); }
    const HH = 46 + lines.slice(0, 4).length * 20 + (lines.length ? 8 : 0);
    const c = document.createElement('canvas'); c.width = ch.cv.width; c.height = ch.cv.height + Math.round(HH * d);
    const x = c.getContext('2d');
    x.fillStyle = th.chartBg || th.bg; x.fillRect(0, 0, c.width, c.height);
    x.drawImage(ch.cv, 0, Math.round(HH * d));
    x.scale(d, d);
    x.fillStyle = th.bg; x.fillRect(0, 0, W, HH);
    x.fillStyle = th.border; x.fillRect(0, HH - 1, W, 1);
    x.textBaseline = 'middle';
    // слева: монета · таймфрейм · биржа, цена и изменение за сутки
    let px = 16;
    x.font = `700 16px ${U.FF}`; x.fillStyle = th.text; x.fillText(lb.short, px, 23); px += x.measureText(lb.short).width + 10;
    x.font = `500 13px ${U.FF}`; x.fillStyle = th.textDim; const sub = `${U.ivShort(ch.iv)} · ${lb.full}`; x.fillText(sub, px, 24); px += x.measureText(sub).width + 16;
    if (b) {
      x.font = `700 15px ${U.FF}`; x.fillStyle = th.text; const pr = U.fmt(b.c, b.c); x.fillText(pr, px, 23); px += x.measureText(pr).width + 8;
      const chg = this.changes[ch.sym];
      if (chg != null && isFinite(chg)) { x.font = `600 13px ${U.FF}`; x.fillStyle = chg >= 0 ? th.up : th.down; x.fillText(`${chg >= 0 ? '+' : ''}${chg.toFixed(2)}% за 24ч`, px, 24); }
    }
    // справа: дата, время и марка
    x.textAlign = 'right';
    x.font = `500 12.5px ${U.FF}`; x.fillStyle = th.textDim;
    x.fillText(new Date().toLocaleString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }), W - 16, 16);
    x.font = `700 12px ${U.FF}`; x.fillStyle = th.accent || th.text; x.fillText('Orbita Terminal', W - 16, 33);
    x.textAlign = 'left';
    // ваша подпись
    if (lines.length) {
      x.font = `500 14px ${U.FF}`; x.fillStyle = th.text;
      lines.slice(0, 4).forEach((ln, k) => x.fillText(k === 3 && lines.length > 4 ? ln + '…' : ln, 16, 52 + k * 20));
    }
    c.toBlob(blob => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
      a.download = `orbita_${lb.short.replace(/[^\w]/g, '')}_${ch.iv}_${stamp}.png`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      try { navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]).then(() => U.toast('Снимок сохранён в «Загрузки» и скопирован — можно сразу вставить в чат (Ctrl+V)', 'info', 3500)).catch(() => U.toast('Снимок сохранён в «Загрузки»', 'info', 2500)); }
      catch { U.toast('Снимок сохранён в «Загрузки»', 'info', 2500); }
    }, 'image/png');
  },

  // ---------- клавиатура ----------
  bindKeys() {
    document.addEventListener('keydown', e => {
      const tag = (e.target.tagName || '').toUpperCase();
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || document.querySelector('.modal-wrap')) return;
      const ch = this.active(); if (!ch) return;
      const k = e.key, mod = e.ctrlKey || e.metaKey;
      if (k === 'F5') { e.preventDefault(); this.charts.forEach(c => c.resync(300)); this.tickKey = null; this.restartTicker(); U.toast('Обновляю данные…', 'info', 1500); return; }
      if (mod && e.code === 'KeyZ') { e.preventDefault(); e.shiftKey ? this.redo() : this.undo(); return; }
      if (mod && e.code === 'KeyY') { e.preventDefault(); this.redo(); return; }
      if (mod && e.code === 'KeyK') { e.preventDefault(); this.openSymbolSearch(); return; }
      if (mod && e.code === 'KeyS') { e.preventDefault(); this.saveLayout(); return; }
      if (mod && e.code === 'KeyN') { e.preventDefault(); this.newWindow(); return; }
      if (e.altKey && e.code === 'KeyS') { e.preventDefault(); this.screenshot(ch); return; }
      if (k === 'Enter' && ch.creating && ch.finishPath()) { e.preventDefault(); return; }
      if (k === 'Escape' && News.open && !ch.creating && !ch.selected && !ch.selInd) { News.toggle(false); return; }
      if (k === 'Escape' && this.maxed && !ch.creating && !ch.selected && !ch.selInd && !ch.ruler) { this.toggleMax(this.maxed); return; }
      if (k === 'Escape') {
        U.closeMenus();
        if (ch.ruler) { ch.ruler = null; ch.invalidate(); }
        if (ch.creating && !ch.finishPath()) { ch.creating = null; ch.invalidate(); }
        else if (ch.selected) { ch.selected = null; this.onSelect(ch); ch.invalidate(); }
        else if (ch.selInd) this.selectIndicator(ch, null);
        this.setTool('cross');
        return;
      }
      if ((k === 'Delete' || k === 'Backspace') && ch.selected) { e.preventDefault(); this.deleteDrawing(ch.sym, ch.selected); return; }
      if ((k === 'Delete' || k === 'Backspace') && ch.selInd) { e.preventDefault(); this.indAction(ch, ch.selInd, 'del'); U.toast('Индикатор удалён (Ctrl+Z не отменяет — добавьте заново через «Индикаторы»)', 'info', 2500); return; }
      if (e.altKey && !mod) {
        const mp = ch.mouse && ch.mouse.y < ch.main.h && ch.mouse.x < ch.plotW ? ch.yToPrice(ch.mouse.y) : (this.prices[ch.sym] || ch.ref);
        const tools = { KeyT: 'trend', KeyF: 'fib', KeyV: 'vline', KeyR: 'rect', KeyB: 'brush' };
        if (e.code === 'KeyH') { e.preventDefault(); this.quickHLine(ch, mp); return; }
        if (e.code === 'KeyA') { e.preventDefault(); Alerts.quickAdd(ch.sym, mp); return; }
        if (e.code === 'KeyI') { e.preventDefault(); this.openIndicatorPicker(); return; }
        if (e.code === 'KeyP') { e.preventDefault(); Voice.wherePrice(); return; }
        if (e.code === 'KeyL') { e.preventDefault(); AI.run(this, ch); return; }
        if (tools[e.code]) { e.preventDefault(); this.setTool(tools[e.code]); return; }
        return;
      }
      if (this.replayChart && k === ' ') { e.preventDefault(); this._rpTimer ? this.replayPause() : this.replayPlay(); return; }
      if (this.replayChart && k === 'ArrowRight' && e.shiftKey) { e.preventDefault(); this.replayPause(); this.replayChart.replayStep(1); this.renderReplayBar(true); return; }
      if (k === 'Escape' && (this.replayPick)) { this.replayStop(this.replayPick); return; }
      if ((k === 'ArrowLeft' || k === 'ArrowRight') && ch.selected && !ch.selected.locked && this.getDrawings(ch.sym).includes(ch.selected)) {
        e.preventDefault();
        this.nudgeDrawing(ch, ch.selected, (k === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 10 : 1));
        return;
      }
      if (k === 'ArrowLeft' || k === 'ArrowRight') {
        e.preventDefault();
        const step = Math.max(1, ch.plotW / ch.spacing * 0.08) * (k === 'ArrowLeft' ? -1 : 1);
        ch.rightIndex = ch.clampRI(ch.rightIndex + step); ch.maybeLoadMore(); ch.invalidate();
        return;
      }
      if (k === 'ArrowUp' || k === 'ArrowDown') {
        e.preventDefault();
        if (mod) { ch.zoom(k === 'ArrowUp' ? 1.15 : 1 / 1.15); return; } // Ctrl+↑/↓ — приблизить/отдалить
        // ↑/↓ — предыдущая/следующая монета, только когда на экране один график (раскладка «1» или развёрнутый)
        if (this.maxed || (LAYOUTS[this.state.layout] || {}).n === 1) this.watchStep(k === 'ArrowUp' ? -1 : 1, e.repeat);
        return;
      }
      if (k === 'Home') { ch.resetView(); ch.invalidate(); return; }
      if (!mod && /^[a-zA-Z0-9]$/.test(k)) { e.preventDefault(); this.openSymbolSearch(k.toUpperCase()); }
    });
  },
};

// ---------- ворота лицензии (офлайн) ----------
async function licenseGate() {
  let st;
  try { st = await window.orbita.licStatus(); } catch { return true; } // нет моста — обычный запуск
  if (!st.need || st.ok) return true; // продажа выключена или код уже активирован
  return new Promise(resolve => showActivation(st, resolve));
}
function showActivation(st, resolve, msg) {
  let el = document.getElementById('licGate');
  if (!el) { el = document.createElement('div'); el.id = 'licGate'; document.body.appendChild(el); }
  el.innerHTML = `
    <div class="lic-box">
      <div class="lic-logo">Orbita <span>Terminal</span></div>
      <div class="lic-sub">Активация программы</div>
      <div class="lic-row"><span>Код вашего компьютера</span><div class="lic-mid"><b id="licMid">${U.esc(st.machine)}</b><button id="licCopy" title="Скопировать">копировать</button></div></div>
      <div class="lic-hint">Отправьте этот код продавцу, чтобы получить ключ активации.</div>
      <textarea id="licCode" rows="3" placeholder="Вставьте сюда ключ активации"></textarea>
      <div class="lic-err" id="licErr">${msg ? U.esc(msg) : ''}</div>
      <button class="lic-go" id="licGo">Активировать</button>
    </div>`;
  el.querySelector('#licCopy').onclick = () => { navigator.clipboard && navigator.clipboard.writeText(st.machine); el.querySelector('#licCopy').textContent = 'скопировано'; };
  const go = async () => {
    const code = el.querySelector('#licCode').value.trim();
    if (!code) return;
    el.querySelector('#licGo').disabled = true;
    const r = await window.orbita.licActivate(code);
    if (r.ok) { el.remove(); resolve(true); }
    else { showActivation(st, resolve, 'Не подошло: ' + (r.reason || 'ошибка') + '. Проверьте, что код для этого компьютера.'); }
  };
  el.querySelector('#licGo').onclick = go;
  el.querySelector('#licCode').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) go(); });
}
window.addEventListener('DOMContentLoaded', async () => { if (await licenseGate()) App.init(); });
