'use strict';
// ---------- Озвучка: начало новых свечей и предупреждения перед закрытием ----------
// ---------- Фоновая музыка: генеративный эмбиент без авторских прав или свои MP3 ----------
const Music = (() => {
  let ac = null, master = null, timer = null, on = false, step = 0, audio = null, files = [], fi = 0, rainNode = null;
  const cfg = () => { const st = App.state.settings; return st.music || (st.music = { mode: 'ambient', vol: 0.35, on: false }); };
  // мягкая последовательность аккордов (ля минор): Am9 – Fmaj7 – Cmaj7 – G6
  const CHORDS = [[110, 220, 261.6, 329.6, 493.9], [87.3, 174.6, 220, 261.6, 329.6], [130.8, 196, 246.9, 329.6, 392], [98, 196, 246.9, 293.7, 329.6]];
  const MEL = [440, 493.9, 523.3, 587.3, 659.3, 784, 880];
  function ensure() {
    if (ac) return;
    ac = new (window.AudioContext || window.webkitAudioContext)();
    master = ac.createGain(); master.gain.value = 0;
    const d = ac.createDelay(2), fb = ac.createGain(), lp = ac.createBiquadFilter(), wet = ac.createGain();
    d.delayTime.value = 0.42; fb.gain.value = 0.5; lp.type = 'lowpass'; lp.frequency.value = 1500; wet.gain.value = 0.45;
    master.connect(ac.destination); master.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(wet); wet.connect(ac.destination);
  }
  function pad(freqs, t, dur) {
    freqs.forEach((f, i) => {
      const o = ac.createOscillator(), g = ac.createGain(), lp = ac.createBiquadFilter();
      o.type = i === 0 ? 'sine' : 'triangle'; o.frequency.value = f * (1 + (Math.random() - 0.5) * 0.003);
      lp.type = 'lowpass'; lp.frequency.value = 700 + Math.random() * 300;
      const v = i === 0 ? 0.05 : 0.022;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + dur * 0.35); g.gain.exponentialRampToValueAtTime(0.0001, t + dur * 1.05);
      o.connect(lp); lp.connect(g); g.connect(master); o.start(t); o.stop(t + dur * 1.1);
    });
  }
  function bell(f, t, v = 0.035) {
    [[1, v, 3.2], [2.01, v * 0.25, 1.4], [3, v * 0.08, 0.8]].forEach(([k, a, d]) => {
      const o = ac.createOscillator(), g = ac.createGain(); o.type = 'sine'; o.frequency.value = f * k;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(a, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(master); o.start(t); o.stop(t + d + 0.1);
    });
  }
  function rain() {
    if (rainNode) return;
    const len = ac.sampleRate * 2, buf = ac.createBuffer(1, len, ac.sampleRate), data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * 0.5;
    const src = ac.createBufferSource(); src.buffer = buf; src.loop = true;
    const bp = ac.createBiquadFilter(); bp.type = 'lowpass'; bp.frequency.value = 1200;
    const hp = ac.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 300;
    const g = ac.createGain(); g.gain.value = 0.09;
    src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(master); src.start();
    rainNode = { src, g };
  }
  function stopRain() { if (rainNode) { try { rainNode.src.stop(); } catch { /* */ } rainNode = null; } }
  function loop() {
    const c = cfg(), bar = 8, t = ac.currentTime + 0.1;
    pad(CHORDS[step % CHORDS.length], t, bar);
    const n = c.mode === 'rain' ? 2 : 3 + Math.floor(Math.random() * 3);
    for (let i = 0; i < n; i++) if (Math.random() < 0.8) bell(MEL[Math.floor(Math.random() * MEL.length)] * (Math.random() < 0.3 ? 0.5 : 1), t + 0.6 + Math.random() * (bar - 1.5), c.mode === 'rain' ? 0.025 : 0.035);
    step++;
  }
  function fadeTo(v, sec = 2) { const t = ac.currentTime; master.gain.cancelScheduledValues(t); master.gain.setValueAtTime(master.gain.value, t); master.gain.linearRampToValueAtTime(v, t + sec); }
  function startGen() {
    ensure(); if (ac.state === 'suspended') ac.resume();
    if (cfg().mode === 'rain') rain(); else stopRain();
    fadeTo(cfg().vol, 3); loop(); clearInterval(timer); timer = setInterval(loop, 8000);
  }
  function stopGen() { if (!ac) return; fadeTo(0, 2); clearInterval(timer); timer = null; setTimeout(stopRain, 2100); }
  function pickFiles() {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'audio/*'; inp.multiple = true;
    inp.onchange = () => { files = Array.from(inp.files || []); fi = 0; if (files.length) { on = true; cfg().on = true; playFile(); } };
    inp.click();
  }
  function playFile() {
    if (!files.length) { pickFiles(); return; }
    if (!audio) { audio = new Audio(); audio.onended = () => { fi = (fi + 1) % files.length; playFile(); }; }
    if (audio.src) URL.revokeObjectURL(audio.src);
    audio.src = URL.createObjectURL(files[fi]); audio.volume = cfg().vol; audio.play().catch(() => {});
    U.toast('♪ ' + files[fi].name, 'info', 2500);
  }
  function stopFile() { if (audio) audio.pause(); }
  function start() { on = true; cfg().on = true; if (cfg().mode === 'file') playFile(); else startGen(); App.saveSoon(); updateBtn(); }
  function stop() { on = false; cfg().on = false; stopGen(); stopFile(); App.saveSoon(); updateBtn(); }
  function toggle() { on ? stop() : start(); }
  function setMode(m) { const was = on; if (was) stop(); cfg().mode = m; App.saveSoon(); if (was || m === 'file') start(); }
  function setVol(v) { cfg().vol = v; if (audio) audio.volume = v; if (ac && on && cfg().mode !== 'file') fadeTo(v, 0.3); App.saveSoon(); }
  // во время озвучки музыка становится тише
  function duck(isOn) { if (!on || !ac || cfg().mode === 'file') { if (audio && on) audio.volume = cfg().vol * (isOn ? 0.35 : 1); return; } fadeTo(cfg().vol * (isOn ? 0.35 : 1), 0.4); }
  function updateBtn() { const b = document.querySelector('#musicBtn'); if (b) { b.classList.toggle('on', on); b.title = on ? 'Музыка играет — нажмите, чтобы выключить' : 'Включить спокойную музыку'; } }
  function init() {
    const b = document.querySelector('#musicBtn');
    if (b) { b.innerHTML = U.icon('music', 18); b.onclick = () => toggle(); b.oncontextmenu = e => { e.preventDefault(); Voice.openSettings(); }; }
    updateBtn();
    // браузер разрешает звук только после действия пользователя — включаем музыку при первом клике
    if (cfg().on && cfg().mode !== 'file') document.addEventListener('pointerdown', () => { if (!on) start(); }, { once: true });
  }
  return { init, toggle, start, stop, setMode, setVol, duck, cfg, playing: () => on };
})();

const Voice = (() => {
  const TF = [
    { k: '15m', ms: 9e5, nom: 'пятнадцатиминутная', gen: 'пятнадцатиминутной', notes: [660] },
    { k: '1h', ms: 36e5, nom: 'часовая', gen: 'часовой', notes: [740] },
    { k: '4h', ms: 144e5, nom: 'четырёхчасовая', gen: 'четырёхчасовой', notes: [660, 880] },
    { k: '1d', ms: 864e5, nom: 'дневная', gen: 'дневной', notes: [523, 659, 784] },
    { k: '1w', ms: 6048e5, nom: 'недельная', gen: 'недельной', notes: [523, 659, 784, 1047], chord: true },
  ];
  const NAMES = { BTC: 'биткоин', ETH: 'эфир', SOL: 'солана', BNB: 'би эн би', XRP: 'рипл', DOGE: 'доги', ADA: 'кардано', TON: 'тон', LINK: 'линк', AVAX: 'авакс', TRX: 'трон', DOT: 'полкадот', LTC: 'лайткоин', SUI: 'суи', PEPE: 'пепе', HYPE: 'хайп', SHIB: 'шиба' };
  const WEEK_OFF = 3 * 864e5; // недели Binance начинаются в понедельник 00:00 UTC
  const key = (tf, t) => tf.k === '1w' ? Math.floor((t + WEEK_OFF) / tf.ms) : Math.floor(t / tf.ms);
  const start = (tf, t) => tf.k === '1w' ? key(tf, t) * tf.ms - WEEK_OFF : key(tf, t) * tf.ms;
  let last = {}, warned = {}, voices = [], actx = null;

  const cfg = () => {
    const st = App.state.settings;
    return st.voice || (st.voice = { on: false, tfs: { '15m': false, '1h': true, '4h': true, '1d': true, '1w': true }, pre: 0, summary: true, rate: 1, volume: 1, voice: '', orders: true, quiet: true, qFrom: 0, qTo: 8, mood: true, calmEvery: 15, calmOn: true, calmVoice: true });
  };

  function migrate() { const c = cfg(); if (!c.calmVoiceV2) { c.calmVoice = true; c.calmVoiceV2 = true; } }
  function loadVoices() { try { voices = speechSynthesis.getVoices(); } catch { voices = []; } }
  function pickVoice() {
    const c = cfg();
    return voices.find(v => v.voiceURI === c.voice) || voices.find(v => /^ru/i.test(v.lang)) || null;
  }

  function chime(tf) {
    const c = cfg();
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const t0 = actx.currentTime + 0.02;
      tf.notes.forEach((f, i) => {
        const at = tf.chord ? t0 + i * 0.05 : t0 + i * 0.16;
        const o = actx.createOscillator(), g = actx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, at);
        g.gain.exponentialRampToValueAtTime(0.22 * c.volume, at + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, at + (tf.chord ? 1.1 : 0.45));
        o.connect(g).connect(actx.destination);
        o.start(at); o.stop(at + 1.2);
      });
      return (tf.chord ? 0.4 : tf.notes.length * 0.16 + 0.25) * 1000;
    } catch { return 0; }
  }

  // тихие часы: ночью звучат только важные события (вход, тейк, стоп)
  function isQuiet() {
    const c = cfg(); if (!c.quiet) return false;
    const h = new Date().getHours(), a = c.qFrom ?? 0, b = c.qTo ?? 8;
    return a <= b ? h >= a && h < b : h >= a || h < b;
  }
  // интонация: хорошие новости — выше и бодрее, плохие — ниже и спокойнее
  const MOODS = { good: { pitch: 1.18, rate: 1.06 }, bad: { pitch: 0.82, rate: 0.92 }, neutral: { pitch: 1, rate: 1 } };
  function say(text, delay = 0, mood = 'neutral') {
    const c = cfg();
    setTimeout(() => {
      try {
        const u = new SpeechSynthesisUtterance(text);
        const v = pickVoice(); if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'ru-RU';
        const md = c.mood !== false ? (MOODS[mood] || MOODS.neutral) : MOODS.neutral;
        u.rate = c.rate * md.rate; u.volume = c.volume * (isQuiet() ? 0.6 : 1); u.pitch = md.pitch;
        u.onstart = () => Music.duck(true); u.onend = () => Music.duck(false); u.onerror = () => Music.duck(false);
        speechSynthesis.speak(u);
      } catch { /* без голоса */ }
    }, delay);
  }

  const num = v => {
    if (!isFinite(v)) return '';
    const a = Math.abs(v), d = a >= 1000 ? 0 : a >= 10 ? 1 : a >= 1 ? 2 : 4;
    return v.toFixed(d).replace('.', ',');
  };
  const coinName = id => { const lb = Data.label(id); return NAMES[lb.base] || lb.base; };

  async function summary(tf, boundary) {
    const ch = App.active(); if (!ch || !cfg().summary) return { text: '', mood: 'neutral' };
    try {
      const bars = await Data.klines(ch.sym, tf.k, null, 3);
      const prev = bars.find(b => b.t === boundary - tf.ms) || bars[bars.length - 2];
      if (!prev) return { text: '', mood: 'neutral' };
      const p = (prev.c - prev.o) / prev.o * 100;
      const nm = coinName(ch.sym);
      return { text: ` ${nm[0].toUpperCase() + nm.slice(1)}: прошлая свеча ${p >= 0 ? 'плюс' : 'минус'} ${Math.abs(p).toFixed(2).replace('.', ',')} процента, цена ${num(prev.c)}.`, mood: p >= 0.3 ? 'good' : p <= -0.3 ? 'bad' : 'neutral' };
    } catch { return { text: '', mood: 'neutral' }; }
  }

  async function announce(tf, boundary) {
    if (isQuiet()) return;
    const wait = chime(tf);
    const extra = await summary(tf, boundary);
    say(`Новая ${tf.nom} свеча.${extra.text}`, wait, extra.mood);
    U.toast(`🔔 Новая ${tf.nom} свеча`, 'info', 4000);
  }

  // ---------- лимитки, тейк и стоп у инструментов «Длинная / Короткая позиция» ----------
  function orderChime(kind) {
    const notes = kind === 'tp' ? [784, 1047] : kind === 'sl' ? [523, 392] : [660, 990];
    return chime({ notes, chord: false });
  }
  function event(kind, text) {
    const c = cfg();
    U.toast(text, kind === 'sl' ? 'dn' : kind === 'tp' ? 'up' : 'alert', 8000);
    if (c.orders === false) return;
    const wait = orderChime(kind);
    say(text, wait, kind === 'tp' ? 'good' : kind === 'sl' ? 'bad' : 'neutral');
  }
  function checkPositions(sym, prev, p) {
    const ds = App.state.drawings[App.dKey(sym)]; if (!ds || !ds.length) return;
    const now = Date.now(), name = coinName(sym), Nm = name[0].toUpperCase() + name.slice(1);
    let changed = false;
    for (const d of ds) {
      if ((d.type !== 'long' && d.type !== 'short') || d.closed || d.acct || !d.pts || d.pts.length < 3) continue;
      if (now < d.pts[0].t || now > d.pts[1].t + 1000) continue;
      const lg = d.type === 'long';
      const ens = d.entries && d.entries.length > 1 ? d.entries : [{ p: d.pts[0].p }];
      d.fills = d.fills || [];
      ens.forEach((en, i) => {
        if (d.fills[i]) return;
        const hit = lg ? (prev > en.p && p <= en.p) : (prev < en.p && p >= en.p);
        if (!hit) return;
        d.fills[i] = true; changed = true;
        d.fillAt = d.fillAt || []; d.fillAt[i] = Date.now();
        const which = ens.length > 1 ? `лимитка ${i + 1} из ${ens.length}` : 'лимитка';
        // новая нулевая точка — средняя по исполненным лимиткам
        let ws = ens.map(x => (+x.w > 0 ? +x.w : 0)); if (!ws.some(v => v > 0)) ws = ens.map(() => 1);
        const fw = ens.reduce((a, x, k) => a + (d.fills[k] ? ws[k] : 0), 0), zp = ens.reduce((a, x, k) => a + (d.fills[k] ? x.p * ws[k] : 0), 0) / (fw || 1);
        const n = d.fills.filter(Boolean).length;
        const zpTxt = ens.length > 1 && n > 1 ? ` Новая нулевая точка ${num(zp)}.` : '';
        event('fill', `${Nm}: ${which} по цене ${num(en.p)} ${n > 1 ? 'исполнена' : 'зашла в сделку'}. ${lg ? 'Лонг' : 'Шорт'}.${zpTxt}`);
      });
      if (!d.fills.some(Boolean)) continue;
      const st = d.pts[2].p;
      const tps = d.tps && d.tps.length > 1 ? d.tps.slice().map((t, i) => ({ ...t, i })) : [{ p: d.pts[1].p, i: 0 }];
      d.tpHits = d.tpHits || [];
      const sl = lg ? (prev > st && p <= st) : (prev < st && p >= st);
      if (sl) {
        const done = d.tpHits.filter(Boolean).length;
        d.closed = 'sl'; changed = true;
        event('sl', `${Nm}: сработал стоп-лосс по цене ${num(st)}.${done ? ` До этого закрыто тейков: ${done} из ${tps.length}.` : ''}`);
        continue;
      }
      // тейки по порядку от ближнего к дальнему
      const order = tps.slice().sort((a, b) => lg ? a.p - b.p : b.p - a.p);
      for (const t of order) {
        if (d.tpHits[t.i]) continue;
        const hit = lg ? (prev < t.p && p >= t.p) : (prev > t.p && p <= t.p);
        if (!hit) continue;
        d.tpHits[t.i] = true; changed = true;
        const n = d.tpHits.filter(Boolean).length, total = tps.length;
        if (n >= total) { d.closed = 'tp'; event('tp', total > 1 ? `${Nm}: тейк ${n} из ${total} по цене ${num(t.p)} закрыт. Все тейки взяты, позиция закрыта. Поздравляю!` : `${Nm}: тейк-профит по цене ${num(t.p)} достигнут. Поздравляю!`); }
        else event('tp', `${Nm}: тейк ${n} из ${total} по цене ${num(t.p)} закрыт.${n === 1 ? ' Можно перенести стоп в безубыток.' : ''}`);
      }
    }
    if (changed) { App.saveSoon(); App.invalidateSym(sym); }
  }

  // ---------- сводка при запуске ----------
  const plural = (n, a, b, c) => { const m = n % 10, h = n % 100; return m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 10 || h >= 20) ? b : c; };
  function greeting() { const h = new Date().getHours(); return h >= 5 && h < 12 ? 'Доброе утро!' : h >= 12 && h < 18 ? 'Добрый день!' : h >= 18 && h < 23 ? 'Добрый вечер!' : 'Доброй ночи!'; }
  const pct = v => `${v >= 0 ? 'плюс' : 'минус'} ${Math.abs(v).toFixed(1).replace('.', ',')}`;
  function buildSummary() {
    const wl = App.state.watchlist.filter(s => App.changes[s] != null && isFinite(App.changes[s]));
    const parts = [greeting()];
    const btc = 'BTCUSDT';
    if (App.changes[btc] != null) parts.push(`Биткоин ${num(App.prices[btc])}, за сутки ${pct(App.changes[btc])} процента.`);
    const others = wl.filter(s => s !== btc).sort((a, b) => App.changes[b] - App.changes[a]);
    if (others.length >= 2) {
      const best = others[0], worst = others[others.length - 1], cap = id => { const n = coinName(id); return n[0].toUpperCase() + n.slice(1); };
      parts.push(`Лучший в вашем списке ${cap(best)}, ${pct(App.changes[best])}. Слабее всех ${cap(worst)}, ${pct(App.changes[worst])}.`);
      const up = wl.filter(s => App.changes[s] > 0).length;
      parts.push(`Растут ${up} из ${wl.length}.`);
    }
    // позиции
    let live = 0, wait = 0; const now = Date.now();
    for (const ds of Object.values(App.state.drawings)) for (const d of ds) {
      if ((d.type !== 'long' && d.type !== 'short') || d.closed || !d.pts || now > d.pts[1].t) continue;
      if (d.fills && d.fills.some(Boolean)) live++; else if (now >= d.pts[0].t) wait++;
    }
    if (live) parts.push(`У вас ${live} ${plural(live, 'позиция', 'позиции', 'позиций')} в сделке.`);
    if (wait) parts.push(`${wait} ${plural(wait, 'позиция ждёт', 'позиции ждут', 'позиций ждут')} входа.`);
    const al = App.state.alerts.filter(a => a.active).length;
    if (al) parts.push(`Активных оповещений: ${al}.`);
    const day = TF[3], left = start(day, now) + day.ms - now, hh = Math.floor(left / 36e5), mm = Math.floor(left % 36e5 / 6e4);
    parts.push(`До новой дневной свечи ${hh ? `${hh} ${plural(hh, 'час', 'часа', 'часов')} ` : ''}${mm} ${plural(mm, 'минута', 'минуты', 'минут')}. Удачной торговли!`);
    return parts.join(' ');
  }
  function morning(force) {
    const c = cfg();
    if (!force && (c.morning === false || c.lastMorning === new Date().toDateString() || isQuiet())) return;
    let tries = 0;
    const go = () => {
      const wl = App.state.watchlist, have = wl.filter(s => App.changes[s] != null).length;
      if (!force && have < Math.min(3, wl.length) && tries++ < 20) { setTimeout(go, 1000); return; }
      c.lastMorning = new Date().toDateString(); App.saveSoon();
      const text = buildSummary(), bc = App.changes.BTCUSDT;
      const wait = chime({ notes: [523, 659, 784, 1047], chord: false });
      say(text, wait, bc >= 1 ? 'good' : bc <= -1 ? 'bad' : 'neutral');
      U.toast(text, 'info', 15000);
    };
    setTimeout(go, force ? 0 : 3000);
  }

  // ---------- спокойные мысли каждые N минут (собственные тексты Orbita) ----------
  const CALM = [
    'Сделайте медленный вдох. Рынок никуда не денется, а вы у себя одни.',
    'Не каждое движение цены — приглашение. Иногда лучшая сделка — та, которую вы не открыли.',
    'Вы управляете не рынком, а только своими решениями. И этого достаточно.',
    'Плечи вниз, челюсть расслаблена. Проверьте, где сейчас ваше напряжение.',
    'Убыток — это плата за обучение, а не приговор. Завтра будет новый график.',
    'Терпение — тоже позиция. И часто самая прибыльная.',
    'Стоики говорили: беспокойся только о том, что зависит от тебя. Цена от вас не зависит, план — зависит.',
    'Сделайте глоток воды. Ясная голова видит больше, чем уставшая.',
    'Хороший трейдер не тот, кто всегда прав, а тот, кто бережёт себя, когда ошибается.',
    'Посмотрите вдаль на несколько секунд. Глазам тоже нужен отдых.',
    'Вы сделали достаточно на сегодня, если действовали по плану.',
    'Тишина между сделками — не потерянное время. Это время, когда вы становитесь лучше.',
    'Свеча закрывается, начинается новая. Так и с ошибками: отпустите и смотрите вперёд.',
    'Спешка — главный враг точного входа. Дайте цене прийти к вам.',
    'Заметьте одну хорошую вещь, которая случилась сегодня. Даже маленькую.',
    'Ваша ценность не измеряется балансом счёта.',
    'Рынок вознаграждает дисциплину, а не волнение.',
    'Выдохните длиннее, чем вдохнули. Так тело понимает, что опасности нет.',
    'Мысль в духе Сенеки: мы страдаем чаще в воображении, чем в реальности.',
    'Сделайте паузу, если чувствуете азарт. Азарт любит торопиться, а прибыль — ждать.',
    'Каждый уровень на графике когда-то был просто чьим-то спокойным решением.',
    'Если день тяжёлый — можно просто наблюдать. Наблюдение тоже навык.',
    'Мысль в духе Марка Аврелия: утро начинается с того, что вы выбираете своё отношение к дню.',
    'Ваше тело не стул. Встаньте и потянитесь на минуту.',
    'Не догоняйте ушедший поезд. Следующий уже в пути.',
    'Маленький стабильный шаг лучше большого случайного прыжка.',
    'Будьте к себе так же добры, как были бы к другу после трудной сделки.',
    'Сравнивайте себя только с собой вчерашним.',
    'Спокойный ум видит уровни, тревожный — только риски.',
    'Вы уже прошли через многое. Пройдёте и через этот день.',
    'Позвольте себе маленькую улыбку. Она меняет больше, чем кажется.',
    'Хороший план не требует постоянного взгляда на экран.',
    'Мысль в духе Эпиктета: не события тревожат нас, а наши суждения о них.',
    'Отпустите сделку, которая не случилась. Она уже не ваша забота.',
    'Сделайте три медленных вдоха. Этого хватит, чтобы вернуть ясность.',
    'Рынок — это марафон. Берегите силы для длинной дистанции.',
  ];
  let bag = [];
  const nextCalm = () => { if (!bag.length) bag = CALM.map((_, i) => i).sort(() => Math.random() - 0.5); return CALM[bag.pop()]; };
  // спокойные синтезированные звуки: поющая чаша, ветряные колокольчики, тёплый аккорд
  function ctx0() { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); return actx; }
  function softVerb(ac) {
    // простая «комната»: задержка с затуханием даёт мягкий хвост
    const inp = ac.createGain(), d = ac.createDelay(1), fb = ac.createGain(), lp = ac.createBiquadFilter(), out = ac.createGain();
    d.delayTime.value = 0.23; fb.gain.value = 0.45; lp.type = 'lowpass'; lp.frequency.value = 1800; out.gain.value = 0.5;
    inp.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(out);
    return { inp, out };
  }
  function tone(ac, dest, f, at, dur, vol, type = 'sine') {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(vol, at + Math.min(0.6, dur * 0.15)); g.gain.exponentialRampToValueAtTime(0.0001, at + dur);
    o.connect(g); g.connect(dest); o.start(at); o.stop(at + dur + 0.1);
  }
  const SOUNDS = {
    bowl(ac, out, v) { // поющая чаша: основной тон и обертоны с медленными биениями
      const t = ac.currentTime + 0.05, f = 196;
      [[1, 0.12, 7], [1.004, 0.09, 7], [2.76, 0.05, 5], [5.4, 0.025, 3.5], [8.9, 0.01, 2.5]].forEach(([k, a, d]) => tone(ac, out, f * k, t, d, a * v));
    },
    chimes(ac, out, v) { // ветряные колокольчики: редкие ноты пентатоники
      const notes = [523, 587, 659, 784, 880, 1047, 1175], t = ac.currentTime + 0.05;
      for (let i = 0; i < 6; i++) { const f = notes[Math.floor(Math.random() * notes.length)]; const at = t + i * (0.35 + Math.random() * 0.45); tone(ac, out, f, at, 2.6, 0.045 * v); tone(ac, out, f * 2.01, at, 1.2, 0.012 * v); }
    },
    pad(ac, out, v) { // тёплый мягкий аккорд с медленным нарастанием
      const t = ac.currentTime + 0.05;
      [220, 277.2, 329.6, 415.3].forEach((f, i) => { const o = ac.createOscillator(), g = ac.createGain(), lp = ac.createBiquadFilter();
        o.type = 'triangle'; o.frequency.value = f * (1 + (i % 2 ? 0.002 : -0.002)); lp.type = 'lowpass'; lp.frequency.value = 900;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.035 * v, t + 1.8); g.gain.exponentialRampToValueAtTime(0.0001, t + 6);
        o.connect(lp); lp.connect(g); g.connect(out); o.start(t); o.stop(t + 6.2); });
    },
  };
  function calmSound(kind) {
    const c = cfg();
    try {
      const ac = ctx0(), master = ac.createGain(), vb = softVerb(ac);
      master.gain.value = 0.9 * c.volume;
      master.connect(ac.destination); vb.out.connect(master);
      const dry = ac.createGain(); dry.gain.value = 0.8; dry.connect(master);
      const bus = ac.createGain(); bus.connect(dry); bus.connect(vb.inp);
      const k = kind || ['bowl', 'chimes', 'pad'][Math.floor(Math.random() * 3)];
      SOUNDS[k](ac, bus, 1);
    } catch { /* без звука */ }
  }
  function calmSay(force, kind) {
    const c = cfg();
    if (!force && (isQuiet() || speechSynthesis.speaking)) return;
    const text = nextCalm();
    calmSound(kind);
    if (c.calmVoice) setTimeout(() => {
      try {
        const u = new SpeechSynthesisUtterance(text);
        const v = pickVoice(); if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'ru-RU';
        u.rate = c.rate * 0.86; u.pitch = 0.95; u.volume = c.volume * 0.7;
        u.onstart = () => Music.duck(true); u.onend = () => Music.duck(false); u.onerror = () => Music.duck(false);
        speechSynthesis.speak(u);
      } catch { /* */ }
    }, 1500);
    calmCard(text);
  }
  // мягкая карточка с мыслью: плавно появляется и тает
  function calmCard(text) {
    const old = document.querySelector('.calm-card'); if (old) old.remove();
    const el = U.h(`<div class="calm-card"><span class="calm-leaf">🌿</span><span>${U.esc(text)}</span></div>`);
    el.onclick = () => el.classList.add('out');
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => el.classList.add('out'), 14000);
    setTimeout(() => el.remove(), 16500);
  }

  // «Где цена?» — Alt+P
  async function wherePrice() {
    const ch = App.active(); if (!ch || !ch.bars.length) return;
    const nm = coinName(ch.sym), Nm = nm[0].toUpperCase() + nm.slice(1);
    const last = ch.bars[ch.bars.length - 1], p = App.prices[ch.sym] ?? last.c;
    let chg = App.changes[ch.sym];
    const cp = (p - last.o) / last.o * 100;
    let text = `${Nm} ${num(p)}.`;
    if (chg != null && isFinite(chg)) text += ` За сутки ${pct(chg)} процента.`;
    const IVW = { '1m': 'минутная', '3m': 'трёхминутная', '5m': 'пятиминутная', '15m': 'пятнадцатиминутная', '30m': 'тридцатиминутная', '1h': 'часовая', '2h': 'двухчасовая', '4h': 'четырёхчасовая', '6h': 'шестичасовая', '8h': 'восьмичасовая', '12h': 'двенадцатичасовая', '1d': 'дневная', '3d': 'трёхдневная', '1w': 'недельная', '1M': 'месячная' };
    text += ` Текущая ${IVW[ch.iv] || ''} свеча: ${pct(cp)}.`;
    try { speechSynthesis.cancel(); } catch { /* */ }
    const wait = chime({ notes: [880], chord: false });
    say(text, wait, (chg ?? cp) >= 0.5 ? 'good' : (chg ?? cp) <= -0.5 ? 'bad' : 'neutral');
    U.toast(text, 'info', 5000);
  }

  function tick() {
    const c = cfg(), now = Date.now();
    const fresh = [];
    for (const tf of TF) {
      const k = key(tf, now);
      if (last[tf.k] === undefined) { last[tf.k] = k; continue; }
      if (k !== last[tf.k]) { last[tf.k] = k; if (c.on && c.tfs[tf.k]) fresh.push(tf); }
      // предупреждение до закрытия
      if (c.on && c.pre && c.tfs[tf.k] && tf.ms > c.pre * 6e4) {
        const left = start(tf, now) + tf.ms - now, wk = tf.k + ':' + k;
        if (left <= c.pre * 6e4 && left > c.pre * 6e4 - 5000 && !warned[wk] && !isQuiet()) {
          warned[wk] = true;
          const minutes = c.pre === 1 ? 'одна минута' : `${c.pre} минут`;
          chime({ notes: [880], chord: false });
          say(`До закрытия ${tf.gen} свечи ${minutes}.`, 300);
        }
      }
    }
    if (c.calmOn && c.calmEvery) {
      const per = c.calmEvery * 6e4, kk = Math.floor((now + per / 2) / per);
      if (last.calm === undefined) last.calm = kk;
      else if (kk !== last.calm) { last.calm = kk; calmSay(); }
    }
    // если совпало несколько (например, в полночь по UTC) — объявляем самую крупную
    if (fresh.length) { const tf = fresh[fresh.length - 1]; announce(tf, start(tf, now)); }
  }

  function init() {
    migrate();
    loadVoices();
    try { speechSynthesis.onvoiceschanged = loadVoices; } catch { /* */ }
    Music.init();
    setInterval(tick, 1000);
    tick();
    morning();
    updateBtn();
  }
  function updateBtn() {
    const b = $('#voiceBtn'); if (!b) return;
    const on = cfg().on;
    b.classList.toggle('on', on);
    b.innerHTML = U.icon(on ? 'speaker' : 'speakerOff', 18);
    b.title = on ? 'Озвучка свечей включена' : 'Озвучка свечей выключена';
  }

  function openSettings() {
    const c = cfg();
    loadVoices();
    const ru = voices.filter(v => /^ru/i.test(v.lang));
    const m = U.modal({ title: 'Озвучка свечей', width: 460 });
    const nextIn = tf => { const left = start(tf, Date.now()) + tf.ms - Date.now(); return U.fmtCountdown(left); };
    m.body.innerHTML = `<div class="form">
      <label class="chk big"><input type="checkbox" id="vOn"${c.on ? ' checked' : ''}> Включить озвучку</label>
      <div class="form-title">Объявлять начало свечи</div>
      ${TF.map(tf => `<label class="chk"><input type="checkbox" data-tf="${tf.k}"${c.tfs[tf.k] ? ' checked' : ''}> ${tf.nom[0].toUpperCase() + tf.nom.slice(1)} <span class="muted">· ${'♪'.repeat(tf.notes.length)} · следующая через ${nextIn(tf)}</span></label>`).join('')}
      <div class="form-title">Позиции (длинная / короткая)</div>
      <label class="chk"><input type="checkbox" id="vOrd"${c.orders !== false ? ' checked' : ''}> Озвучивать вход лимиток, тейк и стоп <span class="muted">(работает, даже если озвучка свечей выключена)</span></label>
      <div class="form-title">Спокойные мысли</div>
      <label class="chk"><input type="checkbox" id="vCalm"${c.calmOn !== false ? ' checked' : ''}> Тихим голосом говорить что-то хорошее каждые <select class="inp mini" id="vCalmE">${[10, 15, 20, 30, 60].map(v => `<option value="${v}"${(c.calmEvery || 15) === v ? ' selected' : ''}>${v}</option>`).join('')}</select> минут</label>
      <div class="muted sm" style="margin:-4px 0 4px 26px">Сначала мягкий звук (чаша, колокольчики или аккорд), затем тихий голос. Ночью в тихие часы молчит.</div>
      <label class="chk" style="margin-left:26px"><input type="checkbox" id="vCalmV"${c.calmVoice ? ' checked' : ''}> Читать мысль голосом (после звука)</label>
      <div class="form-title">Фоновая музыка</div>
      <div class="music-row"><button class="btn ghost sm" data-m="toggle">${Music.playing() ? '⏸ Остановить' : '▶ Включить'}</button>
        <select class="inp mini" id="mMode"><option value="ambient">Спокойный эмбиент (генерируется)</option><option value="rain">Дождь и мягкие ноты</option><option value="file">Свои файлы MP3…</option></select>
        <span class="muted sm">Громкость</span><input type="range" id="mVol" min="0" max="1" step="0.05" value="${Music.cfg().vol}"></div>
      <div class="muted sm" style="margin-top:4px">Музыка создаётся прямо в программе и никогда не повторяется одинаково. Можно включить и свои MP3 — они проигрываются по кругу.</div>
      <div class="form-title">Тихие часы и интонация</div>
      <label class="chk"><input type="checkbox" id="vQuiet"${c.quiet !== false ? ' checked' : ''}> Тихо ночью: с <select class="inp mini" id="vQf">${[...Array(24).keys()].map(h => `<option value="${h}"${(c.qFrom ?? 0) === h ? ' selected' : ''}>${U.pad(h)}:00</option>`).join('')}</select> до <select class="inp mini" id="vQt">${[...Array(24).keys()].map(h => `<option value="${h}"${(c.qTo ?? 8) === h ? ' selected' : ''}>${U.pad(h)}:00</option>`).join('')}</select></label>
      <div class="muted sm" style="margin:-4px 0 4px 26px">Ночью молчат свечи, предупреждения и сводка. Вход лимиток, тейк и стоп звучат всегда, но тише.</div>
      <label class="chk"><input type="checkbox" id="vMood"${c.mood !== false ? ' checked' : ''}> Интонация: хорошие новости — бодрее и выше, плохие — ниже и спокойнее</label>
      <div class="muted sm" style="margin:-4px 0 4px 26px">«Где цена?» — нажмите <b>Alt+P</b>: голос назовёт цену и изменение активной монеты.</div>
      <div class="form-title">Сводка при запуске</div>
      <label class="chk"><input type="checkbox" id="vMorn"${c.morning !== false ? ' checked' : ''}> Озвучивать сводку при первом запуске за день <span class="muted">(биткоин, лучший и худший в списке, ваши позиции)</span></label>
      <div class="form-title">Свечи</div>
      <label class="chk"><input type="checkbox" id="vSum"${c.summary ? ' checked' : ''}> Добавлять итог прошлой свечи по активному графику</label>
      <label>Предупреждать до закрытия<select class="inp" id="vPre">${[[0, 'Нет'], [1, 'За 1 минуту'], [5, 'За 5 минут'], [15, 'За 15 минут']].map(([v, n]) => `<option value="${v}"${c.pre === v ? ' selected' : ''}>${n}</option>`).join('')}</select></label>
      <div class="form-title">Голос</div>
      ${ru.length ? `<label>Голос<select class="inp" id="vVoice">${ru.map(v => `<option value="${U.esc(v.voiceURI)}"${v.voiceURI === c.voice ? ' selected' : ''}>${U.esc(v.name)}</option>`).join('')}</select></label>`
        : `<div class="calc">На компьютере не найден русский голос. Windows: <b>Параметры → Время и язык → Речь → Добавить голоса → Русский</b>. После установки перезапустите Orbita. Пока сигналы будут звучать, а голос — системный по умолчанию.</div>`}
      <div class="muted sm">Голос берётся из Windows. Если он звучит как робот — установите голос получше (см. «Как сделать голос приятнее» ниже) и выберите его здесь.</div>
      <details class="hint"><summary>Как сделать голос приятнее</summary>
        <div class="sm">1. Windows: Параметры → Время и язык → Речь → «Добавить голоса» → Русский. Перезапустите Orbita и выберите новый голос в списке выше.<br>
        2. В Windows 11 есть «естественные» голоса для Экранного диктора (звучат почти как человек), но обычным программам они по умолчанию недоступны. Их можно подключить бесплатной сторонней утилитой NaturalVoiceSAPIAdapter (проект на GitHub) — после неё такие голоса появятся в списке.<br>
        3. Помогает и скорость речи 0,8–0,9×: голос становится спокойнее.</div></details>
      <label>Скорость речи: <b id="vRateV">${c.rate.toFixed(1)}×</b><input type="range" id="vRate" min="0.6" max="1.6" step="0.1" value="${c.rate}"></label>
      <label>Громкость: <b id="vVolV">${Math.round(c.volume * 100)}%</b><input type="range" id="vVol" min="0.1" max="1" step="0.05" value="${c.volume}"></label>
    </div>
    <div class="modal-actions"><button class="btn ghost" data-a="t1">Проверить: часовая</button><button class="btn ghost" data-a="t4">4ч</button><button class="btn ghost" data-a="td">День</button><button class="btn ghost" data-a="tl">Лимитка</button><button class="btn ghost" data-a="tm">Сводка</button><button class="btn ghost" data-a="tp">Где цена</button><button class="btn ghost" data-a="tc">Мысль</button><button class="btn ghost" data-a="sb">Чаша</button><button class="btn ghost" data-a="sc">Колокольчики</button><button class="btn ghost" data-a="sp">Аккорд</button><span class="grow"></span><button class="btn primary" data-a="ok">Готово</button></div>`;
    const apply = () => {
      c.on = $('#vOn', m.body).checked;
      $$('[data-tf]', m.body).forEach(i => { c.tfs[i.dataset.tf] = i.checked; });
      c.orders = $('#vOrd', m.body).checked; c.morning = $('#vMorn', m.body).checked;
      c.calmOn = $('#vCalm', m.body).checked; c.calmVoice = $('#vCalmV', m.body).checked; c.calmEvery = +$('#vCalmE', m.body).value;
      c.quiet = $('#vQuiet', m.body).checked; c.qFrom = +$('#vQf', m.body).value; c.qTo = +$('#vQt', m.body).value; c.mood = $('#vMood', m.body).checked;
      c.summary = $('#vSum', m.body).checked; c.pre = +$('#vPre', m.body).value;
      const vv = $('#vVoice', m.body); if (vv) c.voice = vv.value;
      c.rate = +$('#vRate', m.body).value; c.volume = +$('#vVol', m.body).value;
      $('#vRateV', m.body).textContent = c.rate.toFixed(1) + '×'; $('#vVolV', m.body).textContent = Math.round(c.volume * 100) + '%';
      updateBtn(); App.saveSoon();
    };
    $('#mMode', m.body).value = Music.cfg().mode;
    $('#mMode', m.body).onchange = ev => { ev.stopPropagation(); Music.setMode(ev.target.value); };
    $('#mVol', m.body).oninput = ev => { ev.stopPropagation(); Music.setVol(+ev.target.value); };
    m.body.oninput = apply; m.body.onchange = apply;
    m.body.onclick = e => {
      const mb = e.target.closest('[data-m]');
      if (mb) { Music.toggle(); mb.textContent = Music.playing() ? '⏸ Остановить' : '▶ Включить'; return; }
      const a = e.target.closest('[data-a]'); if (!a) return;
      const tf = { t1: TF[1], t4: TF[2], td: TF[3] }[a.dataset.a];
      if (tf) { try { speechSynthesis.cancel(); } catch { /* */ } announce(tf, start(tf, Date.now())); return; }
      if (a.dataset.a === 'tp') { wherePrice(); return; }
      if (a.dataset.a === 'sb' || a.dataset.a === 'sc' || a.dataset.a === 'sp') { calmSay(true, { sb: 'bowl', sc: 'chimes', sp: 'pad' }[a.dataset.a]); return; }
      if (a.dataset.a === 'tc') { try { speechSynthesis.cancel(); } catch { /* */ } calmSay(true); return; }
      if (a.dataset.a === 'tm') { try { speechSynthesis.cancel(); } catch { /* */ } morning(true); return; }
      if (a.dataset.a === 'tl') { const ch = App.active(); const nm = coinName(ch.sym); event('fill', `${nm[0].toUpperCase() + nm.slice(1)}: лимитка 1 из 3 по цене ${num(ch.ref)} зашла в сделку. Лонг.`); return; }
      m.close();
    };
  }
  // для календаря: сказать вслух, если голос включён
  function remind(text, mood = 'neutral') { say(text, 0, mood); return true; } // календарь: своя галочка «напоминать голосом»
  return { init, openSettings, updateBtn, checkPositions, wherePrice, remind, coinName, event: (k, t) => event(k, t) };
})();
