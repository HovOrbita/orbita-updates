'use strict';
const DRAW = (() => {
  const TOOLS = {
    trend: { n: 2, name: 'Линия тренда', icon: 'trend', key: 'Alt+T' },
    ray: { n: 2, name: 'Луч', icon: 'ray' },
    extended: { n: 2, name: 'Продолженная линия', icon: 'extended' },
    arrow: { n: 2, name: 'Стрелка', icon: 'arrowline' },
    hline: { n: 1, name: 'Горизонтальная линия', icon: 'hline', key: 'Alt+H' },
    hray: { n: 1, name: 'Горизонтальный луч', icon: 'hray' },
    vline: { n: 1, name: 'Вертикальная линия', icon: 'vline', key: 'Alt+V' },
    path: { n: -1, name: 'Ломаная со стрелкой', icon: 'path' },
    curve: { n: 3, name: 'Кривая (дуга)', icon: 'curve' },
    crossline: { n: 1, name: 'Линии-перекрестие', icon: 'crossline' },
    channel: { n: 3, name: 'Параллельный канал', icon: 'channel' },
    regression: { n: 2, name: 'Канал линейной регрессии', icon: 'regression' },
    pitchfork: { n: 3, name: 'Вилы Эндрюса', icon: 'pitchfork' },
    fib: { n: 2, name: 'Коррекция Фибоначчи', icon: 'fib', key: 'Alt+F' },
    fibext: { n: 3, name: 'Расширение Фибоначчи', icon: 'fibext' },
    fibfan: { n: 2, name: 'Веер Фибоначчи', icon: 'fibfan' },
    fibtime: { n: 2, name: 'Временные зоны Фибоначчи', icon: 'fibtime' },
    rect: { n: 2, name: 'Прямоугольник', icon: 'rect', key: 'Alt+R' },
    ellipse: { n: 2, name: 'Эллипс', icon: 'ellipse' },
    triangle: { n: 3, name: 'Треугольник', icon: 'triangle' },
    brush: { n: 0, name: 'Кисть', icon: 'brush', key: 'Alt+B' },
    highlighter: { n: 0, name: 'Маркер (выделитель)', icon: 'highlighter' },
    text: { n: 1, name: 'Текст', icon: 'text' },
    pricelabel: { n: 1, name: 'Ценовая метка', icon: 'pricelabel' },
    arrowup: { n: 1, name: 'Отметка вверх', icon: 'arrowUp' },
    arrowdown: { n: 1, name: 'Отметка вниз', icon: 'arrowDown' },
    prange: { n: 2, name: 'Диапазон цен', icon: 'priceRange' },
    drange: { n: 2, name: 'Диапазон дат', icon: 'dateRange' },
    dprange: { n: 2, name: 'Диапазон дат и цен (линейка)', icon: 'dpRange' },
    vprofile: { n: 2, name: 'Профиль объёма фиксированного диапазона', icon: 'vprofile' },
    long: { n: 1, name: 'Длинная позиция', icon: 'long' },
    short: { n: 1, name: 'Короткая позиция', icon: 'short' },
  };
  const GROUPS = [
    { id: 'lines', name: 'Линии, каналы и вилы', sec: [['Линии', ['trend', 'ray', 'extended', 'hline', 'hray', 'vline', 'crossline']], ['Каналы', ['channel', 'regression']], ['Вилы', ['pitchfork']]] },
    { id: 'fib', name: 'Фибоначчи', sec: [['Фибоначчи', ['fib', 'fibext', 'fibfan', 'fibtime']]] },
    { id: 'measure', name: 'Прогнозирование и измерения', sec: [['Прогнозирование', ['long', 'short']], ['Объём', ['vprofile']], ['Измерения', ['prange', 'drange', 'dprange']]] },
    { id: 'shapes', name: 'Фигуры и кисти', sec: [['Кисти', ['brush', 'highlighter']], ['Стрелки', ['arrow', 'path']], ['Фигуры', ['rect', 'ellipse', 'triangle', 'curve']]] },
    { id: 'notes', name: 'Текст и отметки', sec: [['Текст', ['text', 'pricelabel']], ['Отметки', ['arrowup', 'arrowdown']]] },
  ];
  GROUPS.forEach(g => { g.tools = g.sec.flatMap(x => x[1]); });
  const FIBC = ['#8b93a7', '#f0556a', '#f5a623', '#22c39a', '#2ec4b6', '#4f8cff', '#8b93a7', '#a66bff', '#ff6fb5', '#e8c547', '#3ec7e6', '#f0556a'];
  const FIB_R = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1, 1.618, 2.618];
  const FIB_E = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1, 1.272, 1.618, 2, 2.618];
  const DASH = [[], [6, 4], [2, 3]];
  const FILLABLE = ['rect', 'ellipse', 'triangle'];
  const FF = U.FF;

  function defaultStyle(t) {
    const s = { color: '#4f8cff', width: 1.5, dash: 0 };
    if (['fib', 'fibext', 'fibfan', 'fibtime'].includes(t)) s.color = '#8b93a7';
    if (FILLABLE.includes(t)) { s.color = '#a66bff'; s.fill = true; }
    if (t === 'brush') { s.color = '#f5a623'; s.width = 2; }
    if (t === 'highlighter') { s.color = '#e8c547'; s.width = 14; }
    if (t === 'path') { s.arrow = true; }
    if (t === 'text') { s.color = null; s.size = 14; }
    if (t === 'vprofile') { s.color = null; s.rows = 24; s.va = 70; }
    if (t === 'arrowup') s.color = '#22c39a';
    if (t === 'arrowdown') s.color = '#f0556a';
    if (['channel', 'regression', 'pitchfork'].includes(t)) s.color = '#2ec4b6';
    return s;
  }

  const seg = (a, b) => { const p = new Path2D(); p.moveTo(a.x, a.y); p.lineTo(b.x, b.y); return p; };
  const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
  function ext(a, b) {
    const dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy);
    if (!len) return b;
    const k = 20000 / len;
    return { x: a.x + dx * k, y: a.y + dy * k };
  }
  const poly = pts => { const p = new Path2D(); pts.forEach((q, i) => i ? p.lineTo(q.x, q.y) : p.moveTo(q.x, q.y)); p.closePath(); return p; };

  const LIVE = new WeakMap(); // состояние позиций (в сделке, нулевая точка) — для окошка с прибылью
  function build(ch, d, P) {
    const th = ch.app.th, s = d.style || {}, col = s.color || th.text, w = s.width || 1.5, dash = DASH[s.dash || 0];
    const g = { strokes: [], fills: [], texts: [], handles: P.slice() };
    const L = (a, b, o = {}) => g.strokes.push({ p: seg(a, b), c: o.c || col, w: o.w || w, dash: o.dash || dash });
    const F = (path, c, hit = true) => g.fills.push({ p: path, c, hit });
    const T0 = (t, x, y, o = {}) => g.texts.push({ t, x, y, c: o.c || col, align: o.align || 'left', base: o.base || 'bottom', font: o.font, bg: o.bg, pad: o.pad });
    const top = ch.main.top, bot = ch.main.top + ch.main.h, W = ch.plotW;
    const fmt = v => U.fmt(v, ch.ref);
    const T = T0;
    const pts = d.pts;
    const A = P[0], B = P[1] || P[0], Cp = P[2] || P[1] || P[0];
    const small = `11px ${FF}`;
    const FC = k => s.mono ? col : FIBC[k % FIBC.length];
    switch (d.type) {
      case 'trend':
        L(A, s.extR ? ext(A, B) : B);
        if (s.label) { const lx = Math.min(B.x, W - 8); T(s.label, lx - 6, (A.y + (B.y - A.y) * ((lx - A.x) / ((B.x - A.x) || 1))) - 6, { font: small, align: 'right' }); }
        break;
      case 'path': {
        const p = new Path2D(); P.forEach((q, i) => i ? p.lineTo(q.x, q.y) : p.moveTo(q.x, q.y));
        g.strokes.push({ p, c: col, w, dash });
        if (s.arrow !== false && P.length >= 2) {
          const a = P[P.length - 2], b = P[P.length - 1], ang = Math.atan2(b.y - a.y, b.x - a.x), hl = 12, h = new Path2D();
          h.moveTo(b.x - hl * Math.cos(ang - 0.45), b.y - hl * Math.sin(ang - 0.45)); h.lineTo(b.x, b.y); h.lineTo(b.x - hl * Math.cos(ang + 0.45), b.y - hl * Math.sin(ang + 0.45));
          g.strokes.push({ p: h, c: col, w, dash: [] });
        }
        break;
      }
      case 'curve': {
        if (!P[2]) { L(A, B); break; }
        const cp = { x: 2 * P[2].x - (A.x + B.x) / 2, y: 2 * P[2].y - (A.y + B.y) / 2 };
        const p = new Path2D(); p.moveTo(A.x, A.y); p.quadraticCurveTo(cp.x, cp.y, B.x, B.y);
        g.strokes.push({ p, c: col, w, dash });
        break;
      }
      case 'ray': L(A, ext(A, B)); break;
      case 'extended': L(ext(B, A), ext(A, B)); break;
      case 'arrow': {
        L(A, B);
        const ang = Math.atan2(B.y - A.y, B.x - A.x), hl = 12, p = new Path2D();
        p.moveTo(B.x - hl * Math.cos(ang - 0.45), B.y - hl * Math.sin(ang - 0.45));
        p.lineTo(B.x, B.y);
        p.lineTo(B.x - hl * Math.cos(ang + 0.45), B.y - hl * Math.sin(ang + 0.45));
        g.strokes.push({ p, c: col, w, dash: [] });
        break;
      }
      case 'hline': L({ x: -5, y: A.y }, { x: W + 5, y: A.y }); T(fmt(pts[0].p), W - 6, A.y - 3, { align: 'right', font: small }); break;
      case 'hray': L(A, { x: W + 5, y: A.y }); T(fmt(pts[0].p), W - 6, A.y - 3, { align: 'right', font: small }); break;
      case 'vline': L({ x: A.x, y: top - 5 }, { x: A.x, y: bot + 5 }); break;
      case 'crossline': L({ x: -5, y: A.y }, { x: W + 5, y: A.y }); L({ x: A.x, y: top - 5 }, { x: A.x, y: bot + 5 }); break;
      case 'channel': {
        const k = (B.y - A.y) / ((B.x - A.x) || 1e-9), off = Cp.y - (A.y + k * (Cp.x - A.x));
        const A2 = { x: A.x, y: A.y + off }, B2 = { x: B.x, y: B.y + off };
        F(poly([A, B, B2, A2]), U.hexA(col, 0.08), false);
        L(A, B); L(A2, B2); L(mid(A, A2), mid(B, B2), { dash: [4, 4], w: 1 });
        g.handles = [A, B, mid(A2, B2)];
        break;
      }
      case 'regression': {
        const i0 = Math.round(ch.timeToIdx(pts[0].t)), i1 = Math.round(ch.timeToIdx((pts[1] || pts[0]).t));
        const a = Math.max(0, Math.min(i0, i1)), b = Math.min(ch.bars.length - 1, Math.max(i0, i1));
        if (b - a < 2) { L(A, B); break; }
        let n = b - a + 1, sx = 0, sy = 0, sxx = 0, sxy = 0;
        for (let i = a; i <= b; i++) { const y = ch.bars[i].c, x = i - a; sx += x; sy += y; sxx += x * x; sxy += x * y; }
        const m = (n * sxy - sx * sy) / ((n * sxx - sx * sx) || 1), c0 = (sy - m * sx) / n;
        let ss = 0; for (let i = a; i <= b; i++) { const r = ch.bars[i].c - (c0 + m * (i - a)); ss += r * r; }
        const sd = Math.sqrt(ss / n) * 2;
        const pt = (i, o) => ({ x: ch.idxToX(i), y: ch.priceToY(c0 + m * (i - a) + o) });
        const M1 = pt(a, 0), M2 = pt(b, 0), U1 = pt(a, sd), U2 = pt(b, sd), D1 = pt(a, -sd), D2 = pt(b, -sd);
        F(poly([U1, U2, D2, D1]), U.hexA(col, 0.08), false);
        L(M1, M2, { dash: [5, 4] }); L(U1, U2); L(D1, D2);
        g.handles = i0 <= i1 ? [M1, M2] : [M2, M1];
        break;
      }
      case 'pitchfork': {
        const M = mid(B, Cp), dx = M.x - A.x, dy = M.y - A.y, far = p => ({ x: p.x + dx * 50, y: p.y + dy * 50 });
        F(poly([B, far(B), far(Cp), Cp]), U.hexA(col, 0.06), false);
        L(A, far(A)); L(B, far(B)); L(Cp, far(Cp)); L(B, Cp, { w: 1 });
        break;
      }
      case 'fib': {
        const p0 = pts[0].p, p1 = (pts[1] || pts[0]).p, x0 = Math.min(A.x, B.x), x1 = s.extend ? W + 5 : Math.max(A.x, B.x);
        let prevY = null;
        FIB_R.forEach((lv, k) => {
          const pr = p1 + (p0 - p1) * lv, y = ch.priceToY(pr), c = FC(k);
          if (prevY !== null) { const r = new Path2D(); r.rect(x0, Math.min(prevY, y), x1 - x0, Math.abs(y - prevY)); F(r, U.hexA(c, 0.07), false); }
          L({ x: x0, y }, { x: x1, y }, { c, w: 1, dash: [] });
          T(`${lv} (${fmt(pr)})`, x0 + 4, y - 2, { c, font: small });
          prevY = y;
        });
        L(A, B, { dash: [4, 4], w: 1 });
        break;
      }
      case 'fibext': {
        const pa = pts[0].p, pb = (pts[1] || pts[0]).p, pc = (pts[2] || pts[1] || pts[0]).p;
        const span = Math.max(60, Math.abs(B.x - A.x)), x0 = Cp.x, x1 = s.extend ? W + 5 : Cp.x + span;
        FIB_E.forEach((lv, k) => {
          const pr = pc + (pb - pa) * lv, y = ch.priceToY(pr), c = FC(k);
          L({ x: x0, y }, { x: x1, y }, { c, w: 1, dash: [] });
          T(`${lv} (${fmt(pr)})`, x0 + 4, y - 2, { c, font: small });
        });
        L(A, B, { dash: [4, 4], w: 1 }); L(B, Cp, { dash: [4, 4], w: 1 });
        break;
      }
      case 'fibfan': {
        [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1].forEach((lv, k) => {
          const tg = { x: B.x, y: B.y + (A.y - B.y) * lv }, c = FC(k);
          L(A, ext(A, tg), { c, w: 1 });
          T(String(lv), tg.x + 4, tg.y - 2, { c, font: small });
        });
        break;
      }
      case 'fibtime': {
        const i0 = ch.timeToIdx(pts[0].t), i1 = ch.timeToIdx((pts[1] || pts[0]).t), dd = i1 - i0;
        [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144].forEach((k, j) => {
          if (dd === 0 && k > 0) return;
          const x = ch.idxToX(i0 + dd * k), c = FC(j);
          L({ x, y: top - 5 }, { x, y: bot + 5 }, { c, w: 1 });
          T(String(k), x + 3, top + 16, { c, font: small });
        });
        break;
      }
      case 'rect': {
        const rx0 = Math.min(A.x, B.x), rx1 = s.extend ? W + 5 : Math.max(A.x, B.x);
        const r = new Path2D(); r.rect(rx0, Math.min(A.y, B.y), rx1 - rx0, Math.abs(B.y - A.y));
        if (s.fill) F(r, U.hexA(col, s.fa != null ? s.fa : 0.15)); else F(r, 'rgba(0,0,0,0)'); // клик внутри тоже выделяет
        if (s.label) T(s.label, Math.max(rx0, 0) + 6, Math.min(A.y, B.y) - 3, { font: small });
        g.strokes.push({ p: r, c: col, w, dash });
        { // стрелки ◀▶ на левой и правой стороне — меняют только ширину зоны
          const my = (A.y + B.y) / 2, li = A.x <= B.x ? 0 : 1;
          g.handles.push({ x: rx0, y: my, kind: 'w', side: 'l', pi: li });
          if (!s.extend) g.handles.push({ x: rx1, y: my, kind: 'w', side: 'r', pi: 1 - li });
        }
        break;
      }
      case 'ellipse': {
        const e = new Path2D(); e.ellipse((A.x + B.x) / 2, (A.y + B.y) / 2, Math.abs(B.x - A.x) / 2 || 0.1, Math.abs(B.y - A.y) / 2 || 0.1, 0, 0, Math.PI * 2);
        if (s.fill) F(e, U.hexA(col, 0.15)); else F(e, 'rgba(0,0,0,0)');
        g.strokes.push({ p: e, c: col, w, dash });
        break;
      }
      case 'triangle': {
        const t = poly([A, B, Cp]);
        if (s.fill) F(t, U.hexA(col, 0.15));
        g.strokes.push({ p: t, c: col, w, dash });
        break;
      }
      case 'brush': case 'highlighter': {
        // сглаженная линия через середины отрезков
        const p = new Path2D();
        if (P.length) p.moveTo(P[0].x, P[0].y);
        for (let i = 1; i < P.length - 1; i++) { const mx = (P[i].x + P[i + 1].x) / 2, my = (P[i].y + P[i + 1].y) / 2; p.quadraticCurveTo(P[i].x, P[i].y, mx, my); }
        if (P.length > 1) p.lineTo(P[P.length - 1].x, P[P.length - 1].y);
        const hl = d.type === 'highlighter';
        g.strokes.push({ p, c: hl ? U.hexA(col, 0.35) : col, w, dash: hl ? [] : dash, round: true });
        g.handles = [];
        break;
      }
      case 'text': {
        const sz = s.size || 14;
        T(d.text || 'Текст', A.x, A.y, { font: `${s.bold ? '600 ' : ''}${sz}px ${FF}`, base: 'top', bg: s.bg ? U.hexA(col, 0.15) : null });
        break;
      }
      case 'pricelabel': {
        const txt = fmt(pts[0].p), font = `600 12px ${FF}`;
        ch.ctx.font = font;
        const tw = ch.ctx.measureText(txt).width, bx = A.x + 10, by = A.y - 32, bw = tw + 16, bh = 22;
        const p = new Path2D(); p.roundRect(bx, by, bw, bh, 4);
        p.moveTo(bx + 4, by + bh); p.lineTo(A.x, A.y); p.lineTo(bx + 14, by + bh); p.closePath();
        F(p, col);
        T(txt, bx + 8, by + bh / 2, { c: '#fff', font, base: 'middle' });
        break;
      }
      case 'arrowup': case 'arrowdown': {
        const sgn = d.type === 'arrowup' ? 1 : -1, y0 = A.y + 3 * sgn;
        F(poly([{ x: A.x, y: y0 }, { x: A.x - 9, y: y0 + 11 * sgn }, { x: A.x - 4, y: y0 + 11 * sgn }, { x: A.x - 4, y: y0 + 24 * sgn }, { x: A.x + 4, y: y0 + 24 * sgn }, { x: A.x + 4, y: y0 + 11 * sgn }, { x: A.x + 9, y: y0 + 11 * sgn }]), col);
        break;
      }
      case 'prange': case 'drange': case 'dprange': {
        const p0 = pts[0].p, p1 = (pts[1] || pts[0]).p, t0 = pts[0].t, t1 = (pts[1] || pts[0]).t;
        const up = p1 >= p0, c = d.type === 'drange' ? col : (up ? th.up : th.down);
        const r = new Path2D(); r.rect(Math.min(A.x, B.x), Math.min(A.y, B.y), Math.abs(B.x - A.x), Math.abs(B.y - A.y));
        F(r, U.hexA(c, 0.15));
        const mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2;
        const head = (a, b) => { const ang = Math.atan2(b.y - a.y, b.x - a.x), p = new Path2D(); p.moveTo(b.x - 8 * Math.cos(ang - 0.5), b.y - 8 * Math.sin(ang - 0.5)); p.lineTo(b.x, b.y); p.lineTo(b.x - 8 * Math.cos(ang + 0.5), b.y - 8 * Math.sin(ang + 0.5)); g.strokes.push({ p, c, w: 1.5, dash: [] }); };
        const lines = [];
        const i0 = ch.timeToIdx(t0), i1 = ch.timeToIdx(t1);
        if (d.type !== 'drange') { L({ x: mx, y: A.y }, { x: mx, y: B.y }, { c, w: 1.5, dash: [] }); head({ x: mx, y: A.y }, { x: mx, y: B.y }); lines.push(`${up ? '+' : ''}${fmt(p1 - p0)} (${up ? '+' : ''}${((p1 - p0) / p0 * 100).toFixed(2)}%)`); }
        if (d.type !== 'prange') {
          L({ x: A.x, y: my }, { x: B.x, y: my }, { c, w: 1.5, dash: [] }); head({ x: A.x, y: my }, { x: B.x, y: my });
          lines.push(`${Math.round(i1 - i0)} бар., ${U.fmtDur(t1 - t0)}`);
          let vol = 0; const a = Math.max(0, Math.round(Math.min(i0, i1))), b = Math.min(ch.bars.length - 1, Math.round(Math.max(i0, i1)));
          for (let i = a; i <= b; i++) vol += ch.bars[i].v;
          if (d.type === 'dprange') lines.push(`Объём ${U.fmtVol(vol)}`);
        }
        const below = d.type === 'drange' ? true : !up;
        T(lines.join('\n'), mx, below ? Math.max(A.y, B.y) + 8 : Math.min(A.y, B.y) - 8, { c: '#fff', bg: c, align: 'center', base: below ? 'top' : 'bottom', font: `12px ${FF}` });
        break;
      }
      case 'vprofile': {
        const i0 = Math.round(ch.timeToIdx(pts[0].t)), i1 = Math.round(ch.timeToIdx((pts[1] || pts[0]).t));
        const a = Math.max(0, Math.min(i0, i1)), b = Math.min(ch.bars.length - 1, Math.max(i0, i1));
        const xa = ch.idxToX(Math.min(i0, i1)) - ch.spacing / 2, xb = ch.idxToX(Math.max(i0, i1)) + ch.spacing / 2;
        if (b < a) { g.handles = [A, B]; break; }
        let lo = Infinity, hi = -Infinity;
        for (let i = a; i <= b; i++) { const x = ch.bars[i]; if (x.l < lo) lo = x.l; if (x.h > hi) hi = x.h; }
        if (!(hi > lo)) hi = lo * 1.001 + 1e-9;
        const rows = s.rows || 24, step = (hi - lo) / rows, up = new Float64Array(rows), dn = new Float64Array(rows);
        for (let i = a; i <= b; i++) {
          const x = ch.bars[i], rng = Math.max(x.h - x.l, 1e-12), isUp = x.c >= x.o;
          const r0 = Math.max(0, Math.floor((x.l - lo) / step)), r1 = Math.min(rows - 1, Math.floor((x.h - lo) / step));
          for (let r = r0; r <= r1; r++) {
            const bl = lo + r * step, bh = bl + step;
            const ov = x.h === x.l ? 1 / (r1 - r0 + 1) : Math.max(0, Math.min(bh, x.h) - Math.max(bl, x.l)) / rng;
            if (isUp) up[r] += x.v * ov; else dn[r] += x.v * ov;
          }
        }
        const tot = new Float64Array(rows); let total = 0, poc = 0;
        for (let r = 0; r < rows; r++) { tot[r] = up[r] + dn[r]; total += tot[r]; if (tot[r] > tot[poc]) poc = r; }
        // зона стоимости (Value Area)
        let vaLo = poc, vaHi = poc, acc = tot[poc];
        const target = total * (s.va || 70) / 100;
        while (acc < target && (vaLo > 0 || vaHi < rows - 1)) {
          const nu = vaHi < rows - 1 ? tot[vaHi + 1] : -1, nd = vaLo > 0 ? tot[vaLo - 1] : -1;
          if (nu >= nd) { vaHi++; acc += nu; } else { vaLo--; acc += nd; }
        }
        const box = new Path2D(); const yTop = ch.priceToY(hi), yBot = ch.priceToY(lo);
        box.rect(xa, yTop, xb - xa, yBot - yTop);
        F(box, U.hexA(th.textDim, 0.05));
        const maxW = (xb - xa) * 0.7, mx = tot[poc] || 1;
        for (let r = 0; r < rows; r++) {
          if (!tot[r]) continue;
          const y1 = ch.priceToY(lo + (r + 1) * step), y2 = ch.priceToY(lo + r * step), hh = Math.max(1, y2 - y1 - 1);
          const inVa = r >= vaLo && r <= vaHi, al = inVa ? 0.55 : 0.22;
          const wu = up[r] / mx * maxW, wd = dn[r] / mx * maxW;
          const pu = new Path2D(); pu.rect(xa, y1, wu, hh); F(pu, U.hexA(s.upColor || th.up, al), false);
          const pd = new Path2D(); pd.rect(xa + wu, y1, wd, hh); F(pd, U.hexA(s.dnColor || th.down, al), false);
        }
        const pocP = lo + (poc + 0.5) * step, yP = ch.priceToY(pocP);
        L({ x: xa, y: yP }, { x: xb, y: yP }, { c: s.pocColor || '#e8c547', w: 1.5, dash: [] });
        const yVH = ch.priceToY(lo + (vaHi + 1) * step), yVL = ch.priceToY(lo + vaLo * step);
        L({ x: xa, y: yVH }, { x: xb, y: yVH }, { c: U.hexA(th.textDim, 0.8), w: 1, dash: [4, 3] });
        L({ x: xa, y: yVL }, { x: xb, y: yVL }, { c: U.hexA(th.textDim, 0.8), w: 1, dash: [4, 3] });
        T(`POC ${fmt(pocP)}`, xb - 4, yP - 3, { c: s.pocColor || '#e8c547', align: 'right', font: small });
        T(`VAH ${fmt(lo + (vaHi + 1) * step)}`, xb - 4, yVH - 3, { c: th.textDim, align: 'right', font: small });
        T(`VAL ${fmt(lo + vaLo * step)}`, xb - 4, yVL + 3, { c: th.textDim, align: 'right', base: 'top', font: small });
        T(`Объём ${U.fmtVol(total)} · ${b - a + 1} бар.`, (xa + xb) / 2, yBot + 6, { c: '#fff', bg: '#4a5568', align: 'center', base: 'top', font: small });
        const hp = i => ({ x: ch.idxToX(i), y: i === i0 ? yTop : yBot });
        g.handles = [hp(i0), hp(i1)];
        break;
      }
      case 'long': case 'short': {
        if (pts.length < 3) break;
        const isLong = d.type === 'long', tpC = s.tpColor || th.up, slC = s.slColor || th.down;
        // подписи видны только у выделенной позиции (или всегда — если включено в настройках)
        const showLbl = s.alwaysLabels || ch.selected === d || (ch.creating && ch.creating.d === d) || (ch.drag && ch.drag.d === d);
        const T = showLbl ? T0 : () => {};
        const dpr = window.devicePixelRatio || 1, px = v => Math.round(v * dpr) / dpr, hair = Math.max(1, Math.round(dpr)) / dpr;
        const e = pts[0].p, tg = pts[1].p, st = pts[2].p;
        const x0 = px(Math.min(A.x, P[1].x)), x1 = px(Math.max(A.x, P[1].x)), ww = Math.max(2, x1 - x0);
        const yE = px(A.y), yT = px(P[1].y), yS = px(P[2].y);
        const ctx2 = ch.ctx;
        // зоны с мягким градиентом: у входа почти прозрачно, к краю насыщеннее
        const zone = (yA, yB, c) => {
          const r = new Path2D(); r.rect(x0, Math.min(yA, yB), ww, Math.abs(yB - yA));
          const gr = ctx2.createLinearGradient(0, yA, 0, yB);
          gr.addColorStop(0, U.hexA(c, 0.04)); gr.addColorStop(1, U.hexA(c, 0.17));
          F(r, gr);
          const edge = new Path2D(); edge.rect(x0, yB - (yB < yA ? 0 : hair), ww, hair); F(edge, U.hexA(c, 0.95), false);
        };
        zone(yE, yT, tpC); zone(yE, yS, slC);
        // ---- состояние сделки по свечам: ожидание → в сделке → тейк / стоп ----
        const bars = ch.bars, nb = bars.length;
        // позиция с биржи могла открыться внутри текущей свечи — тогда начинаем с последней свечи
        const iS0 = Math.max(0, Math.ceil(ch.timeToIdx(pts[0].t) - 1e-6)), iS = d.acct ? Math.min(iS0, nb - 1) : iS0, iEnd = Math.min(nb - 1, Math.floor(ch.timeToIdx(pts[1].t) + 1e-6));
        // лимитки: вход в сделку — по ПЕРВОЙ исполненной, нулевая точка — средняя по исполненным (с учётом долей)
        const ensAll = d.entries && d.entries.length > 1 ? d.entries : [{ p: e, w: 100 }];
        let ws = ensAll.map(en => (+en.w > 0 ? +en.w : 0)); if (!ws.some(v => v > 0)) ws = ensAll.map(() => 1);
        const wSum = ws.reduce((a, v) => a + v, 0);
        const fillBar = ensAll.map(() => -1);
        let state = 'wait', iIn = -1;
        if (d.acct) { // позиция с биржи: что исполнено и открыта ли — знает биржа
          (d.fills || []).forEach((f, k) => { if (f && k < fillBar.length) fillBar[k] = iS; });
          if (fillBar.some(v => v >= 0)) iIn = iS;
          state = !d.acct.open ? 'acctClosed' : iIn >= 0 ? 'live' : 'wait';
        }
        for (let i = d.acct ? nb : iS; i <= iEnd; i++) {
          const bb = bars[i];
          ensAll.forEach((en, k) => { if (fillBar[k] < 0 && (isLong ? bb.l <= en.p : bb.h >= en.p)) fillBar[k] = i; });
          if (iIn < 0) { if (!fillBar.some(v => v >= 0)) continue; iIn = i; }
          const hitS = isLong ? bb.l <= st : bb.h >= st, hitT = isLong ? bb.h >= tg : bb.l <= tg;
          if (hitS) { state = 'loss'; break; }
          if (hitT) { state = 'win'; break; }
        }
        // то, что поймал живой поток цен (между свечами), тоже считаем исполненным
        if (!d.acct && d.fills) d.fills.forEach((f, k) => { if (f && k < fillBar.length && fillBar[k] < 0) { fillBar[k] = nb - 1; if (iIn < 0) iIn = nb - 1; } });
        if (!d.acct && iIn >= 0 && state === 'wait') state = iEnd === nb - 1 ? 'live' : 'expired';
        const filledW = ensAll.reduce((a, en, k) => a + (fillBar[k] >= 0 ? ws[k] : 0), 0);
        const zp = filledW > 0 ? ensAll.reduce((a, en, k) => a + (fillBar[k] >= 0 ? en.p * ws[k] : 0), 0) / filledW : e;
        const nF = fillBar.filter(v => v >= 0).length, nT = ensAll.length, multi = nT > 1;
        const yZ = px(ch.priceToY(zp));
        const mixW = (c, k) => { const h = U.toHex(c), n = parseInt(h.slice(1), 16); const r = (n >> 16) & 255, gg = (n >> 8) & 255, bl = n & 255; return '#' + [r, gg, bl].map(v => Math.round(v + (255 - v) * k).toString(16).padStart(2, '0')).join(''); };
        let liveTxt = '';
        if (state === 'live') {
          const cur = bars[nb - 1].c, yC = px(ch.priceToY(cur)), profit = isLong ? cur >= zp : cur <= zp;
          const xIn = Math.max(x0, px(ch.idxToX(iIn) - ch.spacing / 2)), wIn = Math.max(2, x1 - xIn);
          const c = profit ? mixW(tpC, 0.45) : mixW(slC, 0.4);
          const top = Math.min(yZ, yC), h = Math.abs(yC - yZ);
          // мягкое свечение вокруг и яркая заливка от входа до текущей цены
          const k = profit ? 1 : 0.6; // красный в минусе — мягче
          const glow = new Path2D(); glow.rect(xIn - 3, top - 3, wIn + 6, h + 6); F(glow, U.hexA(c, 0.05 * k), false);
          const r = new Path2D(); r.rect(xIn, top, wIn, h);
          const gr = ctx2.createLinearGradient(0, yZ, 0, yC); gr.addColorStop(0, U.hexA(c, 0.08 * k)); gr.addColorStop(1, U.hexA(c, 0.26 * k));
          F(r, gr, false);
          const ln = new Path2D(); ln.rect(xIn, yC - hair, wIn, hair * 2); F(ln, U.hexA(c, profit ? 0.85 : 0.65), false);
          const pnl = (cur - zp) / zp * 100 * (isLong ? 1 : -1);
          liveTxt = `   ●  в сделке${multi ? ` ${nF}/${nT}` : ''} ${pnl >= 0 ? '+' : ''}${pnl.toFixed(2)}%`;
        } else if (state === 'win' || state === 'loss') {
          const yA = state === 'win' ? yT : yS, c = state === 'win' ? tpC : slC;
          const r = new Path2D(); r.rect(x0, Math.min(yZ, yA), ww, Math.abs(yA - yZ)); F(r, U.hexA(c, 0.08), false);
          liveTxt = state === 'win' ? '   ✓ тейк достигнут' : '   ✕ сработал стоп';
        } else if (state === 'expired') liveTxt = '   срок вышел';
        else if (state === 'acctClosed') liveTxt = d.acct.exit ? `   закрыта по ${fmt(d.acct.exit)}${d.acct.pnl != null ? ` · ${d.acct.pnl >= 0 ? '+' : '−'}$${Math.abs(d.acct.pnl).toFixed(2)}` : ''}` : '   сделка закрыта';
        else liveTxt = '   ожидание входа';
        const fee = (s.fee || 0) / 100;
        const be = fee ? (isLong ? e * (1 + fee) / (1 - fee) : e * (1 - fee) / (1 + fee)) : e;
        const tpl = d.tps && d.tps.length > 1 ? d.tps : null;
        const exitP = tpl ? (() => { const tw = tpl.reduce((a, x) => a + (+x.w || 0), 0); return tw > 0 ? tpl.reduce((a, x) => a + x.p * (+x.w || 0), 0) / tw : tpl.reduce((a, x) => a + x.p, 0) / tpl.length; })() : tg;
        const tp = (tg - e) / e * 100, sp = (st - e) / e * 100, rr = Math.abs((exitP - be) / ((be - st) || 1e-12));
        const vx0 = Math.max(x0, 0), vx1 = Math.min(x1, ch.plotW - 8), mx = Math.round(vx1 > vx0 ? (vx0 + vx1) / 2 : (x0 + x1) / 2);
        const ens = d.entries && d.entries.length > 1 ? d.entries : null;
        // подпись слева в позиции, но если у правого края не помещается — сдвигаем влево
        const lx = (txt, font) => { ctx2.font = font; const w = ctx2.measureText(txt).width; return Math.max(4, Math.min(x0 + 6, ch.plotW - 10 - w)); };
        if (ens) {
          const tw = ens.reduce((q, en) => q + (+en.w || 0), 0) || ens.length;
          ens.forEach((en, k) => {
            const y = px(ch.priceToY(en.p));
            L({ x: x0, y }, { x: x1, y }, { c: U.hexA(th.text, 0.45), w: 1, dash: [2, 3] });
            if (fillBar[k] >= 0 && Math.abs(y - yZ) < 14 && nF < nT) return; // совпадает с нулевой точкой — подпись уже есть
            const lt = `${d.acct && fillBar[k] >= 0 ? 'Позиция' : `${fillBar[k] >= 0 ? '✓ ' : ''}Лимит ${k + 1}`} · ${fmt(en.p)} · ${((+en.w || (tw === ens.length ? 1 : 0)) / tw * 100).toFixed(0)}%`, lf2 = `${fillBar[k] >= 0 ? 600 : 500} 10.5px ${FF}`;
            T(lt, lx(lt, lf2), y - 3, { c: U.hexA(th.text, fillBar[k] >= 0 ? 1 : 0.85), font: lf2 });
          });
        }
        if (tpl) {
          const tw = tpl.reduce((q, x) => q + (+x.w || 0), 0) || tpl.length;
          tpl.forEach((t, k) => {
            const y = px(ch.priceToY(t.p)), hit = d.tpHits && d.tpHits[k];
            if (Math.abs(y - yT) > 1) L({ x: x0, y }, { x: x1, y }, { c: U.hexA(tpC, hit ? 0.9 : 0.55), w: 1, dash: hit ? [] : [4, 3] });
            T(`${hit ? '✓ ' : ''}Тейк ${k + 1} · ${fmt(t.p)} · ${(((+t.w || (tw === tpl.length ? 1 : 0)) / tw) * 100).toFixed(0)}%`, x1 - 6, y + (isLong ? 3 : -3), { c: U.hexA(tpC, 0.95), align: 'right', base: isLong ? 'top' : 'bottom', font: `500 10.5px ${FF}` });
          });
        }
        const inTrade = nF > 0 && (state === 'live' || state === 'win' || state === 'loss' || state === 'acctClosed');
        if (inTrade && multi && Math.abs(yZ - yE) > 0.5) {
          L({ x: x0, y: yE }, { x: x1, y: yE }, { c: U.hexA(th.text, 0.35), w: 1, dash: [3, 3] }); // плановая средняя
          const zl = new Path2D(); zl.rect(x0, yZ - hair / 2, ww, hair); F(zl, '#e8c547', false);
          const zt = `Нулевая точка ${fmt(zp)} · вход ${nF}/${nT}`, zf = `600 10.5px ${FF}`;
          T(zt, lx(zt, zf), yZ + (isLong ? 3 : -3), { c: '#e8c547', base: isLong ? 'top' : 'bottom', font: zf });
        } else { const ent = new Path2D(); ent.rect(x0, yE - hair / 2, ww, hair); F(ent, U.hexA(th.text, 0.85), false); }
        // для окошка с прибылью на графике
        LIVE.set(d, { state, zp, nF, nT, share: filledW / wSum, tIn: iIn >= 0 && bars[iIn] ? bars[iIn].t : 0, isLong, fee: (s.fee || 0) / 100 });
        if (fee) { const yb = px(ch.priceToY(be)); L({ x: x0, y: yb }, { x: x1, y: yb }, { c: '#e8c547', w: 1, dash: [4, 3] }); T(`Безубыток ${fmt(be)}`, x1 - 6, yb + (isLong ? -3 : 3), { c: '#e8c547', align: 'right', base: isLong ? 'bottom' : 'top', font: `500 10.5px ${FF}` }); }
        const lf = `600 11px ${FF}`, sgn = v => (v >= 0 ? '+' : '') + v.toFixed(2) + '%';
        const cx = d.acct && !d.acct.open && d.acct.exit; // закрытая сделка с биржи: линия = средняя цена закрытия
        T(`${cx && d.acct.win ? 'Закрыто, ср. цена' : tpl ? `Тейк ${tpl.length}` : 'Тейк'}  ${fmt(tg)}   ${sgn(tp)}`, mx, yT < yE ? yT - 5 : yT + 5, { c: '#fff', bg: U.hexA(tpC, 0.92), align: 'center', base: yT < yE ? 'bottom' : 'top', font: lf, pad: 5 });
        T(`${cx && !d.acct.win ? 'Закрыто, ср. цена' : 'Стоп'}  ${fmt(st)}   ${sgn(sp)}`, mx, yS < yE ? yS - 5 : yS + 5, { c: '#fff', bg: U.hexA(slC, 0.92), align: 'center', base: yS < yE ? 'bottom' : 'top', font: lf, pad: 5 });
        T(`${d.acct ? d.acct.exName + (d.acct.openAt ? ` · с ${new Date(d.acct.openAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}` : '') + ' · ' : ''}${isLong ? 'ЛОНГ' : 'ШОРТ'}${d.acct && d.acct.lev ? ' x' + d.acct.lev : ''}   ${ens ? (inTrade && nF < nT ? 'нулевая' : 'ср. вход') : 'вход'} ${fmt(inTrade && nF < nT ? zp : e)}${tpl ? `   ср. выход ${fmt(exitP)}` : ''}   R/R ${rr.toFixed(2)}${liveTxt}`, mx, yE, { c: '#fff', bg: 'rgba(22,27,38,0.92)', align: 'center', base: 'middle', font: lf, pad: 5 });
        // 4-я ручка — стрелки ↔ на правом краю: только ширина (длительность), цены не меняются
        g.handles = [A, { x: P[1].x, y: P[1].y }, { x: P[1].x, y: P[2].y }, { x: x1, y: yE, kind: 'w', side: 'r', pos: true }];
        if (d.acct && !d.acct.open) g.handles.pop();
        if (!d.acct) g.handles.push({ x: x0, y: yE, kind: 'w', side: 'l', pos: true }); // начало сделки с биржи задаёт сама биржа
        break;
      }
    }
    return g;
  }

  function paint(ctx, ch, d, g, hl) {
    for (const f of g.fills) { ctx.fillStyle = f.c; ctx.fill(f.p); }
    for (const s of g.strokes) {
      ctx.strokeStyle = s.c; ctx.lineWidth = s.w + (hl ? 0.6 : 0);
      ctx.lineCap = s.round ? 'round' : 'butt'; ctx.lineJoin = 'round';
      ctx.setLineDash(s.dash || []); ctx.stroke(s.p);
    }
    ctx.setLineDash([]); ctx.lineCap = 'butt';
    for (const t of g.texts) {
      ctx.font = t.font || `11px ${FF}`;
      const fs = +(ctx.font.match(/(\d+(?:\.\d+)?)px/) || [0, 11])[1], lh = Math.round(fs * 1.3);
      const lines = String(t.t).split('\n');
      const tw = Math.max(...lines.map(l => ctx.measureText(l).width)), th = lh * lines.length;
      let x = t.x; if (t.align === 'center') x -= tw / 2; else if (t.align === 'right') x -= tw;
      let y = t.y; if (t.base === 'bottom') y -= th; else if (t.base === 'middle') y -= th / 2;
      const pad = t.bg ? (t.pad ?? 5) : 0;
      if (t.bg && ch.plotW) x = Math.max(4, Math.min(x, ch.plotW - tw - 8));
      x = Math.round(x); y = Math.round(y);
      t.box = { x: x - pad, y: y - pad, w: Math.round(tw + pad * 2), h: Math.round(th + pad * 2) };
      if (t.bg) { ctx.fillStyle = t.bg; ctx.beginPath(); ctx.roundRect(t.box.x, t.box.y, t.box.w, t.box.h, 4); ctx.fill(); }
      ctx.fillStyle = t.c; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      lines.forEach((l, k) => ctx.fillText(l, x, y + k * lh + lh / 2));
    }
  }

  const hctx = document.createElement('canvas').getContext('2d');
  function hit(g, x, y) {
    for (const s of g.strokes) { hctx.lineWidth = Math.max(10, s.w + 6); if (hctx.isPointInStroke(s.p, x, y)) return true; }
    for (const f of g.fills) if (f.hit !== false && hctx.isPointInPath(f.p, x, y)) return true;
    for (const t of g.texts) { const b = t.box; if (b && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) return true; }
    return false;
  }

  function init1(ch, d) {
    const t0 = d.pts[0].t, e = d.pts[0].p;
    if (d.type === 'long' || d.type === 'short') {
      const t1 = ch.idxToTime(ch.timeToIdx(t0) + Math.max(10, Math.round(120 / ch.spacing)));
      const h = (ch.pMax - ch.pMin) * 0.06, lg = d.type === 'long';
      d.pts = [{ t: t0, p: e }, { t: t1, p: lg ? e + h * 2 : e - h * 2 }, { t: t1, p: lg ? e - h : e + h }];
    }
    if (d.type === 'text') d.text = 'Текст';
  }

  return { TOOLS, GROUPS, FILLABLE, defaultStyle, build, paint, hit, init1, LIVE };
})();
