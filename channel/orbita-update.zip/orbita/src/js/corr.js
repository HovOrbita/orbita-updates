'use strict';
// Корреляция с биткоином: насколько монета сейчас ходит вслед за BTC.
// Считаем по изменениям цены (лог-доходностям) последних 100 закрытых свечей, свечи сопоставляем по времени.
// 1 — точно как биткоин, 0 — живёт своей жизнью, −1 — ходит наоборот.
const Corr = (() => {
  const N = 100, BTC = 'BTCUSDT';
  const btcCache = new Map();   // интервал → { t, bars }
  const watchCache = new Map(); // символ → { t, v } (по часовым свечам)
  let busy = false;

  function isBtc(id) { try { const l = Data.label(id); return l.base.toUpperCase() === 'BTC'; } catch { return id === BTC; } }

  // коэффициент Пирсона по доходностям, свечи совпадают по времени открытия
  function compute(a, b) {
    if (!a || !b || a.length < 20 || b.length < 20) return null;
    const bm = new Map(); for (const x of b) bm.set(x.t, x.c);
    const ra = [], rb = [];
    for (let i = 1; i < a.length; i++) {
      const b0 = bm.get(a[i - 1].t), b1 = bm.get(a[i].t);
      if (b0 == null || b1 == null || !(a[i - 1].c > 0) || !(a[i].c > 0) || !(b0 > 0) || !(b1 > 0)) continue;
      ra.push(Math.log(a[i].c / a[i - 1].c)); rb.push(Math.log(b1 / b0));
    }
    const n = Math.min(ra.length, N); if (n < 20) return null;
    const xa = ra.slice(-n), xb = rb.slice(-n);
    let sa = 0, sb = 0; for (let i = 0; i < n; i++) { sa += xa[i]; sb += xb[i]; }
    const ma = sa / n, mb = sb / n;
    let cov = 0, va = 0, vb = 0;
    for (let i = 0; i < n; i++) { const da = xa[i] - ma, db = xb[i] - mb; cov += da * db; va += da * da; vb += db * db; }
    if (!(va > 0) || !(vb > 0)) return null;
    return U.clamp(cov / Math.sqrt(va * vb), -1, 1);
  }

  async function btcBars(iv, maxAge) {
    const c = btcCache.get(iv);
    if (c && Date.now() - c.t < maxAge) return c.bars;
    const bars = await Data.klinesLive(BTC, iv, N + 40);
    if (!bars || !bars.length) throw new Error('нет данных BTC');
    btcCache.set(iv, { t: Date.now(), bars: bars.slice(0, -1) }); // без текущей незакрытой свечи
    return btcCache.get(iv).bars;
  }

  // для подписи графика: по таймфрейму самого графика
  async function forChart(ch) {
    if (!ch || !ch.bars || ch.bars.length < 30 || isBtc(ch.sym)) return null;
    const b = await btcBars(ch.iv, 5 * 60 * 1000);
    return compute(ch.bars.slice(0, -1).slice(-(N + 10)), b);
  }

  // для списка наблюдения: по часовым свечам, обновление раз в 15 минут
  async function refreshWatch(force) {
    if (busy) return; busy = true;
    try {
      const list = (App.state.watchlist || []).filter(s => !isBtc(s));
      let b;
      try { b = await btcBars('1h', 15 * 60 * 1000); } catch { return; }
      for (const s of list) {
        const c = watchCache.get(s);
        if (!force && c && Date.now() - c.t < 15 * 60 * 1000) { Panels.updateCorr && Panels.updateCorr(s, c.v); continue; }
        try {
          const bars = await Data.klinesLive(s, '1h', N + 40);
          const v = bars ? compute(bars.slice(0, -1), b) : null;
          watchCache.set(s, { t: Date.now(), v });
          Panels.updateCorr && Panels.updateCorr(s, v);
        } catch { watchCache.set(s, { t: Date.now(), v: null }); }
        await new Promise(r => setTimeout(r, 250)); // не нагружаем биржу
      }
    } finally { busy = false; }
  }
  function cached(s) { if (isBtc(s)) return 'btc'; const c = watchCache.get(s); return c ? c.v : undefined; }

  // как показывать: цифра и цвет
  function fmt(v) { return v == null ? '—' : (v >= 0 ? '' : '−') + Math.abs(v).toFixed(2).replace(/^0/, ''); }
  function cls(v) { return v == null ? '' : v >= 0.7 ? 'cr-hi' : v >= 0.35 ? 'cr-mid' : 'cr-lo'; }
  function words(v) {
    if (v == null) return 'мало данных';
    if (v >= 0.85) return 'ходит почти как биткоин';
    if (v >= 0.7) return 'сильно зависит от биткоина';
    if (v >= 0.35) return 'частично следует за биткоином';
    if (v > -0.2) return 'живёт своей жизнью';
    return 'ходит против биткоина';
  }
  return { compute, forChart, refreshWatch, cached, fmt, cls, words, isBtc };
})();
