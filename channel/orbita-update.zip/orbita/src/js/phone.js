'use strict';
// Окно «Телефон»: включить доступ, показать QR-код, видеть подключённые телефоны, отключить все.
const Phone = (() => {
  const api = () => window.orbita && window.orbita.phoneStatus && !window.orbita.phone ? window.orbita : null;
  let pickIp = '', timer = null;

  function drawQR(cv, rows) {
    const n = rows.length, q = 4, px = Math.floor(232 / (n + q * 2)), size = px * (n + q * 2);
    cv.width = cv.height = size; cv.style.width = cv.style.height = size + 'px';
    const g = cv.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, size, size); g.fillStyle = '#000';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (rows[r][c] === '1') g.fillRect((c + q) * px, (r + q) * px, px, px);
  }
  const ago = t => { const s = Math.round((Date.now() - t) / 1000); return s < 5 ? 'сейчас' : s < 60 ? `${s} с назад` : `${Math.round(s / 60)} мин назад`; };
  const dev = ua => /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Android/.test(ua) ? 'Android' : 'устройство';

  function render(m, st) {
    const on = st.on;
    m.body.innerHTML = `<div class="form ph">
      <label class="ph-sw"><input type="checkbox" id="phOn" ${on ? 'checked' : ''}> <b>Открывать Orbita на телефоне</b></label>
      ${st.error ? `<div class="ph-err">${U.esc(st.error)}</div>` : ''}
      ${on && st.url ? `
        <div class="ph-qr"><canvas id="phQR"></canvas>
          <ol class="ph-steps">
            ${st.remote ? '<li>На iPhone включите <b>Tailscale</b>.</li>' : '<li>Телефон — в <b>той же Wi-Fi сети</b>, что и компьютер.</li>'}
            <li>Откройте <b>камеру</b> iPhone и наведите на QR-код → нажмите на появившуюся ссылку.</li>
            <li>В Safari: <b>«Поделиться»</b> → <b>«На экран „Домой“»</b>. Появится значок Orbita.</li>
          </ol></div>
        ${st.ips.length > 1 ? `<label class="ph-ip">Сеть: <select id="phIp">${st.ips.map(x => `<option value="${U.esc(x.ip)}" ${x.ip === st.ip ? 'selected' : ''}>${x.ts ? '🌍 ' : '🏠 '}${U.esc(x.ip)} — ${U.esc(x.ts ? x.name : x.name + ' (только дома)')}</option>`).join('')}</select></label>` : ''}
        <div class="muted sm ph-url">${U.esc(st.url.split('#')[0])}</div>
        ${st.remote ? '<div class="ph-ok">🌍 Работает везде — дома и через мобильный интернет (Tailscale). На iPhone Tailscale должен быть включён.</div>'
          : `<details class="ph-ts"${st.hasTs ? '' : ''}><summary>🌍 Хотите открывать Orbita вне дома, через мобильный интернет?</summary>
            <ol class="ph-steps">
              <li>Установите бесплатное приложение <b>Tailscale</b> на этот компьютер (tailscale.com → Download) и на iPhone (App Store).</li>
              <li>Войдите в обоих <b>одним и тем же аккаунтом</b> (например, Google или Apple).</li>
              <li>На iPhone включите Tailscale (переключатель «Connected»).</li>
              <li>Закройте и снова откройте это окно — появится сеть «Tailscale — везде» и новый QR-код. Отсканируйте его.</li>
            </ol>
            <div class="muted sm">Tailscale соединяет ваш телефон с вашим компьютером напрямую и шифрует связь. Посторонние не увидят Orbita.</div></details>`}
        <div class="ph-cl">${st.clients.length ? st.clients.map(c => `<div>✓ Подключён ${dev(c.ua)} · ${ago(c.seen)}</div>`).join('') : '<span class="muted">Телефон ещё не подключался</span>'}</div>
        <div class="muted sm">Если Windows спросит разрешение для Orbita — нажмите <b>«Разрешить»</b> (частные сети). Компьютер должен быть включён, Orbita — открыта. Ключи бирж остаются на компьютере.</div>`
      : on ? '<div class="ph-err">Не найдена Wi-Fi сеть. Подключите компьютер к роутеру.</div>'
      : '<div class="muted">Включите, и появится QR-код. Телефон увидит те же графики, рисунки, списки и позиции, что и компьютер. Работает дома, в одной Wi-Fi сети.</div>'}
    </div>
    <div class="modal-actions">${on ? '<button class="btn ghost" data-a="reset" title="Новый QR-код: все подключённые телефоны отключатся">Отключить все телефоны</button>' : ''}<button class="btn primary" data-a="close">Готово</button></div>`;
    if (on && st.qr) drawQR(m.body.querySelector('#phQR'), st.qr);
    const sw = m.body.querySelector('#phOn');
    sw.onchange = async () => { sw.disabled = true; render(m, await api().phoneEnable(sw.checked, pickIp)); };
    const ip = m.body.querySelector('#phIp'); if (ip) ip.onchange = async () => { pickIp = ip.value; render(m, await api().phoneStatus(pickIp)); };
    m.body.querySelector('[data-a="close"]').onclick = () => m.close();
    const rs = m.body.querySelector('[data-a="reset"]');
    if (rs) rs.onclick = async () => { render(m, await api().phoneReset(pickIp)); U.toast('Новый QR-код. Старые подключения больше не работают.', 'info', 4000); };
  }

  async function open() {
    const o = api();
    const m = U.modal({ title: 'Orbita на телефоне', width: 470 });
    if (!o) { m.body.innerHTML = '<div class="form"><div class="muted">Подключение телефона включается в программе на компьютере.</div></div>'; return; }
    render(m, await o.phoneStatus(pickIp));
    clearInterval(timer);
    timer = setInterval(async () => { if (m.closed) { clearInterval(timer); return; } const st = await o.phoneStatus(pickIp); const cl = m.body.querySelector('.ph-cl'); if (cl && st.on) cl.innerHTML = st.clients.length ? st.clients.map(c => `<div>✓ Подключён ${dev(c.ua)} · ${ago(c.seen)}</div>`).join('') : '<span class="muted">Телефон ещё не подключался</span>'; }, 3000);
  }
  function init() {
    const b = document.getElementById('phoneBtn');
    if (!b) return;
    if (!api()) { b.remove(); return; }
    b.onclick = () => open();
  }
  return { init, open };
})();
