'use strict';
// Окно «Телефон»: включить доступ, показать QR-код, видеть подключённые телефоны, отключить все.
const Phone = (() => {
  const api = () => window.orbita && window.orbita.phoneStatus && !window.orbita.phone ? window.orbita : null;
  let pickIp = '', timer = null, os = 'iphone', sync = null;

  function drawQR(cv, rows) {
    const n = rows.length, q = 4, px = Math.floor(232 / (n + q * 2)), size = px * (n + q * 2);
    cv.width = cv.height = size; cv.style.width = cv.style.height = size + 'px';
    const g = cv.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, size, size); g.fillStyle = '#000';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (rows[r][c] === '1') g.fillRect((c + q) * px, (r + q) * px, px, px);
  }
  const ago = t => { const s = Math.round((Date.now() - t) / 1000); return s < 5 ? 'сейчас' : s < 60 ? `${s} с назад` : `${Math.round(s / 60)} мин назад`; };
  const dev = ua => /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Android/.test(ua) ? 'Android' : /Electron/.test(ua) ? 'ноутбук (программа Orbita)' : /Windows|Macintosh/.test(ua) ? 'компьютер' : 'устройство';
  const hm = t => t ? new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—';
  // ноутбук и другие компьютеры: общие рисунки, списки и настройки через облачную папку (основной ПК может быть выключен)
  function syncHTML() {
    if (!sync) return '';
    if (sync.on) return `<div class="ph-sync on">
        <div><b>💻 Ноутбук: синхронизация включена</b></div>
        <div class="muted sm">Папка: ${U.esc(sync.dir)}</div>
        <div class="muted sm">Отправлено в облако: ${hm(sync.lastPush)} · получено: ${hm(sync.lastPull)}</div>
        ${sync.others.length ? `<div class="sm">Сейчас Orbita открыта также на: <b>${sync.others.map(U.esc).join(', ')}</b></div>` : ''}
        ${sync.err ? `<div class="ph-err">${U.esc(sync.err)}</div>` : ''}
        <div class="muted sm">Этот компьютер можно выключать — на ноутбуке всё будет работать само. Ключи бирж в облако не попадают: на каждом компьютере биржи подключаются отдельно.</div>
        <button class="btn ghost" data-a="syncoff">Отключить синхронизацию</button></div>`;
    return `<div class="ph-sync">
        <div><b>💻 Работать на ноутбуке, даже когда этот компьютер выключен</b></div>
        <div class="muted sm">Рисунки, списки наблюдения, оповещения и настройки станут одинаковыми на всех ваших компьютерах — через вашу облачную папку (OneDrive или Google Диск). Каждый компьютер работает сам, цены берёт прямо с бирж.</div>
        <div class="ph-sbtn">${sync.suggestions.map((x, i) => `<button class="btn primary" data-sync="${i}">Подключить ${U.esc(x.name)}</button>`).join('')}<button class="btn" data-sync="pick">Выбрать папку…</button></div>
        <details class="ph-ts"><summary>Как настроить — по шагам</summary><ol class="ph-steps">
          <li>На <b>этом компьютере</b> нажмите <b>«Подключить OneDrive»</b>. Если OneDrive нет — <b>«Выбрать папку…»</b> и выберите папку Google Диска.</li>
          <li>На <b>ноутбуке</b> установите Orbita (папка Orbita → <b>INSTALL.bat</b>).</li>
          <li>На ноутбуке войдите в <b>OneDrive</b> (или Google Диск) <b>тем же аккаунтом</b>, что и на компьютере.</li>
          <li>На ноутбуке откройте Orbita → кнопка <b>📱</b> → <b>«Подключить OneDrive»</b>. Ваши рисунки и списки появятся через несколько секунд.</li>
          <li>Биржи на ноутбуке подключите заново: <b>«Мои позиции»</b> → ключи <b>только для чтения</b>. Ключи хранятся только на самом компьютере.</li>
        </ol></details></div>`;
  }
  function bindSync(m, st) {
    const go = async d => {
      const r = await api().syncConnect(d); sync = r;
      if (r.on) U.toast(r.joined ? 'Готово: рисунки и списки взяты из облака и объединены с этими.' : 'Готово: данные сохраняются в облако. Теперь подключите ноутбук.', 'up', 6000);
      else if (r.err) U.toast(r.err, 'error', 6000);
      render(m, st);
    };
    m.body.querySelectorAll('[data-sync]').forEach(b => b.onclick = () => go(b.dataset.sync === 'pick' ? null : sync.suggestions[+b.dataset.sync].dir));
    const off = m.body.querySelector('[data-a="syncoff"]');
    if (off) off.onclick = async () => { sync = await api().syncOff(); render(m, st); U.toast('Синхронизация отключена. Данные на этом компьютере остались.', 'info', 4000); };
  }
  function render(m, st) {
    const on = st.on;
    m.body.innerHTML = `<div class="form ph">
      <label class="ph-sw"><input type="checkbox" id="phOn" ${on ? 'checked' : ''}> <b>Открывать Orbita на телефоне</b></label>
      ${st.error ? `<div class="ph-err">${U.esc(st.error)}</div>` : ''}
      ${on && st.url ? `
        <div class="ph-qr"><canvas id="phQR"></canvas>
          <div class="ph-how">
            <div class="ph-os">${['iphone', 'android'].map(k => `<button data-os="${k}" class="${os === k ? 'on' : ''}">${k === 'iphone' ? 'iPhone' : 'Android'}</button>`).join('')}</div>
            <ol class="ph-steps">
              ${st.remote ? `<li>На телефоне включите <b>Tailscale</b>.</li>` : '<li>Телефон — в <b>той же Wi-Fi сети</b>, что и компьютер.</li>'}
              ${os === 'iphone'
                ? '<li>Откройте <b>камеру</b> и наведите на QR-код → нажмите на появившуюся ссылку.</li><li>В Safari: <b>«Поделиться»</b> → <b>«На экран „Домой“»</b>. Появится значок Orbita.</li>'
                : '<li>Откройте <b>камеру</b> (или <b>Google Объектив</b>) и наведите на QR-код → нажмите на ссылку. Откроется Chrome.</li><li>В Chrome: меню <b>⋮</b> вверху справа → <b>«Добавить на главный экран»</b> → <b>«Добавить»</b>. Появится значок Orbita.</li>'}
            </ol></div></div>
        ${st.ips.length > 1 ? `<label class="ph-ip">Сеть: <select id="phIp">${st.ips.map(x => `<option value="${U.esc(x.ip)}" ${x.ip === st.ip ? 'selected' : ''}>${x.dns ? '⚡ ' : x.ts ? '🌍 ' : '🏠 '}${U.esc(x.ip)} — ${U.esc(x.ts ? x.name : x.name + ' (только дома)')}</option>`).join('')}</select></label>` : ''}
        <div class="muted sm ph-url">${U.esc(st.url.split('#')[0])}</div>
        ${st.auto ? `<div class="ph-ok">🌍 Работает везде — дома и через мобильный интернет.</div>
            <details class="ph-ts"><summary>⚡ Чтобы Tailscale на iPhone включался сам, когда открываете Orbita</summary>
            <ol class="ph-steps">
              <li>В приложении Tailscale на iPhone нажмите на <b>свою аватарку</b> вверху справа.</li>
              <li><b>VPN On Demand</b> → включите.</li>
              <li>Для <b>Wi-Fi</b> и для <b>Сотовой связи</b> выберите <b>Do Nothing</b> («ничего не делать»).</li>
              <li>Готово: Tailscale можно выключать. Когда откроете Orbita, iPhone сам его включит.</li>
            </ol><div class="muted sm">Если Orbita не открылась при выключенном Tailscale — просто включите его вручную и сообщите, что так.</div></details>`
        : st.remote ? '<div class="ph-ok">🌍 Работает везде — дома и через мобильный интернет (Tailscale). На телефоне Tailscale должен быть включён.</div>'
          : `<details class="ph-ts"${st.hasTs ? '' : ''}><summary>🌍 Хотите открывать Orbita вне дома, через мобильный интернет?</summary>
            <ol class="ph-steps">
              <li>Установите бесплатное приложение <b>Tailscale</b> на этот компьютер (tailscale.com → Download) и на телефон (App Store на iPhone, Google Play на Android).</li>
              <li>Войдите в обоих <b>одним и тем же аккаунтом</b> (например, Google или Apple).</li>
              <li>На телефоне включите Tailscale (переключатель «Connected») и разрешите VPN.</li>
              <li>Закройте и снова откройте это окно — появится сеть «Tailscale — везде» и новый QR-код. Отсканируйте его.</li>
            </ol>
            <div class="muted sm">Tailscale соединяет ваш телефон с вашим компьютером напрямую и шифрует связь. Посторонние не увидят Orbita.</div></details>`}
        <div class="ph-cl">${st.clients.length ? st.clients.map(c => `<div>✓ Подключён ${dev(c.ua)} · ${ago(c.seen)}</div>`).join('') : '<span class="muted">Телефон ещё не подключался</span>'}</div>
        <div class="muted sm">Если Windows спросит разрешение для Orbita — нажмите <b>«Разрешить»</b> (частные сети). Компьютер должен быть включён, Orbita — открыта. Ключи бирж остаются на компьютере.</div>`
      : on ? '<div class="ph-err">Не найдена Wi-Fi сеть. Подключите компьютер к роутеру.</div>'
      : '<div class="muted">Включите, и появится QR-код. Телефон увидит те же графики, рисунки, списки и позиции, что и компьютер. Работает дома, в одной Wi-Fi сети.</div>'}
      ${syncHTML()}
    </div>
    <div class="modal-actions">${on ? '<button class="btn ghost" data-a="reset" title="Новый QR-код: все подключённые телефоны отключатся">Отключить все телефоны</button>' : ''}<button class="btn primary" data-a="close">Готово</button></div>`;
    if (on && st.qr) drawQR(m.body.querySelector('#phQR'), st.qr);
    m.body.querySelectorAll('[data-os]').forEach(b => b.onclick = () => { os = b.dataset.os; render(m, st); });
    const sw = m.body.querySelector('#phOn');
    sw.onchange = async () => { sw.disabled = true; render(m, await api().phoneEnable(sw.checked, pickIp)); };
    const ip = m.body.querySelector('#phIp'); if (ip) ip.onchange = async () => { pickIp = ip.value; render(m, await api().phoneStatus(pickIp)); };
    m.body.querySelector('[data-a="close"]').onclick = () => m.close();
    bindSync(m, st);
    const rs = m.body.querySelector('[data-a="reset"]');
    if (rs) rs.onclick = async () => { render(m, await api().phoneReset(pickIp)); U.toast('Новый QR-код. Старые подключения больше не работают.', 'info', 4000); };
  }

  async function open() {
    const o = api();
    const m = U.modal({ title: 'Orbita на телефоне и ноутбуке', width: 470 });
    if (!o && isLaptop()) {
      m.body.innerHTML = '<div class="form"><div>💻 Этот компьютер показывает ваш аккаунт с <b>основного компьютера</b>.</div><div class="muted sm">Основной компьютер должен быть включён, Orbita на нём — открыта.</div></div><div class="modal-actions"><button class="btn ghost" data-a="off">Отключить этот компьютер</button><button class="btn primary" data-a="close">Готово</button></div>';
      m.body.querySelector('[data-a="close"]').onclick = () => m.close();
      m.body.querySelector('[data-a="off"]').onclick = () => { location.href = 'orbita-remote://disconnect'; };
      return;
    }
    if (!o) { m.body.innerHTML = '<div class="form"><div class="muted">Подключение телефона включается в программе на компьютере.</div></div>'; return; }
    try { sync = o.syncStatus ? await o.syncStatus() : null; } catch { sync = null; }
    render(m, await o.phoneStatus(pickIp));
    clearInterval(timer);
    timer = setInterval(async () => { if (m.closed) { clearInterval(timer); return; } const st = await o.phoneStatus(pickIp); const cl = m.body.querySelector('.ph-cl'); if (cl && st.on) cl.innerHTML = st.clients.length ? st.clients.map(c => `<div>✓ Подключён ${dev(c.ua)} · ${ago(c.seen)}</div>`).join('') : '<span class="muted">Телефон ещё не подключался</span>'; }, 3000);
  }
  const isLaptop = () => !!window.ORBITA_REMOTE && !window.ORBITA_PHONE && /Electron/.test(navigator.userAgent); // ноутбук, подключённый программой Orbita
  function init() {
    const b = document.getElementById('phoneBtn');
    if (!b) return;
    if (!api() && !isLaptop()) { b.remove(); return; }
    b.onclick = () => open();
  }
  return { init, open };
})();
