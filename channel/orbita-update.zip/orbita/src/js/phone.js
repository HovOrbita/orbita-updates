'use strict';
// Окно «Телефон»: включить доступ, показать QR-код, видеть подключённые телефоны, отключить все.
const Phone = (() => {
  const api = () => window.orbita && window.orbita.phoneStatus && !window.orbita.phone ? window.orbita : null;
  let pickIp = '', timer = null, os = 'iphone';

  function drawQR(cv, rows) {
    const n = rows.length, q = 4, px = Math.floor(232 / (n + q * 2)), size = px * (n + q * 2);
    cv.width = cv.height = size; cv.style.width = cv.style.height = size + 'px';
    const g = cv.getContext('2d');
    g.fillStyle = '#fff'; g.fillRect(0, 0, size, size); g.fillStyle = '#000';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (rows[r][c] === '1') g.fillRect((c + q) * px, (r + q) * px, px, px);
  }
  const ago = t => { const s = Math.round((Date.now() - t) / 1000); return s < 5 ? 'сейчас' : s < 60 ? `${s} с назад` : `${Math.round(s / 60)} мин назад`; };
  const dev = ua => /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Android/.test(ua) ? 'Android' : /Electron/.test(ua) ? 'ноутбук (программа Orbita)' : /Windows|Macintosh/.test(ua) ? 'компьютер' : 'устройство';
  function laptopUrl(st) { // ссылка для второго компьютера: лучше через Tailscale (работает и вне дома)
    const k = (st.url.split('#k=')[1] || ''), x = st.ips.find(i => i.dns) || st.ips.find(i => i.ts) || { ip: st.ip };
    return `http://${x.ip}:${st.port}/app/?w=laptop#k=${k}`;
  }
  function copy(t) {
    try { navigator.clipboard.writeText(t); return; } catch { /* */ }
    const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove();
  }

  function render(m, st) {
    const on = st.on;
    m.body.innerHTML = `<div class="form ph">
      <label class="ph-sw"><input type="checkbox" id="phOn" ${on ? 'checked' : ''}> <b>Открывать Orbita на телефоне</b></label>
      ${st.error ? `<div class="ph-err">${U.esc(st.error)}</div>` : ''}
      ${on && st.url ? `
        <div class="ph-qr"><canvas id="phQR"></canvas>
          <div class="ph-how">
            <div class="ph-os">${['iphone', 'android'].map(k => `<button data-os="${k}" class="${os === k ? 'on' : ''}">${k === 'iphone' ? 'iPhone' : 'Android'}</button>`).join('')}</div>
            <ol class="ph-steps">
              ${st.remote ? `<li>На телефоне включите <b>Tailscale</b>.</li>` : '<li>Телефон — в <b>той же Wi-Fi сети</b>, что и компьютер.</li>'}
              ${os === 'iphone'
                ? '<li>Откройте <b>камеру</b> и наведите на QR-код → нажмите на появившуюся ссылку.</li><li>В Safari: <b>«Поделиться»</b> → <b>«На экран „Домой“»</b>. Появится значок Orbita.</li>'
                : '<li>Откройте <b>камеру</b> (или <b>Google Объектив</b>) и наведите на QR-код → нажмите на ссылку. Откроется Chrome.</li><li>В Chrome: меню <b>⋮</b> вверху справа → <b>«Добавить на главный экран»</b> → <b>«Добавить»</b>. Появится значок Orbita.</li>'}
            </ol></div></div>
        ${st.ips.length > 1 ? `<label class="ph-ip">Сеть: <select id="phIp">${st.ips.map(x => `<option value="${U.esc(x.ip)}" ${x.ip === st.ip ? 'selected' : ''}>${x.dns ? '⚡ ' : x.ts ? '🌍 ' : '🏠 '}${U.esc(x.ip)} — ${U.esc(x.ts ? x.name : x.name + ' (только дома)')}</option>`).join('')}</select></label>` : ''}
        <div class="muted sm ph-url">${U.esc(st.url.split('#')[0])}</div>
        ${st.auto ? `<div class="ph-ok">🌍 Работает везде — дома и через мобильный интернет.</div>
            <details class="ph-ts"><summary>⚡ Чтобы Tailscale на iPhone включался сам, когда открываете Orbita</summary>
            <ol class="ph-steps">
              <li>В приложении Tailscale на iPhone нажмите на <b>свою аватарку</b> вверху справа.</li>
              <li><b>VPN On Demand</b> → включите.</li>
              <li>Для <b>Wi-Fi</b> и для <b>Сотовой связи</b> выберите <b>Do Nothing</b> («ничего не делать»).</li>
              <li>Готово: Tailscale можно выключать. Когда откроете Orbita, iPhone сам его включит.</li>
            </ol><div class="muted sm">Если Orbita не открылась при выключенном Tailscale — просто включите его вручную и сообщите, что так.</div></details>`
        : st.remote ? '<div class="ph-ok">🌍 Работает везде — дома и через мобильный интернет (Tailscale). На телефоне Tailscale должен быть включён.</div>'
          : `<details class="ph-ts"${st.hasTs ? '' : ''}><summary>🌍 Хотите открывать Orbita вне дома, через мобильный интернет?</summary>
            <ol class="ph-steps">
              <li>Установите бесплатное приложение <b>Tailscale</b> на этот компьютер (tailscale.com → Download) и на телефон (App Store на iPhone, Google Play на Android).</li>
              <li>Войдите в обоих <b>одним и тем же аккаунтом</b> (например, Google или Apple).</li>
              <li>На телефоне включите Tailscale (переключатель «Connected») и разрешите VPN.</li>
              <li>Закройте и снова откройте это окно — появится сеть «Tailscale — везде» и новый QR-код. Отсканируйте его.</li>
            </ol>
            <div class="muted sm">Tailscale соединяет ваш телефон с вашим компьютером напрямую и шифрует связь. Посторонние не увидят Orbita.</div></details>`}
        <div class="ph-cl">${st.clients.length ? st.clients.map(c => `<div>✓ Подключён ${dev(c.ua)} · ${ago(c.seen)}</div>`).join('') : '<span class="muted">Телефон ещё не подключался</span>'}</div>
        <details class="ph-ts ph-lap"><summary>💻 Открыть мой аккаунт на ноутбуке (программой Orbita)</summary>
          <ol class="ph-steps">
            <li>Установите Orbita на ноутбук так же, как здесь (папка Orbita → <b>INSTALL.bat</b>).</li>
            ${st.ips.some(i => i.ts) ? '<li>Если ноутбук будет не дома — установите на нём <b>Tailscale</b> и войдите тем же аккаунтом.</li>' : '<li>Ноутбук должен быть в той же Wi-Fi сети. Чтобы работало и вне дома — нужен Tailscale (см. выше).</li>'}
            <li>Нажмите здесь <b>«Скопировать ссылку для ноутбука»</b> и перешлите её себе (например, в Telegram «Избранное»).</li>
            <li>На ноутбуке в Orbita: кнопка <b>📱</b> → внизу <b>«Это второй компьютер?»</b> → вставьте ссылку → <b>«Подключиться»</b>.</li>
          </ol>
          <button class="btn" data-a="lapcopy">📋 Скопировать ссылку для ноутбука</button>
          <div class="muted sm">Ссылка — как ключ от вашего аккаунта. Не отправляйте её другим людям. Если она попала к чужому — «Отключить все телефоны».</div></details>
        <div class="muted sm">Если Windows спросит разрешение для Orbita — нажмите <b>«Разрешить»</b> (частные сети). Компьютер должен быть включён, Orbita — открыта. Ключи бирж остаются на компьютере.</div>`
      : on ? '<div class="ph-err">Не найдена Wi-Fi сеть. Подключите компьютер к роутеру.</div>'
      : '<div class="muted">Включите, и появится QR-код. Телефон увидит те же графики, рисунки, списки и позиции, что и компьютер. Работает дома, в одной Wi-Fi сети.</div>'}
      <details class="ph-ts ph-join"><summary>💻 Это второй компьютер? Подключить к основной Orbita</summary>
        <div class="muted sm">Вставьте ссылку, скопированную на основном компьютере. Эта Orbita будет показывать ваш аккаунт оттуда: те же графики, рисунки, списки и позиции.</div>
        <input id="phJoin" class="inp" placeholder="http://…/app/?w=laptop#k=…" spellcheck="false" style="width:100%;margin:6px 0">
        <button class="btn primary" data-a="join">Подключиться</button>
        <div class="muted sm">Отключиться потом: <b>Ctrl+Shift+L</b>.</div></details>
    </div>
    <div class="modal-actions">${on ? '<button class="btn ghost" data-a="reset" title="Новый QR-код: все подключённые телефоны отключатся">Отключить все телефоны</button>' : ''}<button class="btn primary" data-a="close">Готово</button></div>`;
    if (on && st.qr) drawQR(m.body.querySelector('#phQR'), st.qr);
    m.body.querySelectorAll('[data-os]').forEach(b => b.onclick = () => { os = b.dataset.os; render(m, st); });
    const sw = m.body.querySelector('#phOn');
    sw.onchange = async () => { sw.disabled = true; render(m, await api().phoneEnable(sw.checked, pickIp)); };
    const ip = m.body.querySelector('#phIp'); if (ip) ip.onchange = async () => { pickIp = ip.value; render(m, await api().phoneStatus(pickIp)); };
    m.body.querySelector('[data-a="close"]').onclick = () => m.close();
    const lc = m.body.querySelector('[data-a="lapcopy"]');
    if (lc) lc.onclick = () => { copy(laptopUrl(st)); U.toast('Ссылка скопирована. Отправьте её себе и вставьте в Orbita на ноутбуке.', 'up', 5000); };
    const jb = m.body.querySelector('[data-a="join"]');
    if (jb) jb.onclick = async () => {
      if (!api().remoteConnect) { U.toast('Обновите Orbita на этом компьютере', 'error'); return; }
      const r = await api().remoteConnect(m.body.querySelector('#phJoin').value);
      if (r && r.ok) U.toast('Подключаемся… Orbita перезапустится.', 'up', 4000); else U.toast((r && r.error) || 'Не получилось', 'error', 7000);
    };
    const rs = m.body.querySelector('[data-a="reset"]');
    if (rs) rs.onclick = async () => { render(m, await api().phoneReset(pickIp)); U.toast('Новый QR-код. Старые подключения больше не работают.', 'info', 4000); };
  }

  async function open() {
    const o = api();
    const m = U.modal({ title: 'Orbita на телефоне и ноутбуке', width: 470 });
    if (!o && isLaptop()) {
      m.body.innerHTML = '<div class="form"><div>💻 Этот компьютер показывает ваш аккаунт с <b>основного компьютера</b>.</div><div class="muted sm">Основной компьютер должен быть включён, Orbita на нём — открыта.</div></div><div class="modal-actions"><button class="btn ghost" data-a="off">Отключить этот компьютер</button><button class="btn primary" data-a="close">Готово</button></div>';
      m.body.querySelector('[data-a="close"]').onclick = () => m.close();
      m.body.querySelector('[data-a="off"]').onclick = () => { location.href = 'orbita-remote://disconnect'; };
      return;
    }
    if (!o) { m.body.innerHTML = '<div class="form"><div class="muted">Подключение телефона включается в программе на компьютере.</div></div>'; return; }
    render(m, await o.phoneStatus(pickIp));
    clearInterval(timer);
    timer = setInterval(async () => { if (m.closed) { clearInterval(timer); return; } const st = await o.phoneStatus(pickIp); const cl = m.body.querySelector('.ph-cl'); if (cl && st.on) cl.innerHTML = st.clients.length ? st.clients.map(c => `<div>✓ Подключён ${dev(c.ua)} · ${ago(c.seen)}</div>`).join('') : '<span class="muted">Телефон ещё не подключался</span>'; }, 3000);
  }
  const isLaptop = () => !!window.ORBITA_REMOTE && !window.ORBITA_PHONE && /Electron/.test(navigator.userAgent); // ноутбук, подключённый программой Orbita
  function init() {
    const b = document.getElementById('phoneBtn');
    if (!b) return;
    if (!api() && !isLaptop()) { b.remove(); return; }
    b.onclick = () => open();
  }
  return { init, open };
})();
