'use strict';
// Кнопка «Обновить»: проверка новой версии, скачивание, установка и перезапуск
const Upd = (() => {
  let last = null, notified = false;
  const api = () => window.orbita && window.orbita.updCheck ? window.orbita : null;
  const fmtBuild = b => { const s = String(b || ''); return s.length === 12 ? `${s.slice(6, 8)}.${s.slice(4, 6)}.${s.slice(0, 4)} ${s.slice(8, 10)}:${s.slice(10, 12)}` : '—'; };

  function mark(r) {
    const btn = document.getElementById('updBtn'); if (!btn) return;
    const has = !!(r && r.ok && r.available);
    btn.querySelector('.upd-dot').hidden = !has;
    btn.classList.toggle('has', has);
    btn.title = has ? `Доступно обновление от ${fmtBuild(r.build)} — нажмите, чтобы установить` : 'Обновить программу';
  }

  async function check(quiet) {
    const o = api(); if (!o) return null;
    try { last = await o.updCheck(); } catch { last = null; }
    mark(last);
    if (quiet && last && last.ok && last.available && !notified) {
      notified = true;
      U.toast('Вышло обновление Orbita — нажмите кнопку со стрелкой вверху справа', 'info', 6000);
    }
    return last;
  }

  async function open() {
    const o = api();
    const m = U.modal({ title: 'Обновление программы', width: 440 });
    if (!o) { m.body.innerHTML = '<div class="form"><div class="muted">Обновление доступно в программе для Windows.</div></div>'; return; }
    m.body.innerHTML = '<div class="form upd"><div class="upd-st">Проверяю, есть ли новая версия…</div></div>';
    const r = await check(false);
    if (m.closed) return;
    const cur = `<div class="muted sm">У вас версия от ${fmtBuild(r && r.cur)}</div>`;
    if (!r || !r.ok) {
      m.body.innerHTML = `<div class="form upd">${cur}<div class="upd-st dn">${U.esc(r ? r.error : 'Не удалось проверить')}</div>
        ${r && r.notConfigured ? '<div class="muted sm">Попросите автора программы прислать обновление с настроенным источником.</div>' : '<div class="muted sm">Проверьте интернет и попробуйте ещё раз.</div>'}</div>
        <div class="modal-actions"><button class="btn ghost" data-a="close">Закрыть</button>${r && r.notConfigured ? '' : '<button class="btn primary" data-a="again">Проверить ещё раз</button>'}</div>`;
    } else if (!r.available) {
      m.body.innerHTML = `<div class="form upd">${cur}<div class="upd-st up">✓ У вас последняя версия</div></div>
        <div class="modal-actions"><button class="btn primary" data-a="close">Готово</button></div>`;
    } else {
      const size = r.size ? ` · ${(r.size / 1048576).toFixed(1)} МБ` : '';
      m.body.innerHTML = `<div class="form upd">${cur}
        <div class="upd-st"><b>Доступна новая версия от ${fmtBuild(r.build)}</b><span class="muted sm">${size}</span></div>
        ${r.notes.length ? `<ul class="upd-notes">${r.notes.map(n => `<li>${U.esc(n)}</li>`).join('')}</ul>` : ''}
        <div class="muted sm">Ваши графики, рисунки, списки и подключённые биржи сохранятся. Программа сама перезапустится.</div>
        <div class="upd-bar" hidden><i></i></div></div>
        <div class="modal-actions"><button class="btn ghost" data-a="close">Позже</button><button class="btn primary" data-a="go">Обновить</button></div>`;
    }
    m.body.onclick = async e => {
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'close') { m.close(); return; }
      if (a.dataset.a === 'again') { m.close(); open(); return; }
      if (a.dataset.a !== 'go') return;
      App.save && App.save(); // всё сохраняем перед перезапуском
      m.body.querySelectorAll('[data-a]').forEach(b => b.disabled = true);
      const bar = m.body.querySelector('.upd-bar'), st = m.body.querySelector('.upd-st');
      bar.hidden = false; st.innerHTML = 'Скачиваю…';
      const r2 = await o.updInstall();
      if (r2.ok) { st.className = 'upd-st up'; st.innerHTML = '✓ Обновлено. Перезапускаю программу…'; bar.querySelector('i').style.width = '100%'; }
      else {
        st.className = 'upd-st dn'; st.textContent = r2.error; bar.hidden = true;
        m.body.querySelectorAll('[data-a]').forEach(b => b.disabled = false);
        const go = m.body.querySelector('[data-a="go"]'); if (go) go.textContent = 'Попробовать ещё раз';
      }
    };
    const o2 = api();
    if (o2 && o2.onUpdProgress && !open._sub) {
      open._sub = true;
      o2.onUpdProgress(d => {
        const box = document.querySelector('.modal .upd'); if (!box) return;
        const bar = box.querySelector('.upd-bar i'), st = box.querySelector('.upd-st');
        if (bar) bar.style.width = (d.pct || 0) + '%';
        if (st) st.textContent = { download: `Скачиваю… ${d.pct || 0}%`, verify: 'Проверяю подпись…', install: 'Устанавливаю…', restart: '✓ Обновлено. Перезапускаю программу…' }[d.stage] || st.textContent;
      });
    }
  }

  function init() {
    const btn = document.getElementById('updBtn');
    if (btn) btn.onclick = () => open();
    if (!App.isMain) return;
    setTimeout(() => check(true), 20000);          // тихая проверка после запуска
    setInterval(() => check(true), 6 * 3600e3);    // и раз в 6 часов
  }
  return { init, open, check };
})();
