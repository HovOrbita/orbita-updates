'use strict';
// ---------- Оповещения ----------
const Alerts = {
  get list() { return App.state.alerts; },
  get log() { return App.state.alertLog; },
  condName(c) { return { cross: 'пересекает', up: 'пересекает вверх', down: 'пересекает вниз' }[c] || c; },
  add(a) {
    const al = { id: U.uid(), sym: a.sym, cond: a.cond || 'cross', price: +a.price, msg: a.msg || '', repeat: !!a.repeat, active: true, created: Date.now() };
    this.list.push(al);
    App.saveSoon(); App.restartTicker(); Panels.renderAlerts(); App.invalidateSym(al.sym);
    U.toast(`Оповещение: ${al.sym} ${this.condName(al.cond)} ${U.fmt(al.price, al.price)}`, 'info', 3000);
    return al;
  },
  quickAdd(sym, price) { return this.add({ sym, price, cond: 'cross' }); },
  remove(id) {
    const i = this.list.findIndex(a => a.id === id); if (i < 0) return;
    const [a] = this.list.splice(i, 1);
    App.saveSoon(); App.restartTicker(); Panels.renderAlerts(); App.invalidateSym(a.sym);
  },
  toggle(id) {
    const a = this.list.find(x => x.id === id); if (!a) return;
    a.active = !a.active;
    App.saveSoon(); App.restartTicker(); Panels.renderAlerts(); App.invalidateSym(a.sym);
  },
  check(sym, prev, p) {
    for (const a of this.list) {
      if (!a.active || a.sym !== sym) continue;
      const up = prev < a.price && p >= a.price, dn = prev > a.price && p <= a.price;
      const hit = a.cond === 'up' ? up : a.cond === 'down' ? dn : (up || dn);
      if (hit) this.fire(a, p, up);
    }
  },
  fire(a, p, up) {
    if (!a.repeat) a.active = false;
    a.fired = Date.now();
    const text = `${a.sym} ${up ? 'пересёк вверх' : 'пересёк вниз'} ${U.fmt(a.price, a.price)} (цена ${U.fmt(p, p)})${a.msg ? ' — ' + a.msg : ''}`;
    this.log.unshift({ time: Date.now(), sym: a.sym, text });
    if (this.log.length > 100) this.log.length = 100;
    App.saveSoon(); Panels.renderAlerts(); App.invalidateSym(a.sym);
    U.toast(text, 'alert', 12000);
    if (App.state.settings.sound !== false) U.beep();
    try { new Notification('Orbita · Оповещение', { body: text }); } catch { /* */ }
  },
  lines(sym) {
    return this.list.filter(a => a.active && a.sym === sym).map(a => ({
      id: a.id, price: a.price, color: '#e8a33d', dash: [6, 4], label: 'Оповещение',
      drag: p => { a.price = p; App.invalidateSym(sym); },
      commit: () => { App.saveSoon(); Panels.renderAlerts(); },
      onCancel: () => this.remove(a.id),
    }));
  },
  openDialog(opts = {}) {
    const ch = App.active();
    const sym = opts.sym || ch.sym, price = opts.price ?? App.prices[sym] ?? ch.ref;
    const m = U.modal({ title: 'Создать оповещение', width: 400 });
    m.body.innerHTML = `
      <div class="form">
        <label>Символ<input class="inp" id="alSym" value="${U.esc(sym)}"></label>
        <label>Условие<select class="inp" id="alCond"><option value="cross">Пересечение</option><option value="up">Пересечение вверх</option><option value="down">Пересечение вниз</option></select></label>
        <label>Цена<input class="inp" id="alPrice" type="number" step="any" value="${U.fmt(price, price)}"></label>
        <label>Сообщение<input class="inp" id="alMsg" placeholder="необязательно"></label>
        <label class="chk"><input type="checkbox" id="alRep"> Срабатывать каждый раз (не отключать)</label>
      </div>
      <div class="modal-actions"><button class="btn ghost">Отмена</button><button class="btn primary">Создать</button></div>`;
    m.body.querySelector('.ghost').onclick = () => m.close();
    m.body.querySelector('.primary').onclick = () => {
      const s = $('#alSym', m.body).value.trim().toUpperCase(), pr = parseFloat($('#alPrice', m.body).value);
      if (!s || !(pr > 0)) { U.toast('Укажите символ и цену', 'dn'); return; }
      this.add({ sym: s, cond: $('#alCond', m.body).value, price: pr, msg: $('#alMsg', m.body).value, repeat: $('#alRep', m.body).checked });
      m.close();
    };
    setTimeout(() => $('#alPrice', m.body).focus(), 0);
  },
};

// ---------- Правая панель: список, оповещения, объекты ----------
// короткие метки бирж для узкого списка
const EX_SHORT = { BINANCE: 'BN', BINANCEF: 'BN', BYBIT: 'BY', BYBITF: 'BY', OKX: 'OKX', GATE: 'GT', GATEF: 'GT', MEXC: 'MX' };
// цена для узкого списка: у очень дешёвых монет нули сворачиваются — 0.000007120 → 0.0₅712
const SUB = '₀₁₂₃₄₅₆₇₈₉';
function wlPrice(c) {
  if (!(c > 0) || c >= 0.001) return U.fmt(c, c);
  const m = /^0\.(0+)(\d+)$/.exec(c.toFixed(12)); if (!m) return U.fmt(c, c);
  const z = m[1].length, digits = m[2].replace(/0+$/, '').slice(0, 4) || '0';
  return '0.0' + String(z).split('').map(d => SUB[+d]).join('') + digits;
}
// цветной кружок монеты: у известных — узнаваемый цвет, у остальных — постоянный цвет по названию
const COIN_COL = { BTC: '#f7931a', ETH: '#627eea', BNB: '#f3ba2f', SOL: '#9945ff', XRP: '#23292f', DOGE: '#c2a633', ADA: '#0033ad', TON: '#0098ea', TRX: '#eb0029', LTC: '#345d9d', DOT: '#e6007a', AVAX: '#e84142', LINK: '#2a5ada', SUI: '#4da2ff', SHIB: '#ffa409', PEPE: '#3d9a3a', UNI: '#ff007a', NEAR: '#00c08b', APT: '#2ed8a3', ARB: '#28a0f0', OP: '#ff0420', HYPE: '#50d2c1', XLM: '#14b6e7', BCH: '#8dc351', ATOM: '#2e3148', FIL: '#0090ff', INJ: '#00a3ff', TIA: '#7b2bf9', WLD: '#1c1c1c', ENA: '#2b2b2b', AAVE: '#b6509e', XMR: '#ff6600', ZEC: '#f4b728', ETC: '#328332', ICP: '#29abe2', HBAR: '#222222', KAS: '#49eacb', RENDER: '#e3242b', FET: '#1d2951', POL: '#8247e5', ONDO: '#121c3a', BONK: '#f8a128', WIF: '#a8744f' };
function coinAvatar(base) {
  const B = String(base || '?').toUpperCase().replace(/^1000+/, '');
  let bg = COIN_COL[B];
  if (!bg) { let h = 0; for (const ch of B) h = (h * 31 + ch.charCodeAt(0)) >>> 0; bg = `hsl(${h % 360}, 55%, 42%)`; }
  const dark = /^#(1|2|0)/.test(bg) || /^#(23|2b|2e)/.test(bg);
  return { bg, fg: '#fff', t: B[0] || '?', dark };
}
const Panels = {
  rows: {},
  init() {
    const sb = $('#side-body'), rz = $('#side-resizer');
    const setW = w => { App.state.settings.sideW = w; sb.style.width = w + 'px'; };
    if (App.state.settings.sideW) setW(App.state.settings.sideW);
    rz.onpointerdown = e => {
      if (!App.state.settings.sideOpen) return;
      rz.setPointerCapture(e.pointerId); rz.classList.add('on');
      const x0 = e.clientX, w0 = sb.getBoundingClientRect().width;
      rz.onpointermove = ev => setW(Math.round(U.clamp(w0 - (ev.clientX - x0), 190, Math.min(640, window.innerWidth * 0.45))));
      rz.onpointerup = () => { rz.onpointermove = null; rz.classList.remove('on'); App.saveSoon(); };
    };
    rz.ondblclick = () => { setW(290); App.saveSoon(); };
    $$('#side-rail [data-tab]').forEach(b => b.onclick = () => {
      const st = App.state.settings;
      if ($('#side').classList.contains('auto-hidden')) { App.sideForce = true; st.sidePanel = b.dataset.tab; st.sideOpen = true; App.applySideAuto(); App.saveSoon(); this.render(); return; }
      if (st.sidePanel === b.dataset.tab && st.sideOpen) st.sideOpen = false;
      else { st.sidePanel = b.dataset.tab; st.sideOpen = true; }
      App.saveSoon(); this.render();
    });
    this.render();
  },
  render() {
    const st = App.state.settings;
    $('#side').classList.toggle('collapsed', !st.sideOpen);
    $$('#side-rail [data-tab]').forEach(b => b.classList.toggle('on', st.sideOpen && b.dataset.tab === st.sidePanel));
    if (!st.sideOpen) { this.rows = {}; return; }
    if (st.sidePanel === 'alerts') this.renderAlerts(true);
    else if (st.sidePanel === 'objects') this.refreshObjects(true);
    else if (st.sidePanel === 'cal') Calendar.render();
    else if (st.sidePanel === 'acct') Acct.renderPanel();
    else this.renderWatch();
  },
  body() { return $('#side-body'); },

  renderWatch() {
    const st = App.state.settings;
    if (!st.sideOpen || st.sidePanel !== 'watch') return;
    const b = this.body(), cur = App.active() && App.active().sym, so = st.wlSort || {};
    const hd = (k, t, tip) => `<span class="wl-h${so.key === k ? ' on' : ''}" data-k="${k}"${tip ? ` title="${tip}"` : ''}>${t}${so.key === k ? `<i>${so.dir > 0 ? '▲' : '▼'}</i>` : ''}</span>`;
    b.innerHTML = `<div class="sp-head"><span>Список наблюдения</span><button class="ib" id="wlAdd" title="Добавить символ">${U.icon('plus')}</button></div>
      <div class="wl-cols">${hd('sym', 'Символ', 'Сортировать по названию')}${hd('price', 'Цена', 'Сортировать по цене')}${hd('chg', 'Изм. 24ч', 'Сортировать по изменению за сутки')}${hd('corr', 'BTC', 'Корреляция с биткоином по часовым свечам: 1 — ходит как BTC, 0 — своей жизнью. Клик — сортировать')}</div><div class="wl"></div>`;
    $('#wlAdd', b).onclick = () => App.openSymbolSearch('', 'add');
    // клик по заголовку: по убыванию → по возрастанию → свой порядок
    $$('.wl-h', b).forEach(h => h.onclick = () => {
      const k = h.dataset.k, cur2 = st.wlSort || {};
      const first = k === 'sym' ? 1 : -1;
      st.wlSort = cur2.key !== k ? { key: k, dir: first } : cur2.dir === first ? { key: k, dir: -first } : null;
      App.saveSoon(); this.renderWatch();
      if (!st.wlSort) U.toast('Свой порядок — строки можно перетаскивать мышью', 'info', 2200);
    });
    const wl = $('.wl', b);
    this.rows = {};
    for (const s of this.watchOrder()) {
      const lb = Data.label(s);
      const exc = EX_SHORT[lb.ex] || '', fut = /^Фьюч/.test(lb.kind), av = coinAvatar(lb.base);
      const r = U.h(`<div class="wl-row${s === cur ? ' cur' : ''}" data-s="${U.esc(s)}" title="${U.esc(lb.short)} · ${lb.full}"><span class="wl-s${lb.base.length >= 7 ? ' long' : ''}"><span class="wl-av" style="background:${av.bg};color:${av.fg}">${U.esc(av.t)}</span><span class="wl-b">${U.esc(lb.base)}</span>${lb.quote && lb.quote !== 'USDT' ? `<span class="q">${U.esc(lb.quote)}</span>` : ''}${lb.ex !== 'BINANCE' ? `<span class="ex-mini${fut ? ' fut' : ''}"><span class="exn">${exc}${fut ? '·' : ''}</span>${fut ? '<span class="exf">F</span>' : ''}</span>` : ''}</span><span class="wl-p">—</span><span class="wl-c">—</span><span class="wl-k">…</span><button class="ib xs wl-x" title="Убрать">${U.icon('close', 12)}</button></div>`);
      r.onclick = e => { if (r._dragged) { r._dragged = false; return; } if (e.target.closest('.wl-x')) { this.removeFromWatch(s); return; } App.setSymbol(s); };
      this.dragRow(r, s, wl);
      wl.appendChild(r);
      this.rows[s] = { el: r, p: $('.wl-p', r), c: $('.wl-c', r), k: $('.wl-k', r), last: undefined };
      if (App.prices[s] != null) this.updateWatchRow(s, App.prices[s], App.changes[s]);
      const cv = Corr.cached(s); if (cv !== undefined) this.updateCorr(s, cv);
    }
    setTimeout(() => Corr.refreshWatch(), 1500);
    clearInterval(this._resort);
    if (so.key && so.key !== 'sym') this._resort = setInterval(() => this.resort(), 8000); // цены меняются — порядок обновляется спокойно, раз в 8 секунд
  },
  // порядок строк: свой (как в списке) или по выбранному столбцу
  watchOrder() {
    const list = App.state.watchlist.slice(), so = App.state.settings.wlSort;
    if (!so || !so.key) return list;
    const val = s => {
      if (so.key === 'sym') return Data.label(s).base;
      if (so.key === 'price') return App.prices[s];
      if (so.key === 'chg') return App.changes[s];
      const c = Corr.cached(s); return c === 'btc' ? 2 : c;
    };
    return list.map((s, i) => ({ s, i, v: val(s) })).sort((a, b) => {
      const na = a.v == null || a.v !== a.v, nb = b.v == null || b.v !== b.v;
      if (na || nb) return na === nb ? a.i - b.i : na ? 1 : -1; // без данных — в конец
      if (so.key === 'sym') return so.dir * String(a.v).localeCompare(String(b.v));
      return so.dir * (a.v - b.v) || a.i - b.i;
    }).map(x => x.s);
  },
  resort() {
    const st = App.state.settings, wl = this.body() && $('.wl', this.body());
    if (!wl || !st.wlSort || !st.sideOpen || st.sidePanel !== 'watch' || this._dragging) return;
    const order = this.watchOrder(), now = [...wl.children].map(r => r.dataset.s);
    if (order.join('|') === now.join('|')) return;
    for (const s of order) if (this.rows[s]) wl.appendChild(this.rows[s].el);
  },
  // перетаскивание строк мышью
  dragRow(r, s, wl) {
    r.onpointerdown = e => {
      if (e.button !== 0 || e.target.closest('.wl-x')) return;
      const y0 = e.clientY; let on = false, ph = null, hgt = 0;
      const move = ev => {
        if (!on) {
          if (Math.abs(ev.clientY - y0) < 5) return;
          on = true; this._dragging = true; r.setPointerCapture(e.pointerId);
          hgt = r.getBoundingClientRect().height;
          ph = document.createElement('div'); ph.className = 'wl-ph'; ph.style.height = hgt + 'px';
          wl.style.position = 'relative';
          const top0 = r.offsetTop;
          r.after(ph); r.classList.add('drag');
          Object.assign(r.style, { position: 'absolute', top: top0 + 'px', left: '0', right: '0' }); // строка «поднимается» над списком
        }
        r.style.transform = `translateY(${ev.clientY - y0}px)`;
        // куда вставить: по середине соседних строк
        const rows = [...wl.querySelectorAll('.wl-row')].filter(x => x !== r);
        let before = null;
        for (const x of rows) { const bb = x.getBoundingClientRect(); if (ev.clientY < bb.top + bb.height / 2) { before = x; break; } }
        if (before) { if (ph.nextSibling !== before) wl.insertBefore(ph, before); } else if (wl.lastChild !== ph) wl.appendChild(ph);
        // автопрокрутка у краёв
        const body = this.body(), bb = body.getBoundingClientRect();
        if (ev.clientY < bb.top + 40) body.scrollTop -= 12; else if (ev.clientY > bb.bottom - 40) body.scrollTop += 12;
      };
      const up = () => {
        r.removeEventListener('pointermove', move); r.removeEventListener('pointerup', up); r.removeEventListener('pointercancel', up);
        if (!on) return;
        r._dragged = true; this._dragging = false;
        wl.insertBefore(r, ph); ph.remove();
        r.classList.remove('drag'); Object.assign(r.style, { transform: '', position: '', top: '', left: '', right: '' });
        const order = [...wl.querySelectorAll('.wl-row')].map(x => x.dataset.s);
        const st = App.state.settings, wasSorted = !!(st.wlSort && st.wlSort.key);
        App.state.watchlist = order.concat(App.state.watchlist.filter(x => !order.includes(x)));
        if (wasSorted) { st.wlSort = null; this.renderWatch(); U.toast('Сортировка выключена — теперь ваш порядок', 'info', 2200); }
        App.saveSoon();
      };
      r.addEventListener('pointermove', move); r.addEventListener('pointerup', up); r.addEventListener('pointercancel', up);
    };
  },
  updateCorr(s, v) {
    const r = this.rows && this.rows[s]; if (!r || !r.k) return;
    if (v === 'btc') { r.k.textContent = '·'; r.k.className = 'wl-k'; r.k.title = 'Это сам биткоин'; return; }
    r.k.textContent = Corr.fmt(v); r.k.className = 'wl-k ' + Corr.cls(v);
    r.k.title = `Корреляция с BTC (1ч, 100 свечей): ${v == null ? 'мало данных' : v.toFixed(2) + ' — ' + Corr.words(v)}`;
  },
  updateWatchRow(s, c, ch) {
    const r = this.rows[s]; if (!r) return;
    const old = r.last; r.last = c;
    r.p.textContent = wlPrice(c); r.p.title = U.fmt(c, c);
    if (ch != null && isFinite(ch)) { r.c.textContent = `${ch >= 0 ? '+' : ''}${ch.toFixed(2)}%`; r.c.className = 'wl-c ' + (ch >= 0 ? 'up' : 'dn'); }
    if (old !== undefined && c !== old) {
      r.p.classList.remove('fl-up', 'fl-dn'); void r.p.offsetWidth;
      r.p.classList.add(c > old ? 'fl-up' : 'fl-dn');
    }
  },
  addToWatch(s) {
    if (!App.state.watchlist.includes(s)) App.state.watchlist.push(s);
    App.saveSoon(); App.restartTicker(); this.renderWatch();
  },
  removeFromWatch(s) {
    App.state.watchlist = App.state.watchlist.filter(x => x !== s);
    App.saveSoon(); App.restartTicker(); this.renderWatch();
  },
  markCurrent() {
    const cur = App.active() && App.active().sym;
    for (const [s, r] of Object.entries(this.rows)) r.el.classList.toggle('cur', s === cur);
  },

  renderAlerts(force) {
    const st = App.state.settings;
    const cnt = Alerts.list.filter(a => a.active).length;
    const badge = $('#alertBadge'); if (badge) { badge.textContent = cnt || ''; badge.style.display = cnt ? '' : 'none'; }
    if (!st.sideOpen || st.sidePanel !== 'alerts') return;
    void force;
    const b = this.body();
    b.innerHTML = `<div class="sp-head"><span>Оповещения</span><button class="ib" id="alAdd" title="Создать оповещение">${U.icon('plus')}</button></div>
      <div class="al-list">${Alerts.list.length ? '' : '<div class="empty">Нет оповещений.<br>Правый клик по графику → «Добавить оповещение», или Alt+A.</div>'}</div>
      <div class="sp-head sub"><span>Журнал срабатываний</span>${Alerts.log.length ? '<button class="ib xs" id="alClr" title="Очистить">' + U.icon('trash', 14) + '</button>' : ''}</div>
      <div class="al-log">${Alerts.log.map(l => `<div class="log-row"><span class="muted">${U.fmtDateTime(l.time)}</span> ${U.esc(l.text)}</div>`).join('') || '<div class="empty">Пока пусто</div>'}</div>`;
    $('#alAdd', b).onclick = () => Alerts.openDialog();
    const clr = $('#alClr', b); if (clr) clr.onclick = () => { App.state.alertLog = []; App.saveSoon(); this.renderAlerts(); };
    const list = $('.al-list', b);
    for (const a of Alerts.list) {
      const r = U.h(`<div class="al-row${a.active ? '' : ' off'}"><div class="al-main"><b>${Data.label(a.sym).short}</b> <span class="muted">${Data.label(a.sym).exName} · ${Alerts.condName(a.cond)}</span> <b>${U.fmt(a.price, a.price)}</b>${a.msg ? `<div class="muted sm">${U.esc(a.msg)}</div>` : ''}<div class="muted sm">${a.active ? 'Активно' : (a.fired ? 'Сработало ' + U.fmtDateTime(a.fired) : 'Остановлено')}${a.repeat ? ' · повторяющееся' : ''}</div></div>
        <button class="ib xs" data-a="tog" title="${a.active ? 'Остановить' : 'Перезапустить'}">${U.icon(a.active ? 'eye' : 'eyeOff', 14)}</button><button class="ib xs" data-a="del" title="Удалить">${U.icon('trash', 14)}</button></div>`);
      r.onclick = e => {
        const btn = e.target.closest('[data-a]');
        if (!btn) { App.setSymbol(a.sym); return; }
        if (btn.dataset.a === 'del') Alerts.remove(a.id); else Alerts.toggle(a.id);
      };
      list.appendChild(r);
    }
  },

  refreshObjects(force) {
    const st = App.state.settings;
    if (!st.sideOpen || st.sidePanel !== 'objects') return;
    void force;
    const ch = App.active(); if (!ch) return;
    const b = this.body();
    const inds = ch.cfg.indicators, ds = App.getDrawings(ch.sym);
    b.innerHTML = `<div class="sp-head"><span>Дерево объектов · ${Data.label(ch.sym).short}</span></div>
      <div class="sp-head sub"><span>Индикаторы (${inds.length})</span><button class="ib xs" id="obAddInd" title="Добавить">${U.icon('plus', 14)}</button></div>
      <div class="ob-list" id="obInds"></div>
      <div class="sp-head sub"><span>Рисунки (${ds.length})</span>${ds.length ? `<button class="ib xs" id="obDelAll" title="Удалить все">${U.icon('trash', 14)}</button>` : ''}</div>
      <div class="ob-list" id="obDraws"></div>`;
    $('#obAddInd', b).onclick = () => App.openIndicatorPicker();
    const da = $('#obDelAll', b); if (da) da.onclick = () => App.deleteAllDrawings();
    const il = $('#obInds', b);
    if (!inds.length) il.innerHTML = '<div class="empty">Нет индикаторов</div>';
    for (const inst of inds) {
      const r = U.h(`<div class="ob-row${inst.visible === false ? ' off' : ''}"><span class="ob-ic">${U.icon('fx', 14)}</span><span class="ob-name">${U.esc(IND.title(inst))}</span>
        <button class="ib xs" data-a="vis">${U.icon(inst.visible === false ? 'eyeOff' : 'eye', 14)}</button><button class="ib xs" data-a="set">${U.icon('gear', 14)}</button><button class="ib xs" data-a="del">${U.icon('trash', 14)}</button></div>`);
      r.onclick = e => { const btn = e.target.closest('[data-a]'); if (btn) App.indAction(ch, inst, btn.dataset.a); };
      il.appendChild(r);
    }
    const dl = $('#obDraws', b);
    if (!ds.length) dl.innerHTML = '<div class="empty">Нет рисунков. Выберите инструмент на левой панели.</div>';
    ds.slice().reverse().forEach(d => {
      const T = DRAW.TOOLS[d.type];
      const r = U.h(`<div class="ob-row${d.hidden ? ' off' : ''}${ch.selected === d ? ' sel' : ''}"><span class="ob-ic">${U.icon(T.icon, 14)}</span><span class="ob-name">${U.esc(d.type === 'text' ? '«' + (d.text || '').slice(0, 20) + '»' : T.name)}</span>
        <button class="ib xs" data-a="vis">${U.icon(d.hidden ? 'eyeOff' : 'eye', 14)}</button><button class="ib xs" data-a="lock">${U.icon(d.locked ? 'lock' : 'unlock', 14)}</button><button class="ib xs" data-a="del">${U.icon('trash', 14)}</button></div>`);
      r.onclick = e => {
        const btn = e.target.closest('[data-a]');
        if (!btn) { ch.selected = d; App.onSelect(ch); ch.invalidate(); this.refreshObjects(); return; }
        const a = btn.dataset.a;
        if (a === 'del') { App.deleteDrawing(ch.sym, d); return; }
        App.pushUndo(ch.sym);
        if (a === 'vis') d.hidden = !d.hidden;
        if (a === 'lock') d.locked = !d.locked;
        App.drawingsChanged(ch.sym, true);
      };
      dl.appendChild(r);
    });
  },
};
