'use strict';
// Новости по монете из публичных Telegram-каналов (бесплатно, без ключей) — логика из скринера пробоев (news.py):
// читаем t.me/s/<канал>, ищем упоминания монеты, определяем тон (▲/▼), срочность, влиятельных людей,
// листинги/реклама отбрасываются; перевод на русский — Google Translate, запасной MyMemory (translate.py).
const News = (() => {
  const CHANNELS = [['WatcherGuru', 'Watcher.Guru'], ['wublockchainenglish', 'Wu Blockchain'], ['cointelegraph', 'Cointelegraph'], ['CoinDeskGlobal', 'CoinDesk']];
  const PAGES = 3; // страниц на канал (по ~20 постов)
  const COIN_NAMES = {
    bitcoin: 'BTC', btc: 'BTC', ethereum: 'ETH', ether: 'ETH', eth: 'ETH', ripple: 'XRP', xrp: 'XRP',
    solana: 'SOL', dogecoin: 'DOGE', doge: 'DOGE', cardano: 'ADA', chainlink: 'LINK', avalanche: 'AVAX',
    polkadot: 'DOT', litecoin: 'LTC', tron: 'TRX', toncoin: 'TON', hyperliquid: 'HYPE', zcash: 'ZEC',
    'shiba inu': 'SHIB', pepe: 'PEPE', sui: 'SUI', aptos: 'APT', arbitrum: 'ARB', optimism: 'OP',
    polygon: 'POL', 'near protocol': 'NEAR', uniswap: 'UNI', aave: 'AAVE', stellar: 'XLM', monero: 'XMR',
    bnb: 'BNB', 'binance coin': 'BNB', worldcoin: 'WLD', ondo: 'ONDO', ethena: 'ENA', fartcoin: 'FARTCOIN',
    'pump.fun': 'PUMP', bonk: 'BONK', dogwifhat: 'WIF', render: 'RENDER', injective: 'INJ', celestia: 'TIA',
    hedera: 'HBAR', algorand: 'ALGO', filecoin: 'FIL', cosmos: 'ATOM', kaspa: 'KAS', 'bitcoin cash': 'BCH',
  };
  const INFLUENCERS = [
    [/\bCZ\b|changpeng zhao|@cz_binance|binance founder/i, 'CZ'],
    [/elon musk|@elonmusk|\bmusk\b/i, 'Илон Маск'],
    [/donald trump|president trump|\btrump\b|@realdonaldtrump/i, 'Трамп'],
    [/michael saylor|\bsaylor\b|@saylor/i, 'Майкл Сэйлор'],
    [/vitalik|buterin/i, 'Виталик Бутерин'],
    [/jerome powell|\bpowell\b/i, 'Пауэлл, ФРС'],
    [/larry fink/i, 'Ларри Финк, BlackRock'],
    [/brian armstrong/i, 'Брайан Армстронг, Coinbase'],
    [/arthur hayes/i, 'Артур Хейс'],
    [/justin sun/i, 'Джастин Сан'],
    [/richard teng/i, 'Ричард Тенг, Binance'],
    [/paolo ardoino/i, 'Паоло Ардоино, Tether'],
    [/brad garlinghouse/i, 'Брэд Гарлингхаус, Ripple'],
    [/cathie wood/i, 'Кэти Вуд'],
    [/\bsec chair\w*/i, 'глава SEC'],
  ];
  const RU_NAMES = { 'биткоин': 'BTC', 'биткойн': 'BTC', 'эфириум': 'ETH', 'эфир': 'ETH', 'рипл': 'XRP', 'солана': 'SOL', 'догикоин': 'DOGE', 'доги': 'DOGE', 'кардано': 'ADA', 'лайткоин': 'LTC', 'трон': 'TRX', 'тон': 'TON', 'тонкоин': 'TON', 'шиба': 'SHIB', 'пепе': 'PEPE', 'суи': 'SUI', 'аптос': 'APT', 'арбитрум': 'ARB', 'полигон': 'POL', 'юнисвап': 'UNI', 'монеро': 'XMR', 'биэнби': 'BNB', 'чейнлинк': 'LINK', 'аваланч': 'AVAX', 'полкадот': 'DOT' };
  const AMBIGUOUS = new Set(['ONE', 'GAS', 'OP', 'NEAR', 'SUN', 'CAKE', 'MASK', 'ID', 'AI', 'IO', 'ME', 'BAND', 'ACE', 'BOND', 'PEOPLE',
    'SAND', 'GALA', 'FLOW', 'ROSE', 'DENT', 'HOT', 'ARK', 'LIT', 'LAB', 'PUMP', 'MOVE', 'TRUMP', 'BIO', 'KAITO',
    'S', 'T', 'W', 'G', 'C', 'U', 'NOT', 'BLUR', 'MAGIC', 'BEL', 'MEW', 'JUP', 'ALT', 'BANANA', 'SUPER',
    'TRU', 'PROM', 'COOKIE', 'POPCAT', 'DOGS', 'HIGH', 'LOW', 'KEY', 'SIGN', 'OM', 'AUCTION', 'ZK', 'XAI']);
  const SKIP = /\b(will list|lists|listing|listed|delist|delisting|launchpool|airdrop|giveaway|subscribe|join our|promo|sponsored|advertis)/i;
  const POS = /\b(approv\w*|etf inflow\w*|inflows?|buys?|bought|accumulat\w*|reserve|adopt\w*|partner\w*|launch\w*|wins?|won|dismiss\w*|drops? (lawsuit|case)|settle\w*|bullish|surg\w*|soar\w*|record high|ath|all-time high|upgrade|mainnet|integrat\w*|backs?|invest\w*|rate cut\w*|cuts? rates?)\b/gi;
  const NEG = /\b(hack\w*|exploit\w*|drain\w*|stolen|sues?|sued|lawsuit|charg\w*|arrest\w*|ban\w*|reject\w*|delay\w*|outflow\w*|sells?|sold|dump\w*|crash\w*|plung\w*|liquidat\w*|investigat\w*|fraud|bearish|halt\w*|freez\w*|depeg\w*|insolven\w*|bankrupt\w*|rate hike\w*|hikes? rates?|unlock\w*)\b/gi;
  const URGENT = /(JUST IN|BREAKING|🚨|⚡)/i;
  const MACRO = /\b(fed|fomc|powell|cpi|inflation|interest rate|rates?|tariff\w*|sec|white house|trump|treasury|recession|jobs report|nfp|gdp)\b/i;

  // ---------- загрузка каналов ----------
  const cache = new Map(); // канал → { t, posts }
  function parseChannel(html, name) {
    const doc = new DOMParser().parseFromString(html, 'text/html'), out = [];
    for (const m of doc.querySelectorAll('.tgme_widget_message[data-post]')) {
      const post = m.getAttribute('data-post'), id = +post.split('/').pop();
      const tx = [...m.querySelectorAll('.tgme_widget_message_text')].find(x => !/reply/.test(x.className));
      const tm = m.querySelector('time[datetime]');
      if (!tx || !tm || !id) continue;
      tx.querySelectorAll('br').forEach(b => b.replaceWith('\n'));
      const text = tx.textContent.replace(/\n{3,}/g, '\n\n').trim();
      if (!text) continue;
      out.push({ id, post, ch: name, ts: Date.parse(tm.getAttribute('datetime')) || Date.now(), text });
    }
    return out;
  }
  async function fetchPage(name, before) {
    const r = await window.orbita.fetchText(`https://t.me/s/${name}${before ? `?before=${before}` : ''}`);
    if (!r || !r.ok) throw new Error(r && r.status ? `HTTP ${r.status}` : 'нет связи с Telegram');
    return parseChannel(r.text, name);
  }
  async function channel(name) {
    const c = cache.get(name);
    if (c && Date.now() - c.t < 60000) return c.posts;
    let posts = [], before = null;
    for (let i = 0; i < PAGES; i++) {
      const p = await fetchPage(name, before);
      if (!p.length) break;
      posts = posts.concat(p);
      before = Math.min(...p.map(x => x.id));
    }
    const seen = new Set(); posts = posts.filter(p => !seen.has(p.post) && seen.add(p.post));
    cache.set(name, { t: Date.now(), posts });
    return posts;
  }

  // ---------- разбор ----------
  const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function mentions(text, base) {
    const low = text.toLowerCase(), B = base.toUpperCase();
    for (const [name, tk] of Object.entries(COIN_NAMES)) {
      if (tk !== B) continue;
      if (!(['ETH', 'BTC', 'XRP', 'DOGE', 'BNB'].includes(tk) || name.length > 3 || name.toUpperCase() === tk)) continue;
      const m = new RegExp(`(?<![a-z])${esc(name)}(?![a-z])`).exec(low);
      if (m) return m.index;
    }
    let m = new RegExp(`\\$${esc(B)}\\b`).exec(text);
    if (m) return m.index;
    if (B.length >= 3 && !AMBIGUOUS.has(B)) { m = new RegExp(`\\b${esc(B)}\\b`).exec(text); if (m) return m.index; }
    for (const [ru, tk] of Object.entries(RU_NAMES)) { if (tk === B) { const mm = low.indexOf(ru); if (mm >= 0) return mm; } }
    return -1;
  }
  function analyze(text) {
    if (SKIP.test(text)) return null;
    const pos = (text.match(POS) || []).length, neg = (text.match(NEG) || []).length;
    const who = [];
    for (const [re, n] of INFLUENCERS) if (re.test(text) && !who.includes(n)) who.push(n);
    return { tone: pos > neg ? 1 : neg > pos ? -1 : 0, urgent: URGENT.test(text), macro: MACRO.test(text), who };
  }

  // ---------- перевод ----------
  const tcache = new Map();
  const KEEP = new Set(['ETF', 'ETFs', 'USDT', 'USDC', 'DeFi', 'NFT', 'BTC', 'ETH', 'XRP', 'SOL', 'BNB', 'DOGE']);
  function protect(text, tickers) {
    const keep = [], names = new Set([...tickers, ...KEEP]);
    const t = text.replace(/\$[A-Za-z][A-Za-z0-9]{1,9}\b|\b[A-Za-z][A-Za-z0-9]{1,9}\b/g, w => {
      if (w.startsWith('$') || names.has(w)) { keep.push(w); return `[${keep.length - 1}]`; }
      return w;
    });
    return [t, keep];
  }
  const restore = (t, keep) => keep.reduce((s, k, i) => s.replace(new RegExp(`\\[\\s*${i}\\s*\\]`, 'g'), () => k), t);
  async function translate(text, tickers = []) {
    text = (text || '').trim();
    if (!text || /[а-яё]/i.test(text)) return text;
    if (tcache.has(text)) return tcache.get(text);
    const [safe, keep] = protect(text.slice(0, 1500), tickers);
    const tries = [
      async () => { const r = await window.orbita.fetchJSON('https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q=' + encodeURIComponent(safe)); if (!r.ok || !r.data) throw 0; return r.data[0].map(p => p && p[0] || '').join(''); },
      async () => { const r = await window.orbita.fetchJSON('https://api.mymemory.translated.net/get?langpair=en|ru&q=' + encodeURIComponent(safe.slice(0, 480))); const o = r.ok && r.data && r.data.responseData && r.data.responseData.translatedText; if (!o || /MYMEMORY WARNING/i.test(o)) throw 0; return o; },
    ];
    for (const f of tries) {
      try { const out = restore(await f(), keep).trim(); if (out) { tcache.set(text, out); return out; } } catch { /* следующий */ }
    }
    return null;
  }

  // ---------- законные источники (для продажной версии): GDELT + объявления бирж ----------
  const NAME_OF = {}; for (const [name, tk] of Object.entries(COIN_NAMES)) { (NAME_OF[tk] = NAME_OF[tk] || []).push(name); }
  function coinQuery(base) {
    const B = base.toUpperCase(), names = NAME_OF[B] || [];
    const full = names.filter(n => n.length > 3)[0] || names[0];
    const terms = [full ? `"${full}"` : null, `"$${B}"`].filter(Boolean);
    return `(${terms.join(' OR ')}) (crypto OR cryptocurrency OR token OR blockchain)`;
  }
  function gdeltDate(s) { // "20231115T130000Z" -> ms
    const m = /^(\d{4})(\d\d)(\d\d)T(\d\d)(\d\d)(\d\d)Z$/.exec(s || '');
    return m ? Date.parse(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}Z`) : Date.now();
  }
  async function gdelt(query) {
    const url = 'https://api.gdeltproject.org/api/v2/doc/doc?query=' + encodeURIComponent(query) +
      '&mode=artlist&maxrecords=45&sort=datedesc&timespan=7d&format=json';
    const r = await window.orbita.fetchJSON(url);
    if (!r || !r.ok || !r.data || !Array.isArray(r.data.articles)) throw new Error('GDELT недоступен');
    return r.data.articles.map(a => ({
      url: a.url, title: (a.title || '').trim(), text: (a.title || '').trim(),
      source: a.domain || 'GDELT', ts: gdeltDate(a.seendate), lang: a.language || '',
    })).filter(x => x.url && x.title);
  }
  async function bybitAnn(locale) {
    const url = `https://api.bybit.com/v5/announcements/index?locale=${locale}&limit=30`;
    const r = await window.orbita.fetchJSON(url);
    const list = r && r.ok && r.data && r.data.result && r.data.result.list;
    if (!Array.isArray(list)) throw new Error('Bybit недоступен');
    return list.map(a => ({
      url: a.url, title: (a.title || '').trim(), text: (a.title || '').trim(),
      source: 'Bybit', ts: +a.dateTimestamp || (a.publishTime ? +a.publishTime : Date.now()),
      lang: locale.startsWith('ru') ? 'rus' : 'eng', kind: a.type && a.type.title || '',
    })).filter(x => x.url && x.title);
  }
  // разрешённые каналы (пусто, пока вы не получите согласие владельца и не впишете их сюда)
  const PERMITTED = []; // напр. [['WatcherGuru','Watcher.Guru']] — только с письменного разрешения
  async function loadLegal(force) {
    const my = tok, base = Data.label(sym).base;
    const jobs = [gdelt(coinQuery(base)), gdelt('(cryptocurrency OR bitcoin OR ethereum) (price OR market OR SEC OR ETF)'),
      bybitAnn('en-US'), bybitAnn('ru-RU')];
    for (const [ch] of PERMITTED) jobs.push(channel(ch).then(ps => ps.map(p => ({ url: 'https://t.me/' + p.post, title: p.text, text: p.text, source: 'Telegram', ts: p.ts, lang: /[а-яё]/i.test(p.text) ? 'rus' : 'eng' }))));
    const res = await Promise.allSettled(jobs);
    if (my !== tok) return;
    const got = [], errs = [];
    res.forEach(r => r.status === 'fulfilled' ? got.push(...r.value) : errs.push(r.reason && r.reason.message));
    const now = Date.now(), seen = new Set();
    const norm = s2 => (s2 || '').toLowerCase().replace(/[^a-zа-я0-9]/gi, '').slice(0, 60);
    const fresh = got.filter(p => now - p.ts < 7 * DAY && p.ts <= now + 36e5)
      .sort((x, y) => y.ts - x.ts)
      .filter(p => { const k = norm(p.title); if (!k || seen.has(k)) return false; seen.add(k); return true; })
      .map(p => ({ ...p, a: analyze(p.text) || { tone: 0, urgent: false, macro: false, who: [] } }));
    allItems = fresh.slice(0, 50);
    const B = base.toUpperCase();
    items = fresh.filter(p => mentions(p.title, B) >= 0 || (p.kind && new RegExp('\\b' + B + '\\b').test(p.title))).slice(0, 50);
    loading = false; err = got.length ? '' : (errs.find(Boolean) || 'нет данных');
    render();
  }

  // ---------- панель ----------
  let open = false, sym = null, items = [], allItems = [], mode = 'coin', loading = false, err = '', timer = null, tok = 0;
  const DAY = 864e5;
  function ago(ts) {
    const m = Math.max(0, Math.round((Date.now() - ts) / 6e4));
    if (m < 1) return 'только что'; if (m < 60) return `${m} мин назад`;
    const h = Math.round(m / 60); if (h < 24) return `${h} ч назад`;
    const d = Math.round(h / 24); return `${d} д назад`;
  }
  function panel() {
    let el = document.getElementById('newsPanel');
    if (!el) {
      el = U.h(`<div id="newsPanel" class="news-panel"><div class="np-head"><b>Новости</b><span class="np-sym"></span><div class="np-tabs"><button data-m="coin">Монета</button><button data-m="all">Все</button></div><button class="ib xs np-ref" title="Обновить">${U.icon('refresh', 15)}</button><button class="ib xs np-x" title="Закрыть (Esc)">${U.icon('close', 15)}</button></div><div class="np-body"></div><div class="np-foot">Telegram: Watcher.Guru, Wu Blockchain, Cointelegraph, CoinDesk · перевод автоматический</div></div>`);
      el.querySelector('.np-x').onclick = () => toggle(false);
      el.querySelector('.np-ref').onclick = () => { cache.clear(); load(true); };
      el.querySelectorAll('.np-tabs button').forEach(b => b.onclick = () => { mode = b.dataset.m; render(); });
      document.body.appendChild(el);
    }
    return el;
  }
  function render() {
    const el = panel(), base = sym ? Data.label(sym).base : '';
    el.querySelector('.np-sym').textContent = base;
    el.querySelectorAll('.np-tabs button').forEach(b => b.classList.toggle('on', b.dataset.m === mode));
    const body = el.querySelector('.np-body');
    const list = mode === 'coin' ? items : allItems;
    const foot = el.querySelector('.np-foot');
    if (foot) foot.textContent = legal ? 'Источники: GDELT (мировые СМИ) и официальные объявления бирж. Текст — на языке источника, без перевода.' : 'Telegram: Watcher.Guru, Wu Blockchain, Cointelegraph, CoinDesk';
    if (loading && !list.length) { body.innerHTML = '<div class="np-note">Загружаю свежие новости…</div>'; return; }
    if (err && !list.length) { body.innerHTML = `<div class="np-note">Не удалось загрузить новости: ${U.esc(err)}.<br>Проверьте интернет${legal ? '' : '; если Telegram заблокирован — включите VPN'}.</div>`; return; }
    if (!list.length) {
      body.innerHTML = `<div class="np-note">За последнюю неделю отдельных новостей про ${U.esc(base)} нет.<br><button class="np-link">Показать общие крипто-новости</button></div>`;
      body.querySelector('.np-link').onclick = () => { mode = 'all'; render(); };
      return;
    }
    body.innerHTML = '';
    for (const it of list) {
      const a = it.a, tone = a.tone > 0 ? 'np-up' : a.tone < 0 ? 'np-dn' : '';
      const src = U.esc(it.source || it.chName || ''), link = it.url || (it.post ? 'https://t.me/' + it.post : '');
      const row = U.h(`<div class="np-item ${tone}${a.urgent ? ' urgent' : ''}">
        <div class="np-meta"><span class="np-tone">${a.tone > 0 ? '▲' : a.tone < 0 ? '▼' : '•'}</span><span>${ago(it.ts)}</span><span class="np-ch">${src}</span>${a.urgent ? '<span class="np-badge">срочно</span>' : ''}${a.who.length ? `<span class="np-who">${U.esc(a.who.join(', '))}</span>` : ''}</div>
        <div class="np-text"></div>
        <div class="np-act">${link ? `<a href="${U.esc(link)}" target="_blank" rel="noopener">открыть ↗</a>` : ''}</div></div>`);
      const tx = row.querySelector('.np-text');
      tx.textContent = it.title || it.text;
      tx.onclick = () => row.classList.toggle('full');
      body.appendChild(row);
    }
  }
  async function translateVisible(list) {
    const my = tok, base = sym ? Data.label(sym).base : '';
    const todo = list.slice(0, 25).filter(it => it.ru === undefined);
    let i = 0;
    const worker = async () => {
      while (i < todo.length && my === tok) {
        const it = todo[i++]; it.ru = null;
        it.ru = await translate(it.text, [base]);
        if (my === tok && it._paint) it._paint();
      }
    };
    await Promise.all([worker(), worker(), worker()]);
  }
  async function load(force) {
    if (!open || !sym) return;
    const my = ++tok, base = Data.label(sym).base;
    loading = true; err = ''; if (force) { items = []; allItems = []; } render();
    if (legal) { return loadLegal(force); }
    const res = await Promise.allSettled(CHANNELS.map(([n]) => channel(n)));
    if (my !== tok) return;
    const posts = [], errs = [];
    res.forEach((r, k) => { if (r.status === 'fulfilled') r.value.forEach(p => posts.push({ ...p, chName: CHANNELS[k][1] })); else errs.push(r.reason && r.reason.message || 'ошибка'); });
    const now = Date.now(), fresh = posts.filter(p => now - p.ts < 7 * DAY).sort((x, y) => y.ts - x.ts);
    const old = new Map([...items, ...allItems].map(it => [it.post, it]));
    const mk = p => { const a = analyze(p.text); if (!a) return null; const o = old.get(p.post); return { ...p, a, ru: o ? o.ru : undefined }; };
    allItems = fresh.map(mk).filter(Boolean).slice(0, 40);
    items = fresh.filter(p => mentions(p.text, base) >= 0).map(mk).filter(Boolean).slice(0, 40);
    loading = false; err = posts.length ? '' : (errs[0] || 'нет данных');
    render();
  }
  let legal = false, legalKnown = false;
  async function detectMode() {
    if (legalKnown) return;
    try { const st = await window.orbita.licStatus(); legal = !!st.need; } catch { legal = false; }
    legalKnown = true;
  }
  async function toggle(v) {
    open = v === undefined ? !open : v;
    const el = panel(); el.classList.toggle('open', open);
    clearInterval(timer);
    if (open) { await detectMode(); const ch = App.active(); setSym(ch && ch.sym, true); timer = setInterval(() => load(), 60000); }
    App.buildTools();
  }
  function setSym(s, force) {
    if (!s) return;
    const changed = !sym || Data.label(s).base !== Data.label(sym).base;
    sym = s;
    if (!open) return;
    if (changed || force) { items = []; mode = 'coin'; load(); }
  }
  return { toggle, setSym, get open() { return open; }, mentions, analyze, translate, parseChannel };
})();
