'use strict';
// Демо-генератор котировок (используется, если Binance недоступен)
const Demo = (() => {
  const BASE = {
    BTCUSDT: 91500, ETHUSDT: 3150, BNBUSDT: 640, SOLUSDT: 142, XRPUSDT: 2.18, DOGEUSDT: 0.162,
    ADAUSDT: 0.47, TONUSDT: 2.9, LINKUSDT: 14.2, AVAXUSDT: 15.8, TRXUSDT: 0.29, DOTUSDT: 2.9,
    LTCUSDT: 96, BCHUSDT: 520, NEARUSDT: 2.3, APTUSDT: 3.4, ARBUSDT: 0.24, OPUSDT: 0.42,
    SUIUSDT: 1.8, PEPEUSDT: 0.0000062, SHIBUSDT: 0.0000098, ATOMUSDT: 2.9, UNIUSDT: 6.4,
    ETCUSDT: 13.5, FILUSDT: 1.7, INJUSDT: 6.8, AAVEUSDT: 190, ETHBTC: 0.0345,
  };
  const cache = {}, price = {};
  const base = s => BASE[s] || (() => { let h = 7; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return +(0.5 + (h % 20000) / 100).toFixed(2); })();
  function rng(seed) {
    let s = seed >>> 0 || 1;
    return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  }
  function gauss(r) { let u = 0, v = 0; while (!u) u = r(); while (!v) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function series(sym, iv) {
    const key = sym + '|' + iv;
    if (cache[key]) return cache[key];
    const ms = U.IV[iv], N = 3000, last = Math.floor(Date.now() / ms) * ms;
    let seed = 0; for (const c of key) seed = (seed * 33 + c.charCodeAt(0)) >>> 0;
    const r = rng(seed), vol = Math.min(0.08, 0.006 * Math.sqrt(ms / 36e5));
    let p = 1, drift = 0;
    const out = [];
    for (let i = 0; i < N; i++) {
      if (i % 120 === 0) drift = (r() - 0.5) * vol * 0.35;
      const o = p, c = o * Math.exp(drift + gauss(r) * vol);
      const h = Math.max(o, c) * Math.exp(Math.abs(gauss(r)) * vol * 0.5);
      const l = Math.min(o, c) * Math.exp(-Math.abs(gauss(r)) * vol * 0.5);
      out.push({ t: last - (N - 1 - i) * ms, o, h, l, c, v: (200 + r() * 800) * (1 + Math.abs(c - o) / o / vol) });
      p = c;
    }
    const k = (price[sym] || base(sym)) / p;
    out.forEach(b => { b.o *= k; b.h *= k; b.l *= k; b.c *= k; });
    price[sym] = out[N - 1].c;
    cache[key] = out;
    return out;
  }
  function klines(sym, iv, endTime, limit) {
    const s = series(sym, iv);
    let e = s.length - 1;
    if (endTime) while (e >= 0 && s[e].t > endTime) e--;
    if (e < 0) return [];
    return s.slice(Math.max(0, e - limit + 1), e + 1).map(b => ({ ...b }));
  }
  function subscribe(sym, iv, cb) {
    const s = series(sym, iv), ms = U.IV[iv];
    const id = setInterval(() => {
      let b = s[s.length - 1];
      if (Date.now() >= b.t + ms) { const nb = { t: b.t + ms, o: b.c, h: b.c, l: b.c, c: b.c, v: 0 }; s.push(nb); b = nb; }
      const cur = price[sym] ?? b.c;
      const c = cur * Math.exp((Math.random() - 0.5) * 0.0016);
      b.c = c; b.h = Math.max(b.h, c); b.l = Math.min(b.l, c); b.v += Math.random() * 20;
      price[sym] = c;
      cb({ ...b });
    }, 1000);
    return { close() { clearInterval(id); } };
  }
  function ref24(sym) { const d = series(sym, '1d'); return d[d.length - 1].o; }
  function miniTicker(syms, cb) {
    const tick = () => syms.forEach(s => {
      if (price[s] == null) series(s, '1d');
      price[s] *= Math.exp((Math.random() - 0.5) * 0.0006);
      cb(s, price[s], (price[s] / ref24(s) - 1) * 100);
    });
    tick();
    const id = setInterval(tick, 1500);
    return { close() { clearInterval(id); } };
  }
  function tickerList() {
    return Object.keys(BASE).map(s => {
      if (price[s] == null) series(s, '1d');
      return { s, c: price[s], ch: (price[s] / ref24(s) - 1) * 100, qv: 1e6 };
    });
  }
  return { klines, subscribe, miniTicker, tickerList };
})();

// Рыночные данные: несколько бирж (публичные API, без ключей)
const Data = (() => {
  let mode = 'unknown';
  const listeners = [];
  function setMode(m) { if (mode === m) return; mode = m; listeners.forEach(f => f(m)); }

  async function getJSON(url) {
    if (window.orbita && window.orbita.fetchJSON) {
      const r = await window.orbita.fetchJSON(url);
      if (!r.ok) { const e = new Error((r.data && (r.data.msg || r.data.message || r.data.retMsg)) || r.text || ('HTTP ' + r.status)); e.status = r.status; e.data = r.data; throw e; }
      return r.data;
    }
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 10000);
    try {
      const r = await fetch(url, { signal: ctl.signal });
      const data = await r.json().catch(() => null);
      if (!r.ok) { const e = new Error((data && (data.msg || data.message)) || 'HTTP ' + r.status); e.status = r.status; e.data = data; throw e; }
      return data;
    } finally { clearTimeout(to); }
  }
  const bad = m => { const e = new Error(m || 'Символ не найден'); e.bad = true; return e; };
  const cat = (s, q) => [s, q];
  const sec = ms => Math.floor(ms / 1000);

  // ---------- провайдеры ----------
  const BIN_IV = Object.fromEntries(Object.keys(U.IV).map(k => [k, k]));
  const P = {
    BINANCE: {
      name: 'Binance', kind: 'Спот', ws: true, max: 1000, iv: BIN_IV, split: s => U.splitSym(s),
      hosts: ['https://api.binance.com', 'https://data-api.binance.vision'], hi: 0,
      async get(path) {
        let err;
        for (let k = 0; k < this.hosts.length; k++) {
          const i = (this.hi + k) % this.hosts.length;
          try { const d = await getJSON(this.hosts[i] + path); this.hi = i; return d; }
          catch (e) { if (e.status === 400) throw bad(e.message); err = e; }
        }
        throw err;
      },
      async klines(sym, iv, end, limit) {
        const d = await this.get(`/api/v3/klines?symbol=${sym}&interval=${iv}&limit=${limit}${end ? `&endTime=${end}` : ''}`);
        return d.map(k => ({ t: k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
      },
      async tickers() {
        const d = await this.get('/api/v3/ticker/24hr');
        return d.filter(x => +x.quoteVolume > 0).map(x => ({ s: x.symbol, c: +x.lastPrice, ch: +x.priceChangePercent, qv: +x.quoteVolume }));
      },
      wsBases: ['wss://stream.binance.com:443', 'wss://data-stream.binance.vision', 'wss://stream.binance.com:9443'],
      wsUrl: (sym, iv) => `wss://stream.binance.com:9443/ws/${sym.toLowerCase()}@kline_${iv}`,
      wsTick: (syms, a = 0) => `${['wss://stream.binance.com:443', 'wss://data-stream.binance.vision', 'wss://stream.binance.com:9443'][a % 3]}/stream?streams=${syms.map(s => s.toLowerCase() + '@miniTicker').join('/')}`,
    },
    BINANCEF: {
      name: 'Binance', kind: 'Фьючерсы', ws: true, max: 1500, iv: BIN_IV, split: s => U.splitSym(s),
      async klines(sym, iv, end, limit) {
        try {
          const d = await getJSON(`https://fapi.binance.com/fapi/v1/klines?symbol=${sym}&interval=${iv}&limit=${limit}${end ? `&endTime=${end}` : ''}`);
          return d.map(k => ({ t: k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
        } catch (e) { if (e.status === 400) throw bad(e.message); throw e; }
      },
      async tickers() {
        const d = await getJSON('https://fapi.binance.com/fapi/v1/ticker/24hr');
        return d.filter(x => +x.quoteVolume > 0).map(x => ({ s: x.symbol, c: +x.lastPrice, ch: +x.priceChangePercent, qv: +x.quoteVolume }));
      },
      wsBases: ['wss://fstream.binance.com', 'wss://fstream.binance.com:443'],
      wsUrl: (sym, iv) => `wss://fstream.binance.com/ws/${sym.toLowerCase()}@kline_${iv}`,
      wsTick: syms => `wss://fstream.binance.com/stream?streams=${syms.map(s => s.toLowerCase() + '@miniTicker').join('/')}`,
    },
  };
  const bybit = (category, kind) => ({
    name: 'Bybit', kind, max: 1000, split: s => U.splitSym(s),
    iv: { '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '2h': '120', '4h': '240', '6h': '360', '12h': '720', '1d': 'D', '1w': 'W', '1M': 'M' },
    async klines(sym, iv, end, limit) {
      const j = await getJSON(`https://api.bybit.com/v5/market/kline?category=${category}&symbol=${sym}&interval=${iv}&limit=${limit}${end ? `&end=${end}` : ''}`);
      if (j.retCode !== 0) throw bad(j.retMsg);
      return j.result.list.slice().reverse().map(k => ({ t: +k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
    },
    async tickers() {
      const j = await getJSON(`https://api.bybit.com/v5/market/tickers?category=${category}`);
      return (j.result && j.result.list || []).filter(x => +x.turnover24h > 0).map(x => ({ s: x.symbol, c: +x.lastPrice, ch: +x.prevPrice24h ? (x.lastPrice / x.prevPrice24h - 1) * 100 : 0, qv: +x.turnover24h }));
    },
  });
  P.BYBIT = bybit('spot', 'Спот');
  P.BYBITF = bybit('linear', 'Фьючерсы');
  P.OKX = {
    name: 'OKX', kind: 'Спот', max: 300, split: s => s.split('-'),
    iv: { '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '2h': '2H', '4h': '4H', '6h': '6Hutc', '12h': '12Hutc', '1d': '1Dutc', '3d': '3Dutc', '1w': '1Wutc', '1M': '1Mutc' },
    async klines(sym, iv, end, limit) {
      const url = end
        ? `https://www.okx.com/api/v5/market/history-candles?instId=${sym}&bar=${iv}&limit=100&after=${end + 1}`
        : `https://www.okx.com/api/v5/market/candles?instId=${sym}&bar=${iv}&limit=${Math.min(limit, 300)}`;
      const j = await getJSON(url).catch(e => { if (e.data && e.data.code) throw bad(e.data.msg); throw e; });
      if (j.code !== '0') throw bad(j.msg);
      return j.data.slice().reverse().map(k => ({ t: +k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
    },
    async tickers() {
      const j = await getJSON('https://www.okx.com/api/v5/market/tickers?instType=SPOT');
      return (j.data || []).filter(x => +x.volCcy24h > 0).map(x => ({ s: x.instId, c: +x.last, ch: +x.open24h ? (x.last / x.open24h - 1) * 100 : 0, qv: +x.volCcy24h }));
    },
  };
  const gateErr = e => { if (e.status === 400 || (e.data && e.data.label)) throw bad(e.data && (e.data.message || e.data.label)); throw e; };
  P.GATE = {
    name: 'Gate', kind: 'Спот', max: 1000, split: s => s.split('_'),
    iv: { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '8h': '8h', '1d': '1d', '1w': '7d', '1M': '30d' },
    async klines(sym, iv, end, limit, ivMs) {
      const q = end ? `&from=${sec(end - limit * ivMs)}&to=${sec(end)}` : `&limit=${limit}`;
      const d = await getJSON(`https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=${sym}&interval=${iv}${q}`).catch(gateErr);
      return d.map(r => ({ t: +r[0] * 1000, o: +r[5], h: +r[3], l: +r[4], c: +r[2], v: +r[6] }));
    },
    async tickers() {
      const d = await getJSON('https://api.gateio.ws/api/v4/spot/tickers');
      return d.filter(x => +x.quote_volume > 0).map(x => ({ s: x.currency_pair, c: +x.last, ch: +x.change_percentage, qv: +x.quote_volume }));
    },
  };
  P.GATEF = {
    name: 'Gate', kind: 'Фьючерсы', max: 1000, split: s => s.split('_'),
    iv: { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '2h': '2h', '4h': '4h', '6h': '6h', '8h': '8h', '12h': '12h', '1d': '1d', '1w': '7d' },
    async klines(sym, iv, end, limit, ivMs) {
      const q = end ? `&from=${sec(end - limit * ivMs)}&to=${sec(end)}` : `&limit=${limit}`;
      const d = await getJSON(`https://api.gateio.ws/api/v4/futures/usdt/candlesticks?contract=${sym}&interval=${iv}${q}`).catch(gateErr);
      return d.map(r => ({ t: +r.t * 1000, o: +r.o, h: +r.h, l: +r.l, c: +r.c, v: +(r.sum ?? r.v) }));
    },
    async tickers() {
      const d = await getJSON('https://api.gateio.ws/api/v4/futures/usdt/tickers');
      return d.filter(x => +x.volume_24h_quote > 0).map(x => ({ s: x.contract, c: +x.last, ch: +x.change_percentage, qv: +x.volume_24h_quote }));
    },
  };
  P.MEXC = {
    name: 'MEXC', kind: 'Спот', max: 1000, split: s => U.splitSym(s),
    iv: { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '60m', '4h': '4h', '1d': '1d', '1w': '1W', '1M': '1M' },
    async klines(sym, iv, end, limit) {
      const d = await getJSON(`https://api.mexc.com/api/v3/klines?symbol=${sym}&interval=${iv}&limit=${limit}${end ? `&endTime=${end}` : ''}`).catch(e => { if (e.status === 400) throw bad(e.message); throw e; });
      return d.map(k => ({ t: +k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5] }));
    },
    async tickers() {
      const d = await getJSON('https://api.mexc.com/api/v3/ticker/24hr');
      return d.filter(x => +x.quoteVolume > 0).map(x => ({ s: x.symbol, c: +x.lastPrice, ch: +x.openPrice ? (x.lastPrice / x.openPrice - 1) * 100 : 0, qv: +x.quoteVolume }));
    },
  };
  const ORDER = ['BINANCE', 'BINANCEF', 'BYBIT', 'BYBITF', 'OKX', 'GATE', 'GATEF', 'MEXC'];

  // ---------- идентификаторы символов ----------
  // "BTCUSDT" — спот Binance (как раньше), остальные: "GATE:INFI_USDT", "BYBITF:BTCUSDT" и т.п.
  function parse(id) {
    const i = id.indexOf(':');
    if (i < 0) return { ex: 'BINANCE', sym: id };
    const ex = id.slice(0, i);
    return { ex: P[ex] ? ex : 'BINANCE', sym: id.slice(i + 1) };
  }
  const makeId = (ex, sym) => ex === 'BINANCE' ? sym : `${ex}:${sym}`;
  function label(id) {
    const { ex, sym } = parse(id), p = P[ex];
    const [base, quote] = p.split(sym);
    return { base: base || sym, quote: quote || '', exName: p.name, kind: p.kind, ex, full: `${p.name} · ${p.kind.toLowerCase()}`, short: `${base || sym}${quote || ''}` };
  }

  // ---------- интервалы и сборка свечей ----------
  function plan(p, iv) {
    if (p.iv[iv]) return { base: iv, k: 1 };
    const ms = U.IV[iv];
    let best = null;
    for (const b of Object.keys(p.iv)) { const bm = U.IV[b]; if (bm < ms && ms % bm === 0 && (!best || bm > U.IV[best])) best = b; }
    if (!best && iv === '1M') best = p.iv['1w'] ? '1d' : null;
    if (!best) best = '1m';
    return { base: best, k: Math.max(1, Math.round(ms / U.IV[best])) };
  }
  function groupKey(t, iv) {
    if (iv === '1M') { const d = new Date(t); return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1); }
    if (iv === '1w') { const off = 3 * 864e5; return Math.floor((t + off) / 6048e5) * 6048e5 - off; }
    const ms = U.IV[iv]; return Math.floor(t / ms) * ms;
  }
  function aggregate(bars, iv) {
    const out = [];
    for (const b of bars) {
      const t = groupKey(b.t, iv), last = out[out.length - 1];
      if (last && last.t === t) { last.h = Math.max(last.h, b.h); last.l = Math.min(last.l, b.l); last.c = b.c; last.v += b.v; }
      else out.push({ t, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v });
    }
    return out;
  }
  async function fetchBars(id, iv, end, limit) {
    const { ex, sym } = parse(id), p = P[ex], pl = plan(p, iv);
    const n = Math.min(p.max, limit * pl.k);
    const raw = await p.klines(sym, p.iv[pl.base], end, n, U.IV[pl.base]);
    const clean = raw.filter(b => isFinite(b.o) && isFinite(b.c)).sort((a, b) => a.t - b.t);
    return pl.k > 1 ? aggregate(clean, iv) : clean;
  }

  async function klinesLive(id, iv, limit = 5) {
    const { ex } = parse(id);
    if (ex === 'BINANCE' && mode === 'demo') return null;
    return fetchBars(id, iv, null, limit);
  }
  async function klines(id, iv, endTime, limit = 1000) {
    const { ex, sym } = parse(id);
    if (ex === 'BINANCE') {
      if (mode !== 'demo') {
        try { const d = await fetchBars(id, iv, endTime, limit); setMode('live'); return d; }
        catch (e) { if (e.bad) throw new Error('Символ не найден на Binance'); setMode('demo'); }
      }
      return Demo.klines(sym, iv, endTime, limit);
    }
    try { return await fetchBars(id, iv, endTime, limit); }
    catch (e) { throw new Error(e.bad ? `не найден на ${P[ex].name} (${P[ex].kind.toLowerCase()})` : `нет связи с ${P[ex].name}: ${e.message}`); }
  }

  // ---------- живые обновления ----------
  const wsHealth = {}; // ключ → время последнего сообщения
  function socket(urlFn, onMsg, onReopen, silentMs = 25000, key) {
    let ws, closed = false, delay = 500, timer, lastMsg = Date.now(), opened = 0, attempt = 0, got = false;
    const open = () => {
      got = false;
      try { ws = new WebSocket(urlFn(attempt)); } catch { attempt++; schedule(); return; }
      ws.onopen = () => { lastMsg = Date.now(); if (opened++ && onReopen) onReopen(); };
      ws.onmessage = ev => { delay = 500; got = true; lastMsg = Date.now(); if (key) wsHealth[key] = lastMsg; try { onMsg(JSON.parse(ev.data)); } catch { /* пропуск */ } };
      ws.onclose = () => { if (closed) return; if (!got) attempt++; schedule(); };
      ws.onerror = () => { try { ws.close(); } catch { /* */ } };
    };
    const schedule = () => { clearTimeout(timer); timer = setTimeout(open, delay); delay = Math.min(delay * 2, 15000); };
    // «сторож»: если соединение молчит — оно зависло (сон ПК, смена сети); пересоздаём
    const dog = setInterval(() => {
      if (closed) return;
      if (Date.now() - lastMsg > silentMs) {
        lastMsg = Date.now(); attempt++;
        try { ws && (ws.onclose = null, ws.close()); } catch { /* */ }
        delay = 1000; schedule();
      }
    }, 5000);
    open();
    return { close() { closed = true; clearTimeout(timer); clearInterval(dog); try { ws && ws.close(); } catch { /* */ } } };
  }
  function poll(fn, ms) {
    let stop = false, t;
    const run = async () => { if (stop) return; try { await fn(); } catch { /* повтор позже */ } if (!stop) t = setTimeout(run, ms); };
    run();
    return { close() { stop = true; clearTimeout(t); } };
  }

  // свечи + КАЖДАЯ сделка в реальном времени (aggTrade) — цена двигается без задержки
  function subscribe(id, iv, cb, onReopen, onTrade) {
    const { ex, sym } = parse(id), p = P[ex];
    if (ex === 'BINANCE' && mode === 'demo') return Demo.subscribe(sym, iv, cb);
    if (p.ws && p.iv[iv]) {
      const s = sym.toLowerCase();
      return socket(a => `${p.wsBases[a % p.wsBases.length]}/stream?streams=${s}@kline_${iv}/${s}@aggTrade`, m => {
        const d = m.data || m;
        if (d.e === 'aggTrade') { if (onTrade) onTrade(+d.p, +d.q, d.T); return; }
        const k = d.k; if (k) cb({ t: k.t, o: +k.o, h: +k.h, l: +k.l, c: +k.c, v: +k.v });
      }, onReopen, 15000, id + '|' + iv);
    }
    const pl = plan(p, iv);
    return poll(async () => {
      const bars = await fetchBars(id, iv, null, 2);
      bars.slice(-2).forEach(b => cb(b));
    }, pl.k > 1 ? 2000 : 1000);
  }

  const tcache = {};
  async function tickersOf(ex, maxAge = 3000) {
    const c = tcache[ex];
    if (c && Date.now() - c.t < maxAge) return c.d;
    if (c && c.p) return c.p;
    const pr = P[ex].tickers().then(d => { tcache[ex] = { t: Date.now(), d }; return d; }).catch(e => { delete tcache[ex].p; throw e; });
    tcache[ex] = { ...(c || { t: 0, d: [] }), p: pr };
    return pr;
  }

  function miniTicker(ids, cb) {
    if (!ids.length) return { close() {} };
    const by = {};
    for (const id of ids) { const { ex, sym } = parse(id); (by[ex] = by[ex] || []).push(sym); }
    const subs = [];
    for (const [ex, syms] of Object.entries(by)) {
      const p = P[ex];
      if (ex === 'BINANCE' && mode === 'demo') { subs.push(Demo.miniTicker(syms, (s, c, ch) => cb(s, c, ch))); continue; }
      if (p.wsTick) {
        subs.push(socket(a => p.wsTick(syms, a), m => { const d = m.data; if (d && d.s) cb(makeId(ex, d.s), +d.c, (+d.c - +d.o) / +d.o * 100); }, null, 30000));
        continue;
      }
      const want = new Set(syms);
      subs.push(poll(async () => {
        const list = await tickersOf(ex, 3500);
        for (const x of list) if (want.has(x.s)) cb(makeId(ex, x.s), x.c, x.ch);
      }, 4000));
    }
    return { close() { subs.forEach(s => s.close()); } };
  }

  // ---------- поиск по всем биржам ----------
  async function searchList(onPart) {
    let all = [];
    await Promise.all(ORDER.map(async ex => {
      let list;
      try { list = await tickersOf(ex, 60000); }
      catch { if (ex === 'BINANCE') list = Demo.tickerList(); else return; }
      const p = P[ex];
      const items = list.map(x => { const [base, quote] = p.split(x.s); return { id: makeId(ex, x.s), ex, sym: x.s, base: base || x.s, quote: quote || '', key: (x.s).replace(/[-_]/g, ''), c: x.c, ch: x.ch, qv: x.qv }; });
      all = all.concat(items);
      onPart && onPart(all);
    }));
    return all;
  }
  async function tickers24h() { return searchList(); }

  // история открытого интереса фьючерсов Binance (USDT-M), в долларах
  const OI_PERIODS = ['5m', '15m', '30m', '1h', '2h', '4h', '6h', '12h', '1d'];
  async function oiHist(base, iv) {
    const ms = U.IV[iv] || 36e5;
    let period = '5m';
    for (const pp of OI_PERIODS) if (U.IV[pp] <= ms) period = pp;
    const sym = (base + 'USDT').toUpperCase();
    try {
      const d = await getJSON(`https://fapi.binance.com/futures/data/openInterestHist?symbol=${sym}&period=${period}&limit=500`);
      return { sym, period, list: d.map(x => ({ t: +x.timestamp, v: +x.sumOpenInterestValue, n: +x.sumOpenInterest })).filter(x => isFinite(x.v)).sort((a, b) => a.t - b.t) };
    } catch (e) {
      if (e.status === 400) throw new Error(`для ${base} нет фьючерса на Binance`);
      throw new Error('не удалось получить открытый интерес: ' + e.message);
    }
  }

  // текущий открытый интерес в $ (контракты × цена)
  async function oiNow(base) {
    const sym = (base + 'USDT').toUpperCase();
    const [o, p] = await Promise.all([getJSON(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${sym}`), getJSON(`https://fapi.binance.com/fapi/v1/ticker/price?symbol=${sym}`)]);
    const v = +o.openInterest * +p.price;
    return isFinite(v) && v > 0 ? v : null;
  }

  return {
    wsAlive: key => Date.now() - (wsHealth[key] || 0) < 5000,
    klines, klinesLive, subscribe, miniTicker, tickers24h, searchList, oiHist, oiNow, parse, label, makeId,
    EXCHANGES: ORDER.map(ex => ({ ex, name: P[ex].name, kind: P[ex].kind })),
    get mode() { return mode; },
    onMode(f) { listeners.push(f); },
    retry() { setMode('unknown'); },
  };
})();
