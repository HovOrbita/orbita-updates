'use strict';
const U = (() => {
  const IV = {
    '1m': 6e4, '3m': 18e4, '5m': 3e5, '15m': 9e5, '30m': 18e5,
    '1h': 36e5, '2h': 72e5, '4h': 144e5, '6h': 216e5, '8h': 288e5, '12h': 432e5,
    '1d': 864e5, '3d': 2592e5, '1w': 6048e5, '1M': 2592e6,
  };
  const IV_NAMES = {
    '1m': '1 минута', '3m': '3 минуты', '5m': '5 минут', '15m': '15 минут', '30m': '30 минут',
    '1h': '1 час', '2h': '2 часа', '4h': '4 часа', '6h': '6 часов', '8h': '8 часов', '12h': '12 часов',
    '1d': '1 день', '3d': '3 дня', '1w': '1 неделя', '1M': '1 месяц',
  };
  const ivShort = iv => ({ '1d': '1D', '3d': '3D', '1w': '1W', '1M': '1M' }[iv] || iv);
  const MON = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const DOW = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
  const FF = "-apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif";
  const pad = n => String(n).padStart(2, '0');

  function decimals(ref) {
    ref = Math.abs(ref);
    if (!isFinite(ref) || ref === 0) return 2;
    if (ref >= 100) return 2;
    if (ref >= 1) return 4;
    return Math.min(10, Math.ceil(-Math.log10(ref)) + 3);
  }
  function fmt(p, ref) {
    if (p == null || !isFinite(p)) return '—';
    return p.toFixed(decimals(ref ?? p));
  }
  function fmtVol(v) {
    if (v == null || !isFinite(v)) return '—';
    const a = Math.abs(v);
    if (a >= 1e9) return (v / 1e9).toFixed(2) + 'B';
    if (a >= 1e6) return (v / 1e6).toFixed(2) + 'M';
    if (a >= 1e3) return (v / 1e3).toFixed(2) + 'K';
    return v.toFixed(a < 10 ? 3 : 0);
  }
  function fmtNum(v, d = 2) {
    if (v == null || !isFinite(v)) return '—';
    return v.toLocaleString('ru-RU', { minimumFractionDigits: d, maximumFractionDigits: d });
  }
  function fmtQty(q) {
    if (!isFinite(q)) return '—';
    const a = Math.abs(q);
    const d = a >= 1000 ? 0 : a >= 1 ? 4 : 6;
    return (+q.toFixed(d)).toString();
  }
  function niceStep(range, count) {
    if (!(range > 0)) return 1;
    const raw = range / Math.max(1, count);
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const n = raw / mag;
    return (n < 1.5 ? 1 : n < 3 ? 2 : n < 7 ? 5 : 10) * mag;
  }
  function fmtTimeFull(t, ivMs) {
    const d = new Date(t);
    let s = `${DOW[d.getDay()]} ${d.getDate()} ${MON[d.getMonth()]} '${String(d.getFullYear()).slice(2)}`;
    if (ivMs < 864e5) s += `  ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    return s;
  }
  function fmtDateTime(t) {
    const d = new Date(t);
    return `${pad(d.getDate())}.${pad(d.getMonth() + 1)} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  function fmtDur(ms) {
    const s = Math.abs(ms) / 1000;
    const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    if (d) return `${d}д ${h}ч`;
    if (h) return `${h}ч ${m}м`;
    return `${m}м`;
  }
  function fmtCountdown(ms) {
    if (ms < 0) ms = 0;
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    if (h >= 24) return `${Math.floor(h / 24)}д ${h % 24}ч`;
    return (h ? h + ':' + pad(m) : pad(m)) + ':' + pad(x);
  }
  function hexA(hex, a) {
    if (!hex) return hex;
    if (hex.startsWith('rgb')) {
      const m = hex.match(/[\d.]+/g);
      return m ? `rgba(${m[0]},${m[1]},${m[2]},${a})` : hex;
    }
    let h = hex.replace('#', '');
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    const n = parseInt(h.slice(0, 6), 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }
  function toHex(c) {
    if (!c) return '#4f8cff';
    if (c.startsWith('#')) return c.length === 4 ? '#' + c.slice(1).split('').map(x => x + x).join('') : c.slice(0, 7);
    const m = c.match(/[\d.]+/g);
    if (!m) return '#4f8cff';
    return '#' + m.slice(0, 3).map(v => (+v).toString(16).padStart(2, '0')).join('');
  }
  function h(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  }
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function debounce(fn, ms) {
    let t;
    return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  }
  function throttle(fn, ms) {
    let last = 0, t = null;
    return (...a) => {
      const now = Date.now();
      if (now - last >= ms) { last = now; fn(...a); }
      else if (!t) t = setTimeout(() => { t = null; last = Date.now(); fn(...a); }, ms - (now - last));
    };
  }
  function icon(name, size = 18) {
    const d = (typeof ICONS !== 'undefined' && ICONS[name]) || '';
    return `<svg class="ic" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
  }
  const Store = {
    KEY: 'orbita.v1',
    // основное хранилище — файл программы; хранилище браузера — запасное
    load() {
      let f = null, l = null;
      try { const j = window.orbita && window.orbita.loadState && window.orbita.loadState(); if (j) f = JSON.parse(j); } catch { /* */ }
      try { l = JSON.parse(localStorage.getItem(this.KEY)); } catch { /* */ }
      if (f && l) return (l.savedAt || 0) > (f.savedAt || 0) ? l : f;
      return f || l;
    },
    save(s) {
      s.savedAt = Date.now();
      const j = JSON.stringify(s);
      let ok = false;
      try { ok = !!(window.orbita && window.orbita.saveState && window.orbita.saveState(j)); } catch { /* */ }
      try { localStorage.setItem(this.KEY, j); ok = true; } catch (e) { console.warn('localStorage save failed', e); }
      if (!ok && !this._warned) { this._warned = true; try { toast('Не удалось сохранить рисунки и настройки', 'error', 4000); } catch { /* */ } }
    },
  };
  const QUOTES = ['USDT', 'USDC', 'FDUSD', 'TUSD', 'BUSD', 'BTC', 'ETH', 'BNB', 'EUR', 'TRY', 'BRL', 'JPY', 'DAI'];
  function splitSym(s) {
    for (const q of QUOTES) if (s.endsWith(q) && s.length > q.length) return [s.slice(0, -q.length), q];
    return [s, ''];
  }

  // ---------- UI helpers ----------
  let openMenus = [];
  function closeMenus() { openMenus.forEach(m => m.remove()); openMenus = []; }
  document.addEventListener('pointerdown', e => {
    if (!openMenus.length) return;
    if (openMenus.some(m => m.contains(e.target))) return;
    closeMenus();
  }, true);
  window.addEventListener('blur', () => closeMenus());

  // items: {label, icon, shortcut, checked, action, danger, disabled, side:{icon, active, action}} | '-' | {header}
  function menu(x, y, items, opts = {}) {
    if (!opts.keep) closeMenus();
    const el = h('<div class="menu"></div>');
    for (const it of items) {
      if (it === '-') { el.appendChild(h('<div class="menu-sep"></div>')); continue; }
      if (it.header) { el.appendChild(h(`<div class="menu-head">${esc(it.header)}</div>`)); continue; }
      const row = h(`<div class="menu-item${it.danger ? ' danger' : ''}${it.disabled ? ' disabled' : ''}${it.active ? ' active' : ''}">
        <span class="mi-ic">${it.checked === true ? icon('chevRight', 0) + '✓' : it.icon ? icon(it.icon, 16) : ''}</span>
        <span class="mi-label">${esc(it.label)}</span>
        ${it.shortcut ? `<span class="mi-sc">${esc(it.shortcut)}</span>` : ''}
        ${it.side ? `<button class="mi-side${it.side.active ? ' on' : ''}">${icon(it.side.icon, 14)}</button>` : ''}
      </div>`);
      if (it.checked === true) row.querySelector('.mi-ic').innerHTML = '✓';
      row.addEventListener('click', e => {
        if (it.disabled) return;
        if (it.side && e.target.closest('.mi-side')) {
          it.side.action();
          if (it.side.keepOpen) { e.target.closest('.mi-side').classList.toggle('on'); return; }
        } else it.action && it.action();
        closeMenus();
      });
      el.appendChild(row);
    }
    document.body.appendChild(el);
    const r = el.getBoundingClientRect();
    const vw = window.innerWidth, vh = window.innerHeight;
    el.style.left = Math.max(4, Math.min(x, vw - r.width - 4)) + 'px';
    el.style.top = Math.max(4, Math.min(y, vh - r.height - 4)) + 'px';
    openMenus.push(el);
    return el;
  }
  function dropdown(anchor, items, opts) {
    const r = anchor.getBoundingClientRect();
    return menu(r.left, r.bottom + 4, items, opts);
  }
  function popover(anchor, contentEl, side = 'right') {
    closeMenus();
    const el = h('<div class="menu popover"></div>');
    el.appendChild(contentEl);
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect();
    const er = el.getBoundingClientRect();
    if (side === 'right') { el.style.left = (r.right + 6) + 'px'; el.style.top = Math.min(r.top, window.innerHeight - er.height - 6) + 'px'; }
    else if (side === 'top') { // телефон: панель инструментов внизу — список открывается вверх
      el.style.left = Math.max(6, Math.min(r.left, window.innerWidth - er.width - 6)) + 'px';
      el.style.top = Math.max(6, r.top - er.height - 6) + 'px';
    }
    else { el.style.left = Math.min(r.left, window.innerWidth - er.width - 6) + 'px'; el.style.top = (r.bottom + 4) + 'px'; }
    openMenus.push(el);
    return el;
  }

  function modal({ title, body, width = 420, onClose }) {
    closeMenus();
    const root = document.getElementById('modal-root');
    const wrap = h(`<div class="modal-wrap"><div class="modal" style="width:${width}px"><div class="modal-head"><span>${esc(title)}</span><button class="ib close" title="Закрыть">${icon('close')}</button></div><div class="modal-body"></div></div></div>`);
    const m = {
      el: wrap,
      body: wrap.querySelector('.modal-body'),
      close() {
        if (m.closed) return;
        m.closed = true;
        wrap.remove();
        document.removeEventListener('keydown', onKey, true);
        onClose && onClose();
      },
    };
    const onKey = e => { if (e.key === 'Escape') { e.stopPropagation(); e.preventDefault(); m.close(); } };
    document.addEventListener('keydown', onKey, true);
    wrap.addEventListener('pointerdown', e => { if (e.target === wrap) m.close(); });
    wrap.querySelector('.close').onclick = () => m.close();
    if (typeof body === 'string') m.body.innerHTML = body;
    else if (body) m.body.appendChild(body);
    root.appendChild(wrap);
    return m;
  }
  function prompt(title, value = '', { multiline = false } = {}) {
    return new Promise(res => {
      let done = false;
      const m = modal({ title, width: 400, onClose: () => { if (!done) res(null); } });
      m.body.innerHTML = `${multiline ? '<textarea class="inp" rows="4"></textarea>' : '<input class="inp">'}
        <div class="modal-actions"><button class="btn ghost">Отмена</button><button class="btn primary">OK</button></div>`;
      const inp = m.body.querySelector('.inp');
      inp.value = value;
      setTimeout(() => { inp.focus(); inp.select(); }, 0);
      const ok = () => { done = true; res(inp.value); m.close(); };
      m.body.querySelector('.primary').onclick = ok;
      m.body.querySelector('.ghost').onclick = () => m.close();
      inp.addEventListener('keydown', e => { if (e.key === 'Enter' && (!multiline || e.ctrlKey || e.metaKey)) { e.preventDefault(); ok(); } });
    });
  }
  function confirm(text, okLabel = 'Да') {
    return new Promise(res => {
      let done = false;
      const m = modal({ title: 'Подтверждение', width: 380, onClose: () => { if (!done) res(false); } });
      m.body.innerHTML = `<p class="confirm-text">${esc(text)}</p><div class="modal-actions"><button class="btn ghost">Отмена</button><button class="btn danger">${esc(okLabel)}</button></div>`;
      m.body.querySelector('.danger').onclick = () => { done = true; res(true); m.close(); };
      m.body.querySelector('.ghost').onclick = () => m.close();
    });
  }
  function toast(msg, kind = 'info', ms = 4000) {
    const root = document.getElementById('toasts');
    const el = h(`<div class="toast ${kind}"><span>${esc(msg)}</span><button class="ib">${icon('close', 14)}</button></div>`);
    el.querySelector('button').onclick = () => el.remove();
    root.appendChild(el);
    while (root.children.length > 5) root.firstChild.remove();
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, ms);
  }
  let actx = null;
  function beep() {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const t = actx.currentTime;
      [880, 1320].forEach((f, i) => {
        const o = actx.createOscillator(), g = actx.createGain();
        o.frequency.value = f; o.type = 'sine';
        g.gain.setValueAtTime(0.0001, t + i * 0.18);
        g.gain.exponentialRampToValueAtTime(0.25, t + i * 0.18 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.18 + 0.16);
        o.connect(g).connect(actx.destination);
        o.start(t + i * 0.18); o.stop(t + i * 0.18 + 0.18);
      });
    } catch { /* без звука */ }
  }

  return {
    IV, IV_NAMES, ivShort, MON, DOW, FF, pad, decimals, fmt, fmtVol, fmtNum, fmtQty, niceStep,
    fmtTimeFull, fmtDateTime, fmtDur, fmtCountdown, hexA, toHex, h, esc, uid, clamp, debounce, throttle,
    icon, Store, splitSym, menu, dropdown, popover, closeMenus, modal, prompt, confirm, toast, beep,
  };
})();
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
