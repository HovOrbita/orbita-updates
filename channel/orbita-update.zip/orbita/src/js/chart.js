'use strict';
const DPR = () => window.devicePixelRatio || 1;

function heikin(b) {
  const out = new Array(b.length);
  for (let i = 0; i < b.length; i++) {
    const x = b[i], c = (x.o + x.h + x.l + x.c) / 4;
    const o = i ? (out[i - 1].o + out[i - 1].c) / 2 : (x.o + x.c) / 2;
    out[i] = { t: x.t, o, c, h: Math.max(x.h, o, c), l: Math.min(x.l, o, c), v: x.v };
  }
  return out;
}

class Chart {
  constructor(app, cell, cfg, index) {
    this.app = app; this.cell = cell; this.cfg = cfg; this.index = index;
    cell.innerHTML = '<canvas></canvas><div class="legends"></div><div class="chart-msg"></div><button class="cell-max" title="Развернуть / вернуть (или двойной клик по графику)"></button>';
    cell.querySelector('.cell-max').onclick = () => this.app.toggleMax(this);
    this.cv = cell.querySelector('canvas'); this.ctx = this.cv.getContext('2d');
    this.legendsEl = cell.querySelector('.legends'); this.msgEl = cell.querySelector('.chart-msg');
    this.bars = []; this.series = []; this.res = new Map(); this.panes = []; this.main = { kind: 'main', top: 0, h: 100 };
    this.spacing = 8; this.rightIndex = 0; this.priceAuto = true; this.pMin = 0; this.pMax = 1;
    this.AXW = 64; this.AXH = 26; this.W = 0; this.H = 0; this.tok = 0;
    this.mouse = null; this.drag = null; this.creating = null; this.selected = null; this.hover = null;
    this.geo = new Map(); this.plines = []; this.vis = [0, 0];
    this.layoutDirty = true; this.legendDirty = true; this.extCross = null; this.lgKey = '';
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(cell);
    this.bind();
    this.load();
  }
  get sym() { return this.cfg.symbol; }
  get iv() { return this.cfg.interval; }
  get ivMs() { return U.IV[this.cfg.interval] || 36e5; }
  get drawings() { return this.app.getDrawings(this.cfg.symbol); }
  get plotW() { return this.W - this.AXW; }
  get plotH() { return this.H - this.AXH; }
  get ref() { const b = this.bars; return b.length ? b[b.length - 1].c : 1; }

  destroy() { this.dead = true; this.sub && this.sub.close(); this.ro.disconnect(); }
  msg(t) { this.msgEl.textContent = t; this.msgEl.style.display = t ? 'flex' : 'none'; }
  resize() {
    const r = this.cell.getBoundingClientRect();
    this.W = Math.floor(r.width); this.H = Math.floor(r.height);
    const d = DPR();
    this.cv.width = Math.max(1, this.W * d); this.cv.height = Math.max(1, this.H * d);
    this.cv.style.width = this.W + 'px'; this.cv.style.height = this.H + 'px';
    this.layoutDirty = true;
    this.render();
  }
  invalidate() {
    if (this.raf || this.dead) return;
    this.raf = requestAnimationFrame(() => { this.raf = 0; this.render(); });
  }

  // ---------- данные ----------
  async load() {
    const tok = ++this.tok;
    if (this.replay) this.app.replayStop(this, true);
    this.sub && this.sub.close(); this.sub = null;
    this.bars = []; this.series = []; this.res.clear(); this.selected = null; this.creating = null; this.hover = null;
    this.legendDirty = true;
    this.msg('Загрузка ' + Data.label(this.sym).short + '…');
    this.invalidate();
    let bars;
    try { bars = await Data.klines(this.sym, this.iv); }
    catch (e) { if (tok === this.tok) this.msg(`${Data.label(this.sym).short}: ${e.message || e}`); return; }
    if (tok !== this.tok || this.dead) return;
    if (!bars.length) { this.msg('Нет данных'); return; }
    this.msg('');
    this.bars = bars; this.noMore = false; this.lastData = Date.now();
    this.resetView(); this.recalc();
    this.layoutDirty = true; this.legendDirty = true;
    this.sub = Data.subscribe(this.sym, this.iv, k => { if (tok === this.tok) this.onKline(k); }, () => { if (tok === this.tok) this.resync(); }, (pr, q, T) => { if (tok === this.tok) this.onTrade(pr, q, T); });
    this.liqOI = null; this.liqModel = null;
    if (this.cfg.liq) this.liqLoad();
    this.oiData = null; this.oiState = ''; this.oiLoad();
    if (typeof Funding !== 'undefined') Funding.refresh(this);
    this.app.onChartLoaded(this);
    this.invalidate();
  }
  // ---------- повтор истории ----------
  replayStart(idx) {
    const full = this.replay ? this.replay.full : this.bars;
    idx = U.clamp(Math.round(idx), 20, full.length - 2);
    this.replay = { full, idx };
    this.bars = full.slice(0, idx + 1);
    this.recalc();
    this.rightIndex = this.bars.length - 1 + Math.max(5, (this.plotW / this.spacing) * 0.25);
    this.priceAuto = true;
    this.invalidate();
  }
  replayStep(n = 1) {
    const r = this.replay; if (!r) return false;
    let moved = false;
    for (let k = 0; k < n && r.idx < r.full.length - 1; k++) { r.idx++; this.bars.push(r.full[r.idx]); moved = true; }
    if (!moved) return false;
    const atEnd = this.rightIndex >= this.bars.length - 1 - n;
    this.recalc();
    if (atEnd || this.idxToX(this.bars.length - 1) > this.plotW - 20) this.rightIndex = this.clampRI(this.rightIndex + n);
    this.invalidate();
    return r.idx < r.full.length - 1;
  }
  replayEnd() {
    const r = this.replay; if (!r) return;
    this.bars = r.full; this.replay = null;
    this.recalc(); this.scrollToEnd();
  }

  // ---------- карта ликвидаций (собственная модель по открытому интересу) ----------
  // ---------- открытый интерес: карточка с процентами и расшифровкой ----------
  // карточки справа сверху (ОИ, фандинг) — одна колонка, не налезают друг на друга
  cardsBox() { let b = this.cell.querySelector('.side-cards'); if (!b) { b = U.h('<div class="side-cards"></div>'); this.cell.appendChild(b); } return b; }
  hasOI() { return !!this.cfg.oiCard; }
  async oiLoad(quiet) {
    if (!this.cfg.oiCard || this.replay) { this.oiRender(); return; }
    const tok = this.tok, base = Data.label(this.sym).base;
    if (!this.oiData) { this.oiState = 'load'; this.oiRender(); }
    try {
      const r = await Data.oiHist(base, '5m'); // 5-минутная история ≈ 41 час
      let now = null; try { now = await Data.oiNow(base); } catch { /* только история */ }
      if (tok !== this.tok) return;
      this.oiData = { ...r, now }; this.oiState = '';
    } catch (e) {
      if (tok !== this.tok) return;
      this.oiData = null; this.oiState = e.message;
    }
    this.oiRender();
    if (this.cfg.frCard && typeof Funding !== 'undefined') Funding.render(this); // подсказки фандинга учитывают ОИ
  }
  async oiTick() {
    if (!this.cfg.oiCard || !this.oiData || this.replay) return;
    const tok = this.tok;
    try { const v = await Data.oiNow(Data.label(this.sym).base); if (tok === this.tok && v) { this.oiData.now = v; this.oiRender(); } } catch { /* */ }
  }
  oiStats() {
    const d = this.oiData; if (!d || d.list.length < 2) return null;
    const L = d.list, last = L[L.length - 1], cur = d.now || last.v;
    const price = p => p.n > 0 ? p.v / p.n : NaN, pNow = this.bars.length ? this.bars[this.bars.length - 1].c : price(last);
    const at = ms => { const t = last.t - ms; let best = null; for (const p of L) { if (p.t <= t) best = p; else break; } return best; };
    const win = {};
    for (const [k, ms] of [['1ч', 36e5], ['4ч', 144e5], ['24ч', 864e5]]) {
      const p = at(ms); if (!p) continue;
      win[k] = { oi: (cur / p.v - 1) * 100, pr: (pNow / price(p) - 1) * 100 };
    }
    return { cur, win };
  }
  oiRead(w) { // что значит связка цены и ОИ
    if (!w) return null;
    const oT = 0.5, pT = 0.3, o = w.oi, p = w.pr;
    if (Math.abs(o) < oT) return { t: 'ОИ почти не меняется — новых денег нет', k: 'n' };
    if (Math.abs(p) < pT) return o > 0 ? { t: 'ОИ растёт во флэте — копятся позиции, возможен сильный выход', k: 'w' } : { t: 'ОИ падает во флэте — позиции закрывают', k: 'n' };
    if (p > 0 && o > 0) return { t: 'Новые лонги — рост подкреплён деньгами', k: 'g' };
    if (p > 0 && o < 0) return { t: 'Закрываются шорты — рост без новых денег', k: 'w' };
    if (p < 0 && o > 0) return { t: 'Новые шорты — давят продавцы', k: 'r' };
    return { t: 'Выходят лонги / ликвидации — падение без новых денег', k: 'w' };
  }
  oiRender() {
    let el = this.cell.querySelector('.oi-card:not(.fr-card)');
    if (!this.cfg.oiCard) { if (el) el.remove(); return; }
    if (!el) { el = U.h('<div class="oi-card"></div>'); el.onclick = () => this.oiLoad(); }
    const box = this.cardsBox(); if (el.parentNode !== box) box.insertBefore(el, box.firstChild);
    const base = Data.label(this.sym).base;
    if (this.oiState === 'load' && !this.oiData) { el.innerHTML = `<div class="oi-h"><b>ОИ</b> ${U.esc(base)}</div><div class="oi-note">загрузка…</div>`; return; }
    if (!this.oiData) { el.innerHTML = `<div class="oi-h"><b>ОИ</b> ${U.esc(base)}</div><div class="oi-note">${U.esc(this.oiState || 'нет данных')}</div>`; return; }
    const st = this.oiStats(); if (!st) { el.innerHTML = `<div class="oi-h"><b>ОИ</b> ${U.esc(base)}</div><div class="oi-note">мало данных</div>`; return; }
    const f = v => v == null || v !== v ? '—' : `${v > 0 ? '+' : ''}${v.toFixed(Math.abs(v) < 10 ? 2 : 1)}%`;
    const cls = v => v > 0.05 ? 'up' : v < -0.05 ? 'dn' : '';
    const key = this.ivMs <= 9e5 ? '1ч' : this.ivMs <= 36e5 ? '4ч' : '24ч';
    const rd = this.oiRead(st.win[key]);
    const rows = ['1ч', '4ч', '24ч'].map(k => { const w = st.win[k]; return `<div class="oi-c${k === key ? ' main' : ''}"><span class="oi-k">${k}</span><span class="oi-v ${w ? cls(w.oi) : ''}">${w ? f(w.oi) : '—'}</span><span class="oi-p ${w ? cls(w.pr) : ''}">цена ${w ? f(w.pr) : '—'}</span></div>`; }).join('');
    el.innerHTML = `<div class="oi-h"><b>ОИ</b> ${U.esc(base)} <span class="oi-sum">$${U.fmtVol(st.cur)}</span></div><div class="oi-grid">${rows}</div>` +
      (rd ? `<div class="oi-read ${rd.k}">${rd.t} <span class="oi-dim">(за ${key})</span></div>` : '');
    el.title = 'Открытый интерес Binance USDT-фьючерсов. Клик — обновить';
  }
  async liqLoad() {
    if (!this.cfg.liq || !this.bars.length) return;
    const tok = this.tok;
    this.liqStatus = 'Загрузка открытого интереса…'; this.legendDirty = true; this.invalidate();
    try {
      const r = await Data.oiHist(Data.label(this.sym).base, this.iv);
      if (tok !== this.tok) return;
      this.liqOI = r; this.liqStatus = r.list.length ? '' : 'нет данных открытого интереса';
      this._liqN = this.bars.length; this.liqCompute();
    } catch (e) {
      if (tok !== this.tok) return;
      this.liqOI = null; this.liqModel = null; this.liqStatus = e.message;
    }
    this.legendDirty = true; this.invalidate();
  }
  liqCompute() {
    const b = this.bars, n = b.length, oi = this.liqOI; if (!n || !oi || oi.list.length < 2) { this.liqModel = null; return; }
    const st = this.cfg.liqSet || (this.cfg.liqSet = { tiers: { 10: 30, 25: 30, 50: 25, 100: 15 }, thr: 12, profile: true });
    // изменение открытого интереса → к свече, в которой оно произошло
    const dOI = new Float64Array(n);
    for (let k = 1; k < oi.list.length; k++) {
      const i = Math.floor(this.timeToIdx(oi.list[k].t - 1));
      if (i >= 0 && i < n) dOI[i] += oi.list[k].v - oi.list[k - 1].v;
    }
    const first = Math.max(0, Math.floor(this.timeToIdx(oi.list[0].t)));
    const tiers = Object.entries(st.tiers).map(([lev, w]) => [+lev, +w / 100]).filter(x => x[1] > 0);
    const tw = tiers.reduce((a, x) => a + x[1], 0) || 1;
    const bs = b[n - 1].c * 0.0012; // шаг цены уровня ≈ 0,12%
    const levels = [];
    let active = [];
    for (let i = first; i < n; i++) {
      const x = b[i];
      if (active.length) {
        const keep = [];
        for (const lv of active) {
          if ((lv.side === 'L' && x.l <= lv.p) || (lv.side === 'S' && x.h >= lv.p)) lv.e = i; else keep.push(lv);
        }
        active = keep;
      }
      const d = dOI[i];
      if (d > 0) {
        const rng = Math.max(x.h - x.l, 1e-12), lf = U.clamp(0.5 + 0.35 * (x.c - x.o) / rng, 0.15, 0.85), entry = (x.h + x.l + x.c) / 3;
        for (const [lev, w] of tiers) {
          const m = 0.96 / lev, part = d * w / tw;
          const L = { p: Math.round(entry * (1 - m) / bs) * bs, usd: part * lf, side: 'L', s: i, e: null };
          const S = { p: Math.round(entry * (1 + m) / bs) * bs, usd: part * (1 - lf), side: 'S', s: i, e: null };
          levels.push(L, S); active.push(L, S);
        }
      } else if (d < 0 && active.length) {
        const tot = active.reduce((a, lv) => a + lv.usd, 0);
        const f = tot > 0 ? Math.max(0, 1 + d / tot * 0.7) : 1;
        if (f < 0.9) {
          active = active.map(lv => { lv.e = i; const nl = { ...lv, usd: lv.usd * f, s: i, e: null }; levels.push(nl); return nl; });
        } else active.forEach(lv => { lv.usd *= f; });
      }
    }
    const sorted = levels.map(l => l.usd).sort((a, c) => a - c);
    const maxUsd = sorted[Math.floor(sorted.length * 0.985)] || 1;
    this.liqModel = { levels, active, maxUsd, bs };
  }
  drawLiq(ctx, L, R) {
    const m = this.liqModel; if (!m) return;
    const st = this.cfg.liqSet, thr = (st.thr || 0) / 100, pane = this.main, n = this.bars.length;
    const dark = this.app.th.chartBg && parseInt(U.toHex(this.app.th.chartBg).slice(1, 3), 16) < 110;
    const PALS = {
      aurora: dark ? [[0, [46, 110, 255]], [0.35, [0, 200, 210]], [0.65, [120, 240, 120]], [0.85, [255, 225, 60]], [1, [255, 255, 235]]]
                   : [[0, [60, 90, 200]], [0.35, [0, 140, 160]], [0.65, [40, 160, 70]], [0.85, [220, 150, 0]], [1, [200, 40, 30]]],
      fire: dark ? [[0, [150, 40, 255]], [0.35, [255, 60, 120]], [0.65, [255, 140, 40]], [0.85, [255, 220, 60]], [1, [255, 255, 230]]]
                 : [[0, [120, 60, 200]], [0.35, [210, 40, 90]], [0.65, [230, 110, 0]], [1, [160, 30, 0]]],
      ice: dark ? [[0, [60, 120, 255]], [0.5, [80, 200, 255]], [0.8, [190, 240, 255]], [1, [255, 255, 255]]]
                : [[0, [90, 140, 230]], [0.5, [30, 100, 200]], [1, [10, 40, 120]]],
    };
    const pal = t => {
      const S = PALS[st.pal] || PALS.aurora;
      let k = 1; while (k < S.length - 1 && S[k][0] < t) k++;
      const [t0, c0] = S[k - 1], [t1, c1] = S[k], f = (t - t0) / ((t1 - t0) || 1);
      return c0.map((v, j) => Math.round(v + (c1[j] - v) * f));
    };
    const binPx = Math.max(st.thick || 3, Math.abs(this.priceToY(m.levels.length ? m.levels[0].p : 1) - this.priceToY((m.levels.length ? m.levels[0].p : 1) + m.bs)));
    ctx.save();
    ctx.globalCompositeOperation = dark ? 'screen' : 'multiply';
    const xEnd = this.plotW;
    for (const lv of m.levels) {
      const t = Math.min(1, lv.usd / m.maxUsd); if (t < thr) continue;
      const e = lv.e == null ? null : lv.e;
      if (lv.s > R || (e != null && e < L)) continue;
      const x0 = this.idxToX(lv.s), x1 = e == null ? xEnd : this.idxToX(e);
      const y = this.priceToY(lv.p);
      if (y < pane.top - 4 || y > pane.top + pane.h + 4) continue;
      const c = pal(t);
      const al = 0.28 + 0.67 * Math.pow(t, 1.1);
      ctx.fillStyle = `rgba(${c[0]},${c[1]},${c[2]},${dark ? al : Math.min(1, al * 1.2)})`;
      ctx.fillRect(x0, Math.round(y - binPx / 2), Math.max(1, x1 - x0), binPx);
      if (t > 0.6 && dark) { ctx.fillStyle = `rgba(${c[0]},${c[1]},${c[2]},${0.12 * t})`; ctx.fillRect(x0, Math.round(y - binPx * 1.5), Math.max(1, x1 - x0), binPx * 3); }
    }
    ctx.restore();
    // профиль справа: сколько ликвидаций ждёт на каждом уровне сейчас
    if (st.profile !== false && m.active.length) {
      const agg = new Map();
      for (const lv of m.active) agg.set(lv.p, (agg.get(lv.p) || 0) + lv.usd);
      let mx = 0; agg.forEach(v => { if (v > mx) mx = v; });
      const W = Math.min(110, this.plotW * 0.12), last = this.bars[n - 1].c;
      let topL = null, topS = null;
      agg.forEach((v, p) => {
        const y = this.priceToY(p); if (y < pane.top || y > pane.top + pane.h) return;
        const t = v / mx, c = pal(Math.max(0.2, t)), w = Math.max(2, t * W);
        ctx.fillStyle = `rgba(${c[0]},${c[1]},${c[2]},0.95)`;
        ctx.fillRect(this.plotW - w, y - binPx / 2, w, binPx);
        if (p < last && (!topL || v > topL.v)) topL = { p, v, y };
        if (p > last && (!topS || v > topS.v)) topS = { p, v, y };
      });
      ctx.font = `600 10.5px ${U.FF}`; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
      for (const [o, lab] of [[topS, 'Шорты'], [topL, 'Лонги']]) {
        if (!o) continue;
        const txt = `${lab} ${U.fmt(o.p, this.ref)} · $${U.fmtVol(o.v)}`, tw = ctx.measureText(txt).width + 10;
        ctx.fillStyle = dark ? 'rgba(10,12,20,.85)' : 'rgba(255,255,255,.9)'; ctx.beginPath(); ctx.roundRect(this.plotW - W - tw - 6, o.y - 9, tw, 18, 4); ctx.fill();
        ctx.fillStyle = dark ? '#ffe95c' : '#7a4b00'; ctx.fillText(txt, this.plotW - W - 11, o.y);
      }
    }
  }

  resetView() {
    this.spacing = 8;
    this.rightIndex = this.bars.length - 1 + 5;
    this.priceAuto = true;
  }
  recalc() {
    const b = this.bars;
    this.series = this.cfg.type === 'heikin' ? heikin(b) : b;
    this.res.clear();
    for (const inst of this.cfg.indicators) {
      try { this.res.set(inst.id, IND.calc(inst, b, this)); } catch (e) { console.error(e); this.res.set(inst.id, {}); }
    }
    if (this.cfg.liq && this.liqOI && this._liqN !== b.length) { this._liqN = b.length; this.liqCompute(); }
  }
  onKline(k) {
    if (this.replay) {
      const f = this.replay.full, l = f[f.length - 1];
      if (l && k.t === l.t) Object.assign(l, k); else if (l && k.t > l.t) f.push(k);
      this.app.onPrice(this.sym, k.c); Panels.updateWatchRow(this.sym, k.c);
      return;
    }
    const b = this.bars; if (!b.length) return;
    this.lastData = Date.now();
    const last = b[b.length - 1];
    if (k.t === last.t) Object.assign(last, k);
    else if (k.t > last.t) {
      const atEnd = this.rightIndex >= b.length - 2;
      b.push(k);
      if (atEnd) this.rightIndex += 1;
    } else return;
    this.recalcSoon();
    this.invalidate();
    this.app.onPrice(this.sym, k.c);
    Panels.updateWatchRow(this.sym, k.c);
  }
  // каждая сделка: сразу двигаем последнюю свечу и перерисовываем (не чаще кадра экрана)
  onTrade(p, q, T) {
    if (this.replay || !this.bars.length || !(p > 0)) return;
    const b = this.bars, last = b[b.length - 1], ms = this.ivMs;
    this.lastData = Date.now();
    if (T >= last.t + ms && ms < 2592e6) {
      const atEnd = this.rightIndex >= b.length - 2;
      b.push({ t: last.t + Math.floor((T - last.t) / ms) * ms, o: p, h: p, l: p, c: p, v: q });
      if (atEnd) this.rightIndex += 1;
    } else {
      last.c = p; if (p > last.h) last.h = p; if (p < last.l) last.l = p; last.v += q;
    }
    if (this.cfg.type === 'heikin') this.recalcSoon(); else this.series = b;
    this.recalcSoon();
    this.invalidate();
    this.app.onPrice(this.sym, p);
    const now = Date.now();
    if (now - (this._wlAt || 0) > 250) { this._wlAt = now; Panels.updateWatchRow(this.sym, p); }
  }
  recalcSoon() {
    if (this._rc) return;
    this._rc = setTimeout(() => { this._rc = 0; if (this.dead) return; this.recalc(); this.invalidate(); }, 300);
  }
  // докачать пропущенные свечи (после сна компьютера, обрыва связи, возврата в окно)
  async resync(n = 300) {
    if (this.resyncing || !this.bars.length || this.replay) return;
    this.resyncing = true;
    const tok = this.tok;
    try {
      const fresh = await Data.klinesLive(this.sym, this.iv, n);
      if (!fresh) return;
      this.lastData = Date.now(); this.lastFetch = Date.now();
      if (tok !== this.tok || !fresh.length) return;
      const b = this.bars, atEnd = this.rightIndex >= b.length - 3;
      const firstT = fresh[0].t;
      let i = b.length - 1; while (i >= 0 && b[i].t >= firstT) i--;
      const added = (i + 1 + fresh.length) - b.length;
      this.bars = b.slice(0, i + 1).concat(fresh);
      if (atEnd && added > 0) this.rightIndex += added;
      this._liqN = -1;
      this.recalc(); this.invalidate();
      const last = this.bars[this.bars.length - 1];
      this.app.onPrice(this.sym, last.c); Panels.updateWatchRow(this.sym, last.c);
    } catch { /* попробуем позже */ } finally { this.resyncing = false; }
  }
  async loadMore() {
    if (this.loading || this.noMore || !this.bars.length) return;
    this.loading = true;
    const tok = this.tok, first = this.bars[0].t;
    try {
      const older = (await Data.klines(this.sym, this.iv, first - 1)).filter(x => x.t < first);
      if (tok !== this.tok) return;
      if (!older.length) this.noMore = true;
      else {
        this.bars = older.concat(this.bars);
        if (this.replay) { this.replay.full = older.concat(this.replay.full); this.replay.idx += older.length; }
        this.rightIndex += older.length;
        this.recalc();
        this.invalidate();
      }
    } catch { this.noMore = true; }
    finally { this.loading = false; }
  }
  maybeLoadMore() { if (this.bars.length && this.xToIdx(0) < 50) this.loadMore(); }

  // ---------- координаты ----------
  idxToX(i) { return this.plotW - (this.rightIndex - i) * this.spacing; }
  xToIdx(x) { return this.rightIndex - (this.plotW - x) / this.spacing; }
  timeToIdx(t) {
    const b = this.bars, n = b.length; if (!n) return 0;
    const ms = this.ivMs;
    if (t >= b[n - 1].t) return n - 1 + (t - b[n - 1].t) / ms;
    if (t <= b[0].t) return (t - b[0].t) / ms;
    let lo = 0, hi = n - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (b[m].t <= t) lo = m; else hi = m; }
    return lo + (t - b[lo].t) / (b[hi].t - b[lo].t);
  }
  idxToTime(i) {
    const b = this.bars, n = b.length; if (!n) return 0;
    const ms = this.ivMs;
    if (i >= n - 1) return b[n - 1].t + (i - n + 1) * ms;
    if (i <= 0) return b[0].t + i * ms;
    const lo = Math.floor(i), f = i - lo;
    return b[lo].t + f * (b[lo + 1].t - b[lo].t);
  }
  timeToX(t) { return this.idxToX(this.timeToIdx(t)); }
  pf(p) { return this.cfg.log ? Math.log(Math.max(p, 1e-12)) : p; }
  pinv(v) { return this.cfg.log ? Math.exp(v) : v; }
  priceToY(p, pane = this.main) {
    if (pane.kind === 'main') {
      const a = this.pf(this.pMin), z = this.pf(this.pMax);
      return pane.top + (1 - (this.pf(p) - a) / ((z - a) || 1)) * pane.h;
    }
    return pane.top + (1 - (p - pane.min) / ((pane.max - pane.min) || 1)) * pane.h;
  }
  yToPrice(y, pane = this.main) {
    const f = 1 - (y - pane.top) / pane.h;
    if (pane.kind === 'main') { const a = this.pf(this.pMin), z = this.pf(this.pMax); return this.pinv(a + f * (z - a)); }
    return pane.min + f * (pane.max - pane.min);
  }
  clampRI(v) {
    const n = this.bars.length, vis = this.plotW / this.spacing;
    return U.clamp(v, Math.min(n - 1, 5), n - 1 + vis * 0.85);
  }
  zoom(f, x = this.plotW) {
    // плавный зум: копим цель и анимируем к ней, точка под курсором остаётся на месте
    const a = this.zAnim;
    const target = U.clamp((a ? a.target : this.spacing) * f, 0.5, 80);
    this.stopInertia();
    this.zAnim = { target, x, idx: a && Math.abs(a.x - x) < 2 ? a.idx : this.xToIdx(x) };
    this.runAnim();
  }
  runAnim() {
    if (this.animRaf) return;
    let last = performance.now();
    const step = now => {
      this.animRaf = 0;
      if (this.dead) return;
      const dt = Math.min(48, now - last); last = now;
      let more = false;
      const z = this.zAnim;
      if (z) {
        const k = 1 - Math.pow(0.001, dt / 300);
        this.spacing += (z.target - this.spacing) * k;
        if (Math.abs(z.target - this.spacing) < 0.002 * z.target) { this.spacing = z.target; this.zAnim = null; } else more = true;
        this.rightIndex = this.clampRI(z.idx + (this.plotW - z.x) / this.spacing);
      }
      const v = this.inertia;
      if (v) {
        this.rightIndex = this.clampRI(this.rightIndex - v.vx * dt / this.spacing);
        v.vx *= Math.pow(0.88, dt / 16);
        if (Math.abs(v.vx) < 0.02) this.inertia = null; else more = true;
      }
      this.maybeLoadMore();
      this.render();
      if (more) this.animRaf = requestAnimationFrame(step);
    };
    this.animRaf = requestAnimationFrame(step);
  }
  stopInertia() { this.inertia = null; }
  scrollToEnd() { this.rightIndex = this.bars.length - 1 + 5; this.invalidate(); }

  // ---------- раскладка ----------
  computeLayout() {
    const plotH = this.plotH;
    const inds = this.cfg.indicators.filter(i => IND.defs[i.type] && !IND.defs[i.type].overlay);
    const mw = this.cfg.mainWeight || 3;
    let tot = mw; inds.forEach(i => tot += (i.weight || 1));
    const panes = [];
    const mh = Math.round(plotH * mw / tot);
    panes.push({ kind: 'main', top: 0, h: mh });
    let y = mh;
    inds.forEach((ind, k) => {
      const h = k === inds.length - 1 ? plotH - y : Math.round(plotH * (ind.weight || 1) / tot);
      panes.push({ kind: 'ind', ind, top: y, h, min: 0, max: 1 });
      y += h;
    });
    this.panes = panes; this.main = panes[0];
    this.layoutDirty = false; this.legendDirty = true;
  }
  paneAt(y) { return this.panes.find(p => y >= p.top && y < p.top + p.h) || null; }
  region(x, y) {
    if (y >= this.plotH) return { r: 'time' };
    const pane = this.paneAt(y);
    if (x >= this.plotW) return { r: 'price', pane };
    for (let k = 0; k < this.panes.length - 1; k++) {
      const sy = this.panes[k].top + this.panes[k].h;
      if (Math.abs(y - sy) <= 3) return { r: 'sep', k };
    }
    return { r: 'plot', pane };
  }

  overlays() { return this.cfg.indicators.filter(i => i.visible !== false && IND.defs[i.type] && IND.defs[i.type].overlay); }

  computeScales() {
    const n = this.series.length; if (!n) return;
    const L = Math.max(0, Math.floor(this.xToIdx(0))), R = Math.min(n - 1, Math.ceil(this.xToIdx(this.plotW)));
    this.vis = [L, R];
    let hasVol = false;
    if (this.priceAuto && R >= L) {
      let lo = Infinity, hi = -Infinity;
      const lineOnly = this.cfg.type === 'line' || this.cfg.type === 'area';
      for (let i = L; i <= R; i++) {
        const s = this.series[i];
        if (lineOnly) { if (s.c < lo) lo = s.c; if (s.c > hi) hi = s.c; }
        else { if (s.l < lo) lo = s.l; if (s.h > hi) hi = s.h; }
      }
      for (const inst of this.overlays()) {
        const d = IND.defs[inst.type];
        if (d.vol) { hasVol = true; continue; }
        const res = this.res.get(inst.id); if (!res) continue;
        for (const o of d.o) {
          const arr = res[o.k]; if (!arr) continue;
          const off = o.off ? o.off({ ...inst.params }) : 0;
          for (let i = L; i <= R; i++) { const v = arr[i - off]; if (v === v && v !== undefined) { if (v < lo) lo = v; if (v > hi) hi = v; } }
        }
      }
      if (isFinite(lo) && isFinite(hi)) {
        if (lo === hi) { lo *= 0.99; hi *= 1.01; }
        const bp = hasVol ? 0.2 : 0.08;
        if (this.cfg.log && lo > 0) {
          const a = Math.log(lo), z = Math.log(hi), r = z - a;
          this.pMin = Math.exp(a - r * bp); this.pMax = Math.exp(z + r * 0.08);
        } else {
          const r = hi - lo;
          this.pMin = lo - r * bp; this.pMax = hi + r * 0.08;
        }
      }
    }
    for (const pane of this.panes) {
      if (pane.kind !== 'ind') continue;
      const inst = pane.ind, d = IND.defs[inst.type], res = this.res.get(inst.id) || {};
      // шкала, растянутая или сдвинутая вручную (как у цены); двойной клик по шкале — снова авто
      if (inst.scale && isFinite(inst.scale.min) && isFinite(inst.scale.max) && inst.scale.max > inst.scale.min) { pane.min = inst.scale.min; pane.max = inst.scale.max; continue; }
      let lo = Infinity, hi = -Infinity;
      for (const o of d.o) {
        const arr = res[o.k]; if (!arr) continue;
        const off = o.off ? o.off(inst.params) : 0;
        for (let i = L; i <= R; i++) { const v = arr[i - off]; if (v === v && v !== undefined) { if (v < lo) lo = v; if (v > hi) hi = v; } }
        if (o.t === 'hist') { lo = Math.min(lo, 0); hi = Math.max(hi, 0); }
      }
      for (const lv of d.levels) { lo = Math.min(lo, lv); hi = Math.max(hi, lv); }
      if (d.range) { pane.min = d.range[0] - (d.range[1] - d.range[0]) * 0.04; pane.max = d.range[1] + (d.range[1] - d.range[0]) * 0.04; continue; }
      if (!isFinite(lo)) { lo = 0; hi = 1; }
      if (lo === hi) { lo -= 1; hi += 1; }
      const r = hi - lo;
      pane.min = lo - r * 0.1; pane.max = hi + r * 0.1;
    }
  }

  // «круглый» шаг цены: 5×10^(порядок−1) — 90 000 / 95 000, 3 000 / 3 500, 100 / 150 …
  roundStep() { const r = Math.abs(this.ref) || 1; return 5 * Math.pow(10, Math.floor(Math.log10(r)) - 1); }
  isRound(v) { const rs = this.roundStep(); return Math.abs(v / rs - Math.round(v / rs)) < 1e-6; }

  priceTicks(pane) {
    const min = pane.kind === 'main' ? this.pMin : pane.min, max = pane.kind === 'main' ? this.pMax : pane.max;
    const count = Math.max(2, Math.floor(pane.h / 48));
    const out = [];
    if (pane.kind === 'main' && this.cfg.log && min > 0) {
      for (let k = 0; k <= count; k++) {
        const v0 = Math.exp(Math.log(min) + (Math.log(max) - Math.log(min)) * (k + 0.5) / (count + 1));
        const st = U.niceStep(v0 * 0.2, 2), v = Math.round(v0 / st) * st;
        out.push({ v, y: this.priceToY(v, pane), label: U.fmt(v, this.ref) });
      }
      return out;
    }
    const step = U.niceStep(max - min, count);
    for (let v = Math.ceil(min / step) * step, k = 0; v <= max && k < 60; v += step, k++) {
      const y = this.priceToY(v, pane);
      out.push({ v, y, label: pane.kind === 'main' ? U.fmt(v, this.ref) : IND.fmtVal(IND.defs[pane.ind.type], Math.abs(v) < step / 1e6 ? 0 : v) });
    }
    return out;
  }

  timeTicks(L, R) {
    const ms = this.ivMs, sp = this.spacing, b = this.bars, n = b.length;
    const cands = [6e4, 3e5, 9e5, 18e5, 36e5, 72e5, 144e5, 216e5, 432e5, 864e5, 1728e5, 6048e5, -1, -3, -6, -12];
    let cand = -12;
    for (const c of cands) {
      const cm = c > 0 ? c : -c * 2592e6;
      if (cm >= ms && (cm / ms) * sp >= 90) { cand = c; break; }
    }
    const tz = new Date().getTimezoneOffset() * 6e4;
    const key = t => {
      if (cand < 0) { const d = new Date(t); return Math.floor((d.getFullYear() * 12 + d.getMonth()) / -cand); }
      return Math.floor((t - tz) / cand);
    };
    const out = [];
    let prev;
    for (let i = Math.max(0, L); i <= Math.min(n - 1, R); i++) {
      const t = b[i].t, k = key(t);
      if (prev !== undefined && k !== prev) {
        const d = new Date(t);
        let label, major = false;
        if (d.getMonth() === 0 && d.getDate() === 1 && (cand < 0 || cand >= 864e5 || (d.getHours() === 0 && d.getMinutes() === 0))) { label = String(d.getFullYear()); major = true; }
        else if (cand < 0) label = U.MON[d.getMonth()];
        else if (cand >= 864e5) { label = d.getDate() === 1 ? U.MON[d.getMonth()] : String(d.getDate()); major = d.getDate() === 1; }
        else if (d.getHours() === 0 && d.getMinutes() === 0) { label = `${d.getDate()} ${U.MON[d.getMonth()]}`; major = true; }
        else label = `${U.pad(d.getHours())}:${U.pad(d.getMinutes())}`;
        out.push({ i, x: this.idxToX(i), label, major });
      }
      prev = k;
    }
    return out;
  }

  // ---------- отрисовка ----------
  render() {
    if (!this.W || !this.H || this.dead) return;
    if (this.cell.offsetParent === null) return; // график скрыт — не тратим время
    const ctx = this.ctx, d = DPR(), th = this.app.th, st = this.app.state.settings;
    ctx.setTransform(d, 0, 0, d, 0, 0);
    ctx.font = `11px ${U.FF}`;
    if (this.bars.length) {
      const w = Math.ceil(ctx.measureText(U.fmt(this.ref * 1.5, this.ref)).width + 20);
      const nw = Math.max(58, w);
      if (nw !== this.AXW) { this.AXW = nw; this.layoutDirty = true; this.cell.style.setProperty('--axw', nw + 'px'); }
    }
    if (this.layoutDirty) this.computeLayout();
    const W = this.W, H = this.H, pw = this.plotW, ph = this.plotH;
    ctx.fillStyle = th.chartBg; ctx.fillRect(0, 0, W, H);
    if (!this.series.length) {
      ctx.strokeStyle = th.border; ctx.beginPath(); ctx.moveTo(pw + 0.5, 0); ctx.lineTo(pw + 0.5, ph); ctx.moveTo(0, ph + 0.5); ctx.lineTo(W, ph + 0.5); ctx.stroke();
      if (this.legendDirty) this.rebuildLegend();
      return;
    }
    this.computeScales();
    const [L, R] = this.vis;
    const tt = this.timeTicks(L - 1, R + 1);
    for (const pane of this.panes) pane.ticks = this.priceTicks(pane);
    if (st.grid !== false) {
      ctx.strokeStyle = th.grid; ctx.lineWidth = 1; ctx.beginPath();
      for (const k of tt) { const x = Math.round(k.x) + 0.5; ctx.moveTo(x, 0); ctx.lineTo(x, ph); }
      for (const pane of this.panes) for (const t of pane.ticks) { if (t.y < pane.top || t.y > pane.top + pane.h || (pane.kind === 'main' && st.roundLevels !== false && this.isRound(t.v))) continue; const y = Math.round(t.y) + 0.5; ctx.moveTo(0, y); ctx.lineTo(pw, y); }
      ctx.stroke();
      if (st.roundLevels !== false) {
        ctx.strokeStyle = U.hexA(th.text, 0.12); ctx.beginPath();
        for (const t of this.main.ticks) { if (!this.isRound(t.v) || t.y < 0 || t.y > this.main.h) continue; const y = Math.round(t.y) + 0.5; ctx.moveTo(0, y); ctx.lineTo(pw, y); }
        ctx.stroke();
      }
    }
    if (st.sessions) this.drawSessions(ctx, L, R);
    if (st.watermark !== false) {
      ctx.save();
      ctx.fillStyle = th.watermark; ctx.font = `600 ${Math.round(U.clamp(pw / 9, 18, 64))}px ${U.FF}`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(`${Data.label(this.sym).short} · ${U.ivShort(this.iv)}`, pw / 2, this.main.h / 2);
      ctx.restore();
    }
    for (const pane of this.panes) {
      ctx.save(); ctx.beginPath(); ctx.rect(0, pane.top, pw, pane.h); ctx.clip();
      if (pane.kind === 'main') this.drawMain(ctx, L, R); else this.drawIndPane(ctx, pane, L, R);
      ctx.restore();
    }
    // разделители и оси
    ctx.strokeStyle = th.border; ctx.lineWidth = 1; ctx.beginPath();
    for (let k = 1; k < this.panes.length; k++) { const y = Math.round(this.panes[k].top) + 0.5; ctx.moveTo(0, y); ctx.lineTo(W, y); }
    ctx.moveTo(pw + 0.5, 0); ctx.lineTo(pw + 0.5, ph); ctx.moveTo(0, ph + 0.5); ctx.lineTo(W, ph + 0.5);
    ctx.stroke();
    ctx.font = `11px ${U.FF}`; ctx.fillStyle = th.textDim; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    for (const pane of this.panes) for (const t of pane.ticks) {
      if (!(t.y > pane.top + 8 && t.y < pane.top + pane.h - 8)) continue;
      const rnd = pane.kind === 'main' && st.roundLevels !== false && this.isRound(t.v);
      ctx.font = `${rnd ? '600 ' : ''}11px ${U.FF}`; ctx.fillStyle = rnd ? th.text : th.textDim;
      ctx.fillText(t.label, pw + 7, t.y);
    }
    ctx.font = `11px ${U.FF}`; ctx.fillStyle = th.textDim;
    ctx.textAlign = 'center';
    for (const k of tt) {
      if (k.x < 16 || k.x > pw - 16) continue;
      ctx.font = `${k.major ? '600 ' : ''}11px ${U.FF}`; ctx.fillStyle = k.major ? th.text : th.textDim;
      ctx.fillText(k.label, k.x, ph + this.AXH / 2);
    }
    this.drawAxisTags(ctx);
    this.drawCrosshair(ctx);
    if (this.legendDirty) this.rebuildLegend();
    this.updateLegend();
  }

  // торговые сессии (время UTC): Азия 00–09, Европа 07–16, Америка 13–22
  drawSessions(ctx, L, R) {
    if (this.ivMs > 36e5 || !this.bars.length) return;
    const S = [{ n: 'Азия', h0: 0, h1: 9, c: '#e8c547' }, { n: 'Европа', h0: 7, h1: 16, c: '#4f8cff' }, { n: 'Америка', h0: 13, h1: 22, c: '#c46bff' }];
    const t0 = this.idxToTime(L - 2), t1 = this.idxToTime(R + 2), D = 864e5, top = this.main.top, h = this.main.h;
    ctx.save(); ctx.beginPath(); ctx.rect(0, top, this.plotW, h); ctx.clip();
    ctx.font = `600 10px ${U.FF}`; ctx.textBaseline = 'top'; ctx.textAlign = 'left';
    for (let day = Math.floor(t0 / D) * D; day <= t1; day += D) {
      S.forEach((ss, k) => {
        const a = this.timeToX(day + ss.h0 * 36e5) - this.spacing / 2, b = this.timeToX(day + ss.h1 * 36e5) - this.spacing / 2;
        if (b < 0 || a > this.plotW) return;
        ctx.fillStyle = U.hexA(ss.c, 0.045); ctx.fillRect(a, top, b - a, h);
        const yb = top + h * (this.cfg.indicators.some(i => i.type === 'VOL' && i.visible !== false) ? 0.84 : 1) - 4;
        ctx.fillStyle = U.hexA(ss.c, 0.55); ctx.fillRect(a, yb - k * 3, b - a, 2);
        if (b - a > 46) { ctx.fillStyle = U.hexA(ss.c, 0.75); ctx.fillText(ss.n, Math.max(a, 0) + 4, yb - 14 - k * 11); }
      });
    }
    ctx.restore();
  }

  bodyW() { return Math.max(1, this.candleGeom(DPR()).bw / DPR()); }

  drawMain(ctx, L, R) {
    const th = this.app.th, st = this.app.state.settings;
    const upC = st.upColor || th.up, dnC = st.downColor || th.down;
    for (const inst of this.overlays()) if (IND.defs[inst.type].vol) this.drawVolume(ctx, inst, L, R, st.candleBorder !== false && st.borderUp ? st.borderUp : upC, st.candleBorder !== false && st.borderDn ? st.borderDn : dnC);
    if (this.cfg.liq) this.drawLiq(ctx, L, R);
    for (const inst of this.overlays()) if (!IND.defs[inst.type].vol) this.drawFills(ctx, inst, this.main, L, R);
    this.drawSeries(ctx, L, R, upC, dnC);
    for (const inst of this.overlays()) if (!IND.defs[inst.type].vol) this.drawOutputs(ctx, inst, this.main, L, R);
    // последняя цена
    const lb = this.bars[this.bars.length - 1];
    if (lb && st.lastLine !== false) {
      const y = Math.round(this.priceToY(lb.c)) + 0.5;
      ctx.strokeStyle = lb.c >= lb.o ? upC : dnC; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.plotW, y); ctx.stroke(); ctx.setLineDash([]);
    }
    this.drawDrawings(ctx);
    this.drawPriceLines(ctx);
  }

  drawSeries(ctx, L, R, upC, dnC) {
    const s = this.series, type = this.cfg.type, bw = this.bodyW(), th = this.app.th;
    if (type === 'line' || type === 'area') {
      ctx.beginPath();
      for (let i = Math.max(0, L - 1); i <= Math.min(s.length - 1, R + 1); i++) {
        const x = this.idxToX(i), y = this.priceToY(s[i].c);
        i === Math.max(0, L - 1) ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      if (type === 'area') {
        const p = new Path2D(); p.addPath(new Path2D());
        ctx.save();
        const bot = this.main.top + this.main.h;
        const g = ctx.createLinearGradient(0, this.main.top, 0, bot);
        g.addColorStop(0, U.hexA(th.line, 0.35)); g.addColorStop(1, U.hexA(th.line, 0.02));
        ctx.lineTo(this.idxToX(Math.min(s.length - 1, R + 1)), bot); ctx.lineTo(this.idxToX(Math.max(0, L - 1)), bot); ctx.closePath();
        ctx.fillStyle = g; ctx.fill(); ctx.restore();
        ctx.beginPath();
        for (let i = Math.max(0, L - 1); i <= Math.min(s.length - 1, R + 1); i++) {
          const x = this.idxToX(i), y = this.priceToY(s[i].c);
          i === Math.max(0, L - 1) ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
      }
      ctx.strokeStyle = th.line; ctx.lineWidth = 2; ctx.lineJoin = 'round'; ctx.stroke();
      return;
    }
    if (type === 'bars') {
      const tk = Math.max(1, Math.floor(bw / 2));
      for (const up of [true, false]) {
        ctx.beginPath();
        for (let i = L; i <= R; i++) {
          const b = s[i]; if ((b.c >= b.o) !== up) continue;
          const x = Math.round(this.idxToX(i)) + 0.5;
          ctx.moveTo(x, this.priceToY(b.h)); ctx.lineTo(x, this.priceToY(b.l));
          const yo = Math.round(this.priceToY(b.o)) + 0.5, yc = Math.round(this.priceToY(b.c)) + 0.5;
          ctx.moveTo(x - tk, yo); ctx.lineTo(x, yo); ctx.moveTo(x, yc); ctx.lineTo(x + tk, yc);
        }
        ctx.strokeStyle = up ? upC : dnC; ctx.lineWidth = this.spacing > 6 ? 1.5 : 1; ctx.stroke();
      }
      return;
    }
    // Свечи рисуются в физических пикселях экрана: без размытия при масштабе Windows 125%/150%
    const hollow = type === 'hollow', st = this.app.state.settings, dpr = DPR();
    const border = st.candleBorder !== false;
    const bu = st.borderUp || upC, bd = st.borderDn || dnC, wu = st.wickUp || bu, wd = st.wickDn || bd;
    const g = this.candleGeom(dpr);
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const Y = p => Math.round(this.priceToY(p) * dpr);
    const paths = { wu: new Path2D(), wd: new Path2D(), bu: new Path2D(), bd: new Path2D(), fu: new Path2D(), fd: new Path2D(), hole: new Path2D() };
    const bwid = g.bw, ww = g.ww, bt = g.bt;
    for (let i = L; i <= R; i++) {
      const b = s[i], up = b.c >= b.o;
      const left = Math.round(this.idxToX(i) * dpr - bwid / 2), wl = left + ((bwid - ww) >> 1);
      let top = Y(Math.max(b.o, b.c)), bot = Y(Math.min(b.o, b.c));
      if (bot - top < g.minH) { const m = Math.round((top + bot) / 2); top = m - (g.minH >> 1); bot = top + g.minH; }
      const yh = Y(b.h), yl = Y(b.l);
      const wp = up ? paths.wu : paths.wd;
      if (top > yh) wp.rect(wl, yh, ww, top - yh);
      if (yl > bot) wp.rect(wl, bot, ww, yl - bot);
      if (bwid < 3) { wp.rect(left, top, bwid, bot - top); continue; }
      const showB = (border || (hollow && up)) && bwid >= 4 && bot - top > bt * 2;
      if (showB) {
        (up ? paths.bu : paths.bd).rect(left, top, bwid, bot - top);
        if (hollow && up) paths.hole.rect(left + bt, top + bt, bwid - bt * 2, bot - top - bt * 2);
        else (up ? paths.fu : paths.fd).rect(left + bt, top + bt, bwid - bt * 2, bot - top - bt * 2);
      } else (up ? paths.fu : paths.fd).rect(left, top, bwid, bot - top);
    }
    ctx.fillStyle = wu; ctx.fill(paths.wu);
    ctx.fillStyle = wd; ctx.fill(paths.wd);
    ctx.fillStyle = bu; ctx.fill(paths.bu);
    ctx.fillStyle = bd; ctx.fill(paths.bd);
    ctx.fillStyle = upC; ctx.fill(paths.fu);
    ctx.fillStyle = dnC; ctx.fill(paths.fd);
    ctx.fillStyle = this.app.th.chartBg; ctx.fill(paths.hole);
    ctx.restore();
  }

  // геометрия свечи в физических пикселях: тело нечётной ширины, фитиль ровно по центру
  candleGeom(dpr) {
    const sp = this.spacing * dpr;
    let bw = sp < 2.5 ? Math.max(1, Math.floor(sp)) : Math.floor(sp * (sp > 24 ? 0.72 : sp > 8 ? 0.78 : 0.82));
    if (sp >= 3 && sp - bw < 1) bw = Math.floor(sp) - 1;
    let ww = Math.max(1, Math.round(dpr * (this.spacing > 22 ? 1.4 : 1)));
    if (bw >= 3 && (bw - ww) % 2) bw -= 1;
    bw = Math.max(1, bw);
    if (ww > bw) ww = bw;
    return { bw, ww, bt: Math.max(1, Math.round(dpr)), minH: Math.max(1, Math.round(dpr)) };
  }

  drawVolume(ctx, inst, L, R, upC, dnC) {
    const res = this.res.get(inst.id); if (!res || !res.v) return;
    const vh = this.main.h * 0.16, base = this.main.top + this.main.h;
    let mx = 0; for (let i = L; i <= R; i++) if (res.v[i] > mx) mx = res.v[i];
    this.volScale = { mx, vh, base, inst };
    if (!mx) return;
    const dpr = DPR(), g = this.candleGeom(dpr), pu = new Path2D(), pd = new Path2D(), by = Math.round(base * dpr);
    for (let i = L; i <= R; i++) {
      const b = this.bars[i], h = Math.max(1, Math.round(res.v[i] / mx * vh * dpr));
      (b.c >= b.o ? pu : pd).rect(Math.round(this.idxToX(i) * dpr - g.bw / 2), by - h, g.bw, h);
    }
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
    const va = this.app.state.settings.volAlpha ?? 0.35;
    ctx.fillStyle = U.hexA(upC, va); ctx.fill(pu);
    ctx.fillStyle = U.hexA(dnC, va); ctx.fill(pd);
    ctx.restore();
    if (res.ma) {
      const c = inst.colors.ma || IND.defs.VOL.o[1].c;
      ctx.beginPath(); let pen = false;
      for (let i = L; i <= R; i++) { const v = res.ma[i]; if (v !== v) { pen = false; continue; } const x = this.idxToX(i), y = base - v / mx * vh; pen ? ctx.lineTo(x, y) : ctx.moveTo(x, y); pen = true; }
      ctx.strokeStyle = c; ctx.lineWidth = 1; ctx.stroke();
    }
  }

  drawFills(ctx, inst, pane, L, R) {
    const d = IND.defs[inst.type]; if (!d.fills) return;
    const res = this.res.get(inst.id); if (!res) return;
    for (const f of d.fills) {
      const a = res[f.a], b = res[f.b]; if (!a || !b) continue;
      const oa = d.o.find(o => o.k === f.a), off = oa && oa.off ? oa.off(inst.params) : 0;
      let seg = [], sign = 0;
      const flush = () => {
        if (seg.length > 1) {
          ctx.beginPath();
          seg.forEach((p, k) => k ? ctx.lineTo(p.x, p.ya) : ctx.moveTo(p.x, p.ya));
          for (let k = seg.length - 1; k >= 0; k--) ctx.lineTo(seg[k].x, seg[k].yb);
          ctx.closePath();
          ctx.fillStyle = U.hexA(f.c2 && sign < 0 ? f.c2 : (inst.colors[f.a] && !f.c2 ? inst.colors[f.a] : f.c), 0.12);
          ctx.fill();
        }
        seg = [];
      };
      for (let j = L - 1; j <= R + 1; j++) {
        const vi = j - off, va = a[vi], vb = b[vi];
        if (va !== va || vb !== vb || va === undefined || vb === undefined) { flush(); continue; }
        const sg = va >= vb ? 1 : -1;
        if (f.c2 && seg.length && sg !== sign) { const last = seg[seg.length - 1]; flush(); seg.push(last); }
        sign = sg;
        seg.push({ x: this.idxToX(j), ya: this.priceToY(va, pane), yb: this.priceToY(vb, pane) });
      }
      flush();
    }
  }

  drawOutputs(ctx, inst, pane, L, R) {
    const d = IND.defs[inst.type], res = this.res.get(inst.id); if (!res) return;
    const bw = this.bodyW();
    for (const o of d.o) {
      if (o.t === 'vol') continue;
      const arr = res[o.k]; if (!arr) continue;
      const off = o.off ? o.off(inst.params) : 0, c = inst.colors[o.k] || o.c, cols = res._col && res._col[o.k];
      if (o.t === 'hist') {
        const y0 = this.priceToY(0, pane);
        for (let j = L; j <= R; j++) {
          const v = arr[j - off]; if (v !== v || v === undefined) continue;
          const y = this.priceToY(v, pane);
          ctx.fillStyle = cols ? cols[j - off] : (v >= 0 ? c : this.app.th.down);
          ctx.fillRect(Math.round(this.idxToX(j) - bw / 2), Math.min(y, y0), bw, Math.max(1, Math.abs(y - y0)));
        }
      } else if (o.t === 'dots') {
        const r = U.clamp(this.spacing * 0.22, 1.2, 3);
        for (let j = L; j <= R; j++) {
          const v = arr[j - off]; if (v !== v || v === undefined) continue;
          ctx.fillStyle = cols && !inst.colors[o.k] ? cols[j - off] : c;
          ctx.beginPath(); ctx.arc(this.idxToX(j), this.priceToY(v, pane), r, 0, Math.PI * 2); ctx.fill();
        }
      } else {
        ctx.beginPath(); let pen = false;
        for (let j = L - 1; j <= R + 1; j++) {
          const v = arr[j - off]; if (v !== v || v === undefined) { pen = false; continue; }
          const x = this.idxToX(j), y = this.priceToY(v, pane);
          pen ? ctx.lineTo(x, y) : ctx.moveTo(x, y); pen = true;
        }
        ctx.strokeStyle = c; ctx.lineWidth = (o.w || 1.5) + (inst === this.selInd ? 1.6 : 0); ctx.lineJoin = 'round'; ctx.stroke();
      }
    }
  }

  drawIndPane(ctx, pane, L, R) {
    const inst = pane.ind, d = IND.defs[inst.type], th = this.app.th;
    if (inst.visible === false) return;
    if (d.lfill && d.levels.length >= 2) {
      const y1 = this.priceToY(d.levels[0], pane), y2 = this.priceToY(d.levels[d.levels.length - 1], pane);
      ctx.fillStyle = U.hexA('#a66bff', 0.06); ctx.fillRect(0, Math.min(y1, y2), this.plotW, Math.abs(y2 - y1));
    }
    ctx.strokeStyle = U.hexA(th.textDim, 0.6); ctx.lineWidth = 1; ctx.setLineDash([4, 4]); ctx.beginPath();
    for (const lv of d.levels) { const y = Math.round(this.priceToY(lv, pane)) + 0.5; ctx.moveTo(0, y); ctx.lineTo(this.plotW, y); }
    ctx.stroke(); ctx.setLineDash([]);
    this.drawFills(ctx, inst, pane, L, R);
    if (d.zones) this.drawZones(ctx, inst, pane, L, R);
    this.drawOutputs(ctx, inst, pane, L, R);
  }

  // заливка зон перекупленности / перепроданности
  drawZones(ctx, inst, pane, L, R) {
    const d = IND.defs[inst.type], res = this.res.get(inst.id); if (!res) return;
    for (const z of d.zones) {
      const arr = res[z.k]; if (!arr) continue;
      const lv = z.above ?? z.below, yl = this.priceToY(lv, pane);
      ctx.save();
      ctx.beginPath();
      if (z.above != null) ctx.rect(0, pane.top, this.plotW, yl - pane.top);
      else ctx.rect(0, yl, this.plotW, pane.top + pane.h - yl);
      ctx.clip();
      ctx.beginPath();
      let open = false, lastX = 0;
      for (let j = Math.max(0, L - 1); j <= R + 1; j++) {
        const v = arr[j];
        if (v !== v || v === undefined) { if (open) { ctx.lineTo(lastX, yl); ctx.closePath(); open = false; } continue; }
        const x = this.idxToX(j), y = this.priceToY(v, pane);
        if (!open) { ctx.moveTo(x, yl); open = true; }
        ctx.lineTo(x, y); lastX = x;
      }
      if (open) { ctx.lineTo(lastX, yl); ctx.closePath(); }
      ctx.fillStyle = U.hexA(z.c, 0.28);
      ctx.fill();
      ctx.restore();
    }
  }

  // маленькое окошко «в сделке»: плюс/минус и время — в углу графика, не на самой позиции
  updatePosPill() {
    const now = performance.now(); if (now - (this._ppT || 0) < 400) return; this._ppT = now;
    const items = [];
    for (const d of this.drawings) {
      if ((d.type !== 'long' && d.type !== 'short') || d.hidden) continue;
      const L = DRAW.LIVE.get(d); if (!L || L.state !== 'live') continue;
      items.push({ d, L });
    }
    let box = this.cell.querySelector('.pos-pills');
    if (!items.length || this.replay) { if (box) box.remove(); return; }
    if (!box) {
      box = U.h('<div class="pos-pills"></div>'); this.cell.appendChild(box);
      box.addEventListener('click', e => {
        const t = e.target.closest('[data-i]'); if (!t) return;
        const it = this._ppItems && this._ppItems[+t.dataset.i]; if (!it) return;
        if (e.target.closest('.pp-fold')) { const st = this.app.state.settings; st.posPillMini = !st.posPillMini; this.app.saveSoon(); this._ppT = 0; this.invalidate(); return; }
        this.selected = it.d; this.app.onSelect(this); this.invalidate(); // клик — выделить позицию
      });
    }
    this._ppItems = items;
    const cur0 = this.bars.length ? this.bars[this.bars.length - 1].c : 0, mini = !!this.app.state.settings.posPillMini;
    const dur = ms => { const m = Math.max(0, Math.floor(ms / 6e4)); if (m < 60) return `${m} мин`; const h = Math.floor(m / 60); if (h < 24) return `${h} ч ${m % 60} мин`; return `${Math.floor(h / 24)} д ${h % 24} ч`; };
    const usd = v => `${v >= 0 ? '+' : '−'}$${U.fmtNum(Math.abs(v), Math.abs(v) >= 100 ? 0 : 2)}`;
    const html = items.map(({ d, L }, i) => {
      const dir = L.isLong ? 1 : -1;
      // позиция с биржи на другом рынке (например, график — спот, позиция — фьючерс): берём цену фьючерса
      const pid = d.acct && d.acct.key.split('|')[1];
      const cur = pid && pid !== this.sym ? (this.app.prices[pid] || d.acct.mark || cur0) : cur0;
      // с комиссией: считаем от «безубытка» нулевой точки
      const be = L.fee ? (L.isLong ? L.zp * (1 + L.fee) / (1 - L.fee) : L.zp * (1 - L.fee) / (1 + L.fee)) : L.zp;
      const pct = (cur - be) / be * 100 * dir;
      const amt = d.style && d.style.amount > 0 ? d.style.amount * L.share : 0;
      const t0 = d.acct && d.acct.openAt ? d.acct.openAt : d.fillAt && d.fillAt.length ? Math.min(...d.fillAt.filter(Boolean)) : L.tIn;
      const cls = pct >= 0 ? 'up' : 'dn';
      const pctTxt = `${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`;
      if (mini) return `<div class="pp ${cls}" data-i="${i}" title="Нажмите ‹ чтобы развернуть"><span class="pp-fold">›</span><b>${pctTxt}</b></div>`;
      return `<div class="pp ${cls}" data-i="${i}" title="Клик — выделить позицию. Нулевая точка ${U.fmt(L.zp, L.zp)}">
        <span class="pp-fold" title="Свернуть">‹</span>
        ${d.acct ? `<span class="ex-mini">${{ binance: 'BN', bybit: 'BY', gate: 'GT' }[d.acct.ex] || ''}</span>` : ''}<span class="pp-dir ${L.isLong ? 'l' : 's'}">${L.isLong ? 'ЛОНГ' : 'ШОРТ'}${d.acct && d.acct.lev ? ' x' + d.acct.lev : ''}</span>${L.nT > 1 ? `<span class="pp-dim">вход ${L.nF}/${L.nT}</span>` : ''}
        ${amt ? `<b>${usd(amt * pct / 100)}</b>` : ''}<b>${pctTxt}</b><span class="pp-dim">${t0 ? dur(Date.now() - t0) : ''}</span></div>`;
    }).join('');
    if (box._h !== html) { box.innerHTML = html; box._h = html; }
    // над шкалой времени, в левом нижнем углу основного графика
    if (this.main) box.style.top = Math.round(this.main.top + this.main.h - 8) + 'px';
  }
  drawDrawings(ctx) {
    this.geo = new Map();
    const st = this.app.state.settings;
    const all = st.hideDrawings ? [] : this.drawings.slice();
    if (this.creating) all.push(this.creating.d);
    if (this.ruler) all.push(this.ruler);
    for (const d of all) {
      if (d.hidden) continue;
      const P = d.pts.map(p => ({ x: this.timeToX(p.t), y: this.priceToY(p.p) }));
      let g;
      try { g = DRAW.build(this, d, P); } catch (e) { console.error(e); continue; }
      this.geo.set(d, g);
      DRAW.paint(ctx, this, d, g, d === this.selected || d === this.hover);
    }
    this.updatePosPill();
    const th = this.app.th;
    for (const d of [this.selected, this.hover !== this.selected ? this.hover : null]) {
      if (!d) continue;
      const g = this.geo.get(d); if (!g) continue;
      for (const h of g.handles) {
        if (h.kind === 'w') { // ручка ширины: плашка со стрелками ◀ ▶
          const w = 22, hh = 14, x0 = h.side === 'l' ? h.x - 25 : h.x + 3, y0 = h.y - hh / 2;
          ctx.beginPath(); ctx.roundRect(x0, y0, w, hh, 4);
          ctx.fillStyle = th.chartBg; ctx.fill();
          ctx.strokeStyle = d.locked ? th.textDim : th.accent; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.fillStyle = d.locked ? th.textDim : th.accent; ctx.beginPath();
          const cx = x0 + w / 2, cy = h.y;
          ctx.moveTo(cx - 8, cy); ctx.lineTo(cx - 3, cy - 4); ctx.lineTo(cx - 3, cy + 4); ctx.closePath();
          ctx.moveTo(cx + 8, cy); ctx.lineTo(cx + 3, cy - 4); ctx.lineTo(cx + 3, cy + 4); ctx.closePath();
          ctx.fill();
          continue;
        }
        ctx.beginPath(); ctx.arc(h.x, h.y, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = th.chartBg; ctx.fill();
        ctx.strokeStyle = d.locked ? th.textDim : th.accent; ctx.lineWidth = 1.5; ctx.stroke();
      }
    }
  }

  drawPriceLines(ctx) {
    const th = this.app.th;
    this.plines = this.app.priceLinesFor(this.sym);
    ctx.font = `600 11px ${U.FF}`;
    for (const pl of this.plines) {
      const y = Math.round(this.priceToY(pl.price)) + 0.5;
      pl._y = y;
      if (y < this.main.top - 2 || y > this.main.top + this.main.h + 2) { pl._box = pl._x = null; continue; }
      ctx.strokeStyle = pl.color; ctx.lineWidth = 1; ctx.setLineDash(pl.dash || []);
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.plotW, y); ctx.stroke(); ctx.setLineDash([]);
      const tw = ctx.measureText(pl.label).width, bw = tw + 14 + (pl.onCancel ? 18 : 0), bh = 18;
      const bx = this.plotW - bw - 8, by = y - bh / 2;
      ctx.fillStyle = pl.color; ctx.beginPath(); ctx.roundRect(bx, by, bw, bh, 3); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(pl.label, bx + 7, y);
      pl._box = { x: bx, y: by, w: bw, h: bh };
      if (pl.onCancel) {
        const cx = bx + bw - 12;
        ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 1.5; ctx.beginPath();
        ctx.moveTo(cx - 3.5, y - 3.5); ctx.lineTo(cx + 3.5, y + 3.5); ctx.moveTo(cx + 3.5, y - 3.5); ctx.lineTo(cx - 3.5, y + 3.5); ctx.stroke();
        pl._x = { x: bx + bw - 20, y: by, w: 20, h: bh };
      } else pl._x = null;
    }
    void th;
  }

  tag(ctx, y, text, bg, fg, pane, sub) {
    const h = sub ? 30 : 18;
    y = U.clamp(y, pane.top + h / 2, pane.top + pane.h - h / 2);
    ctx.fillStyle = bg; ctx.beginPath(); ctx.roundRect(this.plotW + 1, y - h / 2, this.AXW - 2, h, 3); ctx.fill();
    ctx.fillStyle = fg; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    if (sub) { ctx.fillText(text, this.plotW + 6, y - 7); ctx.font = `10px ${U.FF}`; ctx.fillText(sub, this.plotW + 6, y + 7); ctx.font = `11px ${U.FF}`; }
    else ctx.fillText(text, this.plotW + 6, y);
  }

  drawAxisTags(ctx) {
    const th = this.app.th, st = this.app.state.settings, n = this.bars.length;
    ctx.font = `11px ${U.FF}`;
    const idx = n - 1;
    // индикаторы
    for (const pane of this.panes) {
      const insts = pane.kind === 'main' ? this.overlays().filter(i => !IND.defs[i.type].vol) : (pane.ind.visible === false ? [] : [pane.ind]);
      for (const inst of insts) {
        const d = IND.defs[inst.type], res = this.res.get(inst.id); if (!res) continue;
        for (const o of d.o) {
          const arr = res[o.k]; if (!arr || o.t === 'vol') continue;
          const off = o.off ? o.off(inst.params) : 0;
          if (off > 0) continue;
          const v = arr[idx - off]; if (v !== v || v === undefined) continue;
          const c = (res._col && res._col[o.k] && !inst.colors[o.k]) ? res._col[o.k][idx - off] : (inst.colors[o.k] || o.c);
          this.tag(ctx, this.priceToY(v, pane), pane.kind === 'main' ? U.fmt(v, this.ref) : IND.fmtVal(d, v), c, '#fff', pane);
        }
      }
    }
    for (const pl of this.plines) this.tag(ctx, pl._y, U.fmt(pl.price, this.ref), pl.color, '#fff', this.main);
    const lb = this.bars[idx];
    if (lb) {
      const c = lb.c >= lb.o ? (st.upColor || th.up) : (st.downColor || th.down);
      const rem = lb.t + this.ivMs - Date.now();
      this.tag(ctx, this.priceToY(lb.c), U.fmt(lb.c, this.ref), c, '#fff', this.main, st.countdown !== false && rem > 0 ? U.fmtCountdown(rem) : null);
    }
  }

  drawCrosshair(ctx) {
    const th = this.app.th, pw = this.plotW, ph = this.plotH;
    const tool = this.app.tool;
    let cx = null, cy = null, idx = null;
    if (this.mouse) {
      const { x, y } = this.mouse;
      idx = Math.round(this.xToIdx(Math.min(x, pw)));
      cx = this.idxToX(idx);
      if (y < ph && x < pw) cy = y;
      if (x >= pw && y < ph) cy = y;
    } else if (this.extCross != null) {
      idx = Math.round(this.timeToIdx(this.extCross)); cx = this.idxToX(idx);
    }
    if (cx === null) return;
    if (this.app.replayPick === this && this.mouse && this.mouse.x < pw) {
      const x = Math.round(cx) + 0.5;
      ctx.fillStyle = U.hexA('#3d7bf0', 0.08); ctx.fillRect(x, 0, pw - x, ph);
      ctx.strokeStyle = '#3d7bf0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, ph); ctx.stroke();
      ctx.font = `600 12px ${U.FF}`; const t = 'Начать повтор отсюда', w = ctx.measureText(t).width + 16;
      ctx.fillStyle = '#3d7bf0'; ctx.beginPath(); ctx.roundRect(Math.min(x + 6, pw - w - 4), 12, w, 24, 4); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(t, Math.min(x + 14, pw - w + 4), 24);
    }
    const showLines = tool !== 'arrow' && tool !== 'dot';
    ctx.strokeStyle = th.cross; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
    ctx.beginPath();
    if (showLines || !this.mouse) { const x = Math.round(cx) + 0.5; ctx.moveTo(x, 0); ctx.lineTo(x, ph); }
    if (showLines && cy !== null && this.mouse.x < pw) { const y = Math.round(cy) + 0.5; ctx.moveTo(0, y); ctx.lineTo(pw, y); }
    ctx.stroke(); ctx.setLineDash([]);
    if (tool === 'dot' && cy !== null && this.mouse.x < pw) { ctx.fillStyle = th.text; ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill(); }
    // метка времени
    ctx.font = `11px ${U.FF}`;
    const tl = U.fmtTimeFull(this.idxToTime(idx), this.ivMs), tw = ctx.measureText(tl).width + 14;
    const tx = U.clamp(cx - tw / 2, 0, pw - tw);
    ctx.fillStyle = th.labelBg; ctx.beginPath(); ctx.roundRect(tx, ph + 3, tw, this.AXH - 6, 3); ctx.fill();
    ctx.fillStyle = th.labelText; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(tl, tx + tw / 2, ph + this.AXH / 2);
    if (cy !== null) {
      const pane = this.paneAt(cy);
      if (pane) {
        const v = this.yToPrice(cy, pane);
        this.tag(ctx, cy, pane.kind === 'main' ? U.fmt(v, this.ref) : IND.fmtVal(IND.defs[pane.ind.type], v), th.labelBg, th.labelText, pane);
      }
    }
  }

  // ---------- корреляция с биткоином ----------
  async corrUpdate() {
    const tok = this.tok;
    try { const v = await Corr.forChart(this); if (tok !== this.tok) return; this.corrVal = v; } catch { this.corrVal = null; }
    this.corrFor = this.sym + this.iv; this.paintCorr();
  }
  paintCorr() {
    const el = this.lgCorr; if (!el) return;
    if (Corr.isBtc(this.sym) || this.corrFor !== this.sym + this.iv) { el.textContent = ''; el.title = ''; return; }
    const v = this.corrVal;
    el.textContent = `к BTC ${Corr.fmt(v)}`; el.className = 'lg-corr ' + Corr.cls(v);
    el.title = `Корреляция с биткоином по ${U.ivShort(this.iv)}-свечам (последние 100): ${v == null ? 'мало данных' : v.toFixed(2) + ' — ' + Corr.words(v)}`;
  }
  // ---------- легенда ----------
  rebuildLegend() {
    this.legendDirty = false; this.lgKey = '';
    const el = this.legendsEl; el.innerHTML = ''; this.lg = [];
    const main = U.h(`<div class="legend" style="top:6px"><div class="lg-head"><span class="lg-fresh" title="Свежесть данных"></span><span class="lg-sym">${U.esc(Data.label(this.sym).short)}</span><span class="lg-iv">${U.ivShort(this.iv)} · ${Data.label(this.sym).full}</span><span class="lg-corr"></span><span class="lg-ohlc"></span></div></div>`);
    this.lgOhlc = main.querySelector('.lg-ohlc'); this.lgFresh = main.querySelector('.lg-fresh'); this.lgCorr = main.querySelector('.lg-corr');
    this.paintCorr();
    el.appendChild(main);
    const row = inst => {
      const d = IND.defs[inst.type];
      const r = U.h(`<div class="lg-row${inst.visible === false ? ' off' : ''}${inst === this.selInd ? ' sel' : ''}" data-id="${inst.id}"><span class="lg-name">${U.esc(IND.title(inst))}</span><span class="lg-vals"></span><span class="lg-btns"><button class="ib xs" data-a="vis" title="Показать/скрыть">${U.icon(inst.visible === false ? 'eyeOff' : 'eye', 14)}</button><button class="ib xs" data-a="set" title="Настройки">${U.icon('gear', 14)}</button><button class="ib xs" data-a="del" title="Удалить">${U.icon('close', 14)}</button></span></div>`);
      this.lg.push({ inst, d, vals: r.querySelector('.lg-vals') });
      return r;
    };
    if (this.cfg.liq) {
      const lr = U.h(`<div class="lg-row liq-row"><span class="lg-name">${U.icon('flame', 13)} Карта ликвидаций · модель по OI Binance</span><span class="lg-vals">${U.esc(this.liqStatus || '')}</span><span class="lg-btns"><button class="ib xs" data-liq="set" title="Настройки">${U.icon('gear', 14)}</button><button class="ib xs" data-liq="off" title="Выключить">${U.icon('close', 14)}</button></span></div>`);
      lr.onclick = e => { const bb = e.target.closest('[data-liq]'); if (!bb) return; e.stopPropagation(); bb.dataset.liq === 'off' ? this.app.toggleLiq(this) : this.app.openLiqSettings(this); };
      main.appendChild(lr);
    }
    for (const inst of this.cfg.indicators) {
      const d = IND.defs[inst.type]; if (!d) continue;
      if (d.overlay) main.appendChild(row(inst));
      else {
        const pane = this.panes.find(p => p.ind === inst); if (!pane) continue;
        const box = U.h(`<div class="legend" style="top:${pane.top + 4}px"></div>`);
        box.appendChild(row(inst));
        el.appendChild(box);
      }
    }
    el.onclick = e => {
      const b = e.target.closest('button[data-a]');
      if (!b) { const r = e.target.closest('[data-id]'); if (r) { const inst = this.cfg.indicators.find(i => i.id === r.dataset.id); if (inst) this.app.selectIndicator(this, inst); } return; }
      const id = b.closest('[data-id]').dataset.id;
      const inst = this.cfg.indicators.find(i => i.id === id);
      if (inst) this.app.indAction(this, inst, b.dataset.a);
    };
    el.ondblclick = e => {
      const r = e.target.closest('[data-id]'); if (!r) return;
      const inst = this.cfg.indicators.find(i => i.id === r.dataset.id);
      if (inst) this.app.indAction(this, inst, 'set');
    };
    el.onpointerdown = () => this.app.setActive(this);
    el.oncontextmenu = e => {
      const r = e.target.closest('[data-id]'); if (!r) return;
      e.preventDefault();
      const inst = this.cfg.indicators.find(i => i.id === r.dataset.id);
      if (inst) { this.app.selectIndicator(this, inst); this.app.showChartMenu(this, e.clientX, e.clientY, { ind: inst }); }
    };
  }
  updateFresh() {
    const f = this.lgFresh; if (!f) return;
    const age = Date.now() - (this.lastData || 0), demo = Data.mode === 'demo';
    const cls = this.replay ? 'rp' : demo ? 'demo' : age < 10000 ? 'ok' : age < 30000 ? 'slow' : 'stale';
    if (f.dataset.c !== cls) { f.dataset.c = cls; f.className = 'lg-fresh ' + cls; }
    const live = Data.wsAlive(this.sym + '|' + this.iv);
    f.classList.toggle('poll', !live && cls === 'ok');
    f.title = this.replay ? 'Режим повтора' : demo ? 'Демо-данные' : `${live ? 'Поток сделок работает — цена в реальном времени' : 'Поток не подключается — цена обновляется раз в секунду запасным способом'}. Последнее обновление: ${Math.round(age / 1000)} с назад`;
  }
  updateLegend() {
    this.updateFresh();
    const s = this.series, n = s.length; if (!n || !this.lgOhlc) return;
    let idx = this.mouse && this.mouse.x < this.plotW ? Math.round(this.xToIdx(this.mouse.x)) : (this.extCross != null ? Math.round(this.timeToIdx(this.extCross)) : n - 1);
    idx = U.clamp(idx, 0, n - 1);
    const b = s[idx], key = idx + '|' + n + '|' + b.c + '|' + b.v;
    if (key === this.lgKey) return;
    this.lgKey = key;
    const prev = s[idx - 1], up = b.c >= b.o, cls = up ? 'up' : 'dn';
    const ch = prev ? b.c - prev.c : 0, chp = prev ? ch / prev.c * 100 : 0;
    const f = v => U.fmt(v, this.ref);
    this.lgOhlc.innerHTML = `<span>О<b class="${cls}">${f(b.o)}</b></span><span>М<b class="${cls}">${f(b.h)}</b></span><span>Н<b class="${cls}">${f(b.l)}</b></span><span>З<b class="${cls}">${f(b.c)}</b></span><b class="${ch >= 0 ? 'up' : 'dn'}">${ch >= 0 ? '+' : ''}${f(ch)} (${ch >= 0 ? '+' : ''}${chp.toFixed(2)}%)</b>`;
    for (const r of this.lg) {
      const res = this.res.get(r.inst.id); if (!res) continue;
      r.vals.innerHTML = r.d.o.map(o => {
        const arr = res[o.k]; if (!arr) return '';
        const off = o.off ? o.off(r.inst.params) : 0, v = arr[idx - off];
        let c = r.inst.colors[o.k] || o.c;
        if (o.t === 'vol') c = up ? this.app.th.up : this.app.th.down;
        else if (res._col && res._col[o.k] && !r.inst.colors[o.k]) c = res._col[o.k][idx - off] || c;
        return `<span style="color:${c}">${IND.fmtVal(r.d, v, this.ref)}</span>`;
      }).join(' ');
    }
  }

  // ---------- события ----------
  bind() {
    const cv = this.cv;
    cv.addEventListener('pointerdown', e => this.onDown(e));
    cv.addEventListener('pointermove', e => this.onMove(e));
    cv.addEventListener('pointerup', e => this.onUp(e));
    cv.addEventListener('pointercancel', () => { this.drag = null; });
    cv.addEventListener('pointerleave', () => {
      if (this.drag || this.creating) return;
      this.mouse = null; this.hover = null;
      this.app.crossFrom(this, null);
      this.invalidate();
    });
    cv.addEventListener('wheel', e => this.onWheel(e), { passive: false });
    cv.addEventListener('dblclick', e => this.onDbl(e));
    cv.addEventListener('contextmenu', e => { e.preventDefault(); this.onContext(e); });
  }
  pos(e) { const r = this.cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }

  snap(x, y) {
    const n = this.bars.length, idx = Math.round(this.xToIdx(x)), t = this.idxToTime(idx);
    let p = this.yToPrice(y);
    if (this.app.state.settings.magnet && idx >= 0 && idx < n) {
      const b = this.series[idx];
      let best = p, bd = Infinity;
      for (const v of [b.o, b.h, b.l, b.c]) { const dy = Math.abs(this.priceToY(v) - y); if (dy < bd) { bd = dy; best = v; } }
      if (bd < 40) p = best;
    }
    return { t, p };
  }
  hitPriceLine(x, y) {
    const inB = (b) => b && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;
    for (const pl of this.plines) {
      if (inB(pl._x)) return { pl, x: true };
      if (inB(pl._box)) return { pl };
      if (pl.drag && pl._y != null && Math.abs(y - pl._y) <= 4) return { pl };
    }
    return null;
  }
  hitHandle(x, y) {
    for (const d of [this.selected, this.hover]) {
      if (!d || d.locked) continue;
      const g = this.geo.get(d); if (!g) continue;
      for (let i = 0; i < g.handles.length; i++) {
        const h = g.handles[i];
        if (h.kind === 'w' ? ((h.side === 'l' ? x >= h.x - 27 && x <= h.x + 2 : x >= h.x - 2 && x <= h.x + 27) && Math.abs(y - h.y) <= 9) : Math.hypot(h.x - x, h.y - y) <= 7) return { d, i, w: h.kind === 'w' ? h : null };
      }
    }
    return null;
  }
  hitDrawing(x, y) {
    const ds = this.drawings;
    for (let k = ds.length - 1; k >= 0; k--) {
      const d = ds[k]; if (d.hidden) continue;
      const g = this.geo.get(d);
      if (g && DRAW.hit(g, x, y)) return d;
    }
    return null;
  }

  hitIndicator(x, y) {
    const pane = this.paneAt(y); if (!pane || x >= this.plotW || !this.series.length) return null;
    const idx = Math.round(this.xToIdx(x));
    const insts = pane.kind === 'main' ? this.overlays() : (pane.ind.visible === false ? [] : [pane.ind]);
    const dseg = (px, py, ax, ay, bx, by) => { const dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy; let t = l ? ((px - ax) * dx + (py - ay) * dy) / l : 0; t = Math.max(0, Math.min(1, t)); return Math.hypot(px - ax - t * dx, py - ay - t * dy); };
    for (let k = insts.length - 1; k >= 0; k--) {
      const inst = insts[k], d = IND.defs[inst.type], res = this.res.get(inst.id); if (!res) continue;
      if (d.vol && pane.kind === 'main' && this.volScale && this.volScale.inst === inst) {
        const v = res.v[idx], vs = this.volScale;
        if (v > 0 && y <= vs.base && y >= vs.base - v / vs.mx * vs.vh - 2) return inst;
        continue;
      }
      for (const o of d.o) {
        const arr = res[o.k]; if (!arr || o.t === 'vol') continue;
        const off = o.off ? o.off(inst.params) : 0;
        if (o.t === 'hist') {
          const v = arr[idx - off]; if (v !== v || v === undefined) continue;
          const y0 = this.priceToY(0, pane), yv = this.priceToY(v, pane);
          if (y >= Math.min(y0, yv) - 2 && y <= Math.max(y0, yv) + 2) return inst;
          continue;
        }
        for (let j = idx - 1; j <= idx; j++) {
          const a = arr[j - off], b = arr[j + 1 - off];
          if (a !== a || b !== b || a === undefined || b === undefined) continue;
          if (dseg(x, y, this.idxToX(j), this.priceToY(a, pane), this.idxToX(j + 1), this.priceToY(b, pane)) <= 5) return inst;
        }
      }
    }
    return null;
  }

  onDown(e) {
    if (e.button !== 0) return;
    const { x, y } = this.pos(e);
    this.app.setActive(this);
    U.closeMenus();
    if (!this.series.length) return;
    try { this.cv.setPointerCapture(e.pointerId); } catch { /* */ }
    const reg = this.region(x, y), tool = this.app.tool;
    if (this.app.replayPick === this && reg.r === 'plot') { this.app.replayBegin(this, this.xToIdx(x)); return; }
    if (this.ruler) { this.ruler = null; this.invalidate(); }
    if (e.shiftKey && reg.r === 'plot' && reg.pane === this.main && !this.creating) {
      const pt = this.snap(x, y);
      this.ruler = { type: 'dprange', pts: [pt, { ...pt }], style: { color: '#4f8cff' } };
      this.drag = { k: 'ruler' };
      this.invalidate();
      return;
    }
    if (DRAW.TOOLS[tool] && (reg.r === 'plot' && reg.pane === this.main || this.creating)) { this.drawDown(x, y); return; }
    if (reg.r === 'time') { this.drag = { k: 'tscale', x0: x, sp0: this.spacing }; return; }
    if (reg.r === 'price') {
      if (reg.pane === this.main) { this.priceAuto = false; this.drag = { k: 'pscale', y0: y, min0: this.pMin, max0: this.pMax }; }
      else if (reg.pane && reg.pane.kind === 'ind') this.drag = { k: 'iscale', ind: reg.pane.ind, y0: y, min0: reg.pane.min, max0: reg.pane.max };
      return;
    }
    if (reg.r === 'sep') {
      const a = this.panes[reg.k], b = this.panes[reg.k + 1];
      const wa = a.kind === 'main' ? (this.cfg.mainWeight || 3) : (a.ind.weight || 1), wb = b.ind.weight || 1;
      this.drag = { k: 'sep', a, b, y0: y, ha: a.h, hb: b.h, wsum: wa + wb };
      return;
    }
    if (reg.pane === this.main) {
      const pl = this.hitPriceLine(x, y);
      if (pl) {
        if (pl.x && pl.pl.onCancel) { pl.pl.onCancel(); return; }
        if (pl.pl.drag) { this.drag = { k: 'pline', pl: pl.pl }; return; }
      }
      const h = this.hitHandle(x, y);
      if (h) {
        if (tool === 'eraser') { this.app.deleteDrawing(this.sym, h.d); return; }
        this.app.pushUndo(this.sym);
        this.selected = h.d; this.app.onSelect(this);
        this.drag = { k: 'handle', d: h.d, i: h.i, w: h.w };
        return;
      }
      const d = this.hitDrawing(x, y);
      if (d) {
        if (tool === 'eraser') { this.app.deleteDrawing(this.sym, d); return; }
        this.selected = d; this.app.onSelect(this);
        if (!d.locked) { this.app.pushUndo(this.sym); this.drag = { k: 'move', d, x0: x, y0: y, orig: d.pts.map(p => ({ ...p })) }; }
        this.invalidate();
        return;
      }
      if (this.selected) { this.selected = null; this.app.onSelect(this); }
    }
    if (reg.r === 'plot') {
      const ih = this.hitIndicator(x, y);
      if (ih) this.app.selectIndicator(this, ih);
      else if (this.selInd) this.app.selectIndicator(this, null);
    }
    this.inertia = null; this.zAnim = null;
    const ip = reg.pane && reg.pane.kind === 'ind' ? reg.pane : null;
    this.drag = { k: 'pan', x0: x, y0: y, ri0: this.rightIndex, min0: this.pMin, max0: this.pMax, hist: [{ x, t: performance.now() }],
      ind: ip ? ip.ind : null, ih: ip ? ip.h : 0, imin0: ip ? ip.min : 0, imax0: ip ? ip.max : 0 };
  }

  onMove(e) {
    const { x, y } = this.pos(e);
    this.mouse = { x, y };
    if (this.creating) { this.drawMove(x, y); this.invalidate(); this.syncX(); return; }
    const dr = this.drag;
    if (dr) {
      switch (dr.k) {
        case 'pan': {
          this.rightIndex = this.clampRI(dr.ri0 - (x - dr.x0) / this.spacing);
          dr.hist.push({ x, t: performance.now() }); if (dr.hist.length > 6) dr.hist.shift();
          if (dr.ind) {
            if (dr.ind.scale) { const dv = (y - dr.y0) / (dr.ih || 1) * (dr.imax0 - dr.imin0); dr.ind.scale = { min: dr.imin0 + dv, max: dr.imax0 + dv }; dr.iMoved = true; }
          } else if (!this.priceAuto) {
            const a = this.pf(dr.min0), z = this.pf(dr.max0), dv = (y - dr.y0) / this.main.h * (z - a);
            this.pMin = this.pinv(a + dv); this.pMax = this.pinv(z + dv);
          }
          this.maybeLoadMore();
          this.cv.style.cursor = 'grabbing';
          break;
        }
        case 'tscale': this.spacing = U.clamp(dr.sp0 * Math.exp((x - dr.x0) * 0.006), 0.5, 80); this.maybeLoadMore(); break;
        case 'pscale': {
          const f = Math.exp((y - dr.y0) * 0.004), a = this.pf(dr.min0), z = this.pf(dr.max0), c = (a + z) / 2, hf = (z - a) / 2 * f;
          this.pMin = this.pinv(c - hf); this.pMax = this.pinv(c + hf);
          break;
        }
        case 'iscale': { // растянуть / сжать шкалу индикатора
          const f = Math.exp((y - dr.y0) * 0.004), c = (dr.min0 + dr.max0) / 2, hf = (dr.max0 - dr.min0) / 2 * f;
          dr.ind.scale = { min: c - hf, max: c + hf };
          break;
        }
        case 'sep': {
          const sum = dr.ha + dr.hb, nh = U.clamp(dr.ha + (y - dr.y0), 40, sum - 40);
          const wa = dr.wsum * nh / sum, wb = dr.wsum - wa;
          if (dr.a.kind === 'main') this.cfg.mainWeight = wa; else dr.a.ind.weight = wa;
          dr.b.ind.weight = wb;
          this.layoutDirty = true;
          break;
        }
        case 'handle': {
          dr.moved = true;
          const pt = this.snap(x, y), d = dr.d;
          if (dr.w) { // стрелки ◀▶: меняется только ширина (время), цены не трогаем
            const h = dr.w;
            if (h.pos && h.side === 'r') {
              const t = Math.max(pt.t, this.idxToTime(this.timeToIdx(d.pts[0].t) + 1));
              d.pts[1].t = d.pts[2].t = t;
              if (d.acct) d.acct.ext = t - Date.now(); // для сделок с биржи — запоминаем, насколько дальше «сейчас»
            } else if (h.pos) {
              d.pts[0].t = Math.min(pt.t, this.idxToTime(this.timeToIdx(d.pts[1].t) - 1));
            } else d.pts[h.pi].t = pt.t;
            this.app.drawingsChanged(this.sym, false);
            break;
          }
          if (dr.i === 0 && d.entries && d.entries.length) { const dp = pt.p - d.pts[0].p; d.entries.forEach(en => en.p += dp); }
          if (dr.i === 1 && d.tps && d.tps.length) { const dp = pt.p - d.pts[1].p; d.tps.forEach(t => t.p += dp); }
          d.pts[dr.i] = pt;
          if (d.type === 'long' || d.type === 'short') { if (dr.i === 1) d.pts[2].t = pt.t; if (dr.i === 2) d.pts[1].t = pt.t; }
          this.app.drawingsChanged(this.sym, false);
          break;
        }
        case 'move': {
          dr.moved = true;
          const dIdx = Math.round((x - dr.x0) / this.spacing), dy = y - dr.y0;
          dr.d.pts = dr.orig.map(p => ({ t: this.idxToTime(this.timeToIdx(p.t) + dIdx), p: this.yToPrice(this.priceToY(p.p) + dy) }));
          this.app.drawingsChanged(this.sym, false);
          break;
        }
        case 'pline': dr.moved = true; dr.pl.drag(this.yToPrice(y)); break;
        case 'ruler': if (this.ruler) this.ruler.pts[1] = this.snap(x, y); break;
      }
      this.invalidate(); this.syncX();
      return;
    }
    this.updateHover(x, y);
    this.invalidate(); this.syncX();
  }

  onUp(e) {
    const { x, y } = this.pos(e);
    try { this.cv.releasePointerCapture(e.pointerId); } catch { /* */ }
    if (this.creating) { this.drawUp(x, y); return; }
    const dr = this.drag; this.drag = null;
    if (!dr) return;
    if (dr.k === 'pan' && dr.hist && this.app.state.settings.inertia !== false) {
      const now = performance.now(), h = dr.hist.filter(p => now - p.t < 120);
      if (h.length >= 2) {
        const a = h[0], b = h[h.length - 1], vx = (b.x - a.x) / Math.max(1, b.t - a.t);
        const sp = this.app.state.settings.speed ?? 0.5;
        if (Math.abs(vx) > 0.4) { this.inertia = { vx: U.clamp(vx * 0.6 * sp * 2, -3, 3) }; this.runAnim(); }
      }
    }
    if (dr.k === 'handle' || dr.k === 'move') {
      if (dr.moved) { if (dr.d) dr.d.ai = false; this.app.drawingsChanged(this.sym, true); } else this.app.popUndo();
    }
    if (dr.k === 'pline' && dr.moved && dr.pl.commit) dr.pl.commit();
    if (dr.k === 'sep' || dr.k === 'iscale' || dr.iMoved) this.app.saveSoon();
    this.updateHover(x, y);
  }

  updateHover(x, y) {
    const reg = this.region(x, y), tool = this.app.tool;
    let cur = tool === 'arrow' ? 'default' : 'crosshair', hov = null;
    if (reg.r === 'time') cur = 'ew-resize';
    else if (reg.r === 'price') cur = reg.pane ? 'ns-resize' : 'default';
    else if (reg.r === 'sep') cur = 'row-resize';
    else if (reg.pane === this.main && !DRAW.TOOLS[tool]) {
      const pl = this.hitPriceLine(x, y);
      if (pl) cur = pl.x ? 'pointer' : (pl.pl.drag ? 'ns-resize' : cur);
      else { const hh = this.hitHandle(x, y); if (hh) cur = hh.w ? 'ew-resize' : 'move'; else { hov = this.hitDrawing(x, y); if (hov) cur = tool === 'eraser' ? 'not-allowed' : 'pointer'; else if (this.hitIndicator(x, y)) cur = 'pointer'; } }
    } else if (reg.r === 'plot' && !DRAW.TOOLS[tool] && this.hitIndicator(x, y)) cur = 'pointer';
    if (hov !== this.hover) { this.hover = hov; }
    this.cv.style.cursor = cur;
  }

  onWheel(e) {
    e.preventDefault();
    if (!this.series.length) return;
    const { x, y } = this.pos(e), reg = this.region(x, y);
    const unit = e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? 300 : 1;
    if (Math.abs(e.deltaX) > Math.abs(e.deltaY) || (e.shiftKey && !e.ctrlKey)) {
      const d = (Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY) * unit;
      this.stopInertia(); this.zAnim = null;
      this.rightIndex = this.clampRI(this.rightIndex + d * (this.app.state.settings.speed ?? 0.5) / this.spacing);
      this.maybeLoadMore();
    } else if (reg.r === 'price' && reg.pane && reg.pane.kind === 'ind') {
      const p = reg.pane, f = Math.exp(e.deltaY * 0.002), c = (p.min + p.max) / 2, hf = (p.max - p.min) / 2 * f;
      p.ind.scale = { min: c - hf, max: c + hf }; this.app.saveSoon();
    } else if (reg.r === 'price' && reg.pane === this.main) {
      this.priceAuto = false;
      const f = Math.exp(e.deltaY * 0.002), a = this.pf(this.pMin), z = this.pf(this.pMax), c = (a + z) / 2, hf = (z - a) / 2 * f;
      this.pMin = this.pinv(c - hf); this.pMax = this.pinv(c + hf);
    } else {
      const dy = U.clamp(e.deltaY * unit, -300, 300);
      const sp = this.app.state.settings.speed ?? 0.5;
      this.zoom(Math.exp(-dy * (e.ctrlKey ? 0.006 : 0.0018) * sp), Math.min(x, this.plotW));
      return;
    }
    this.invalidate();
  }

  onDbl(e) {
    if (this.finishPath()) return;
    const { x, y } = this.pos(e), reg = this.region(x, y);
    if (reg.r === 'time') { this.resetView(); this.invalidate(); return; }
    if (reg.r === 'price') {
      if (reg.pane && reg.pane.kind === 'ind') { reg.pane.ind.scale = null; this.app.saveSoon(); }
      else this.priceAuto = true;
      this.invalidate(); return;
    }
    if (reg.r === 'plot' && reg.pane === this.main) {
      const d = this.hitDrawing(x, y);
      if (d) { this.selected = d; this.app.onSelect(this); this.app.openDrawingSettings(this.sym, d); return; }
    }
    if (reg.r === 'plot') { const ih = this.hitIndicator(x, y); if (ih) { this.app.openIndSettings(this, ih); return; } }
    if (reg.r === 'plot' && !DRAW.TOOLS[this.app.tool]) this.app.toggleMax(this);
  }

  onContext(e) {
    const { x, y } = this.pos(e), reg = this.region(x, y);
    this.app.setActive(this);
    if (this.creating) { if (!this.finishPath()) { this.creating = null; this.invalidate(); } return; }
    const hit = {};
    if (reg.r === 'plot' && reg.pane === this.main) {
      hit.drawing = this.hitDrawing(x, y);
      hit.price = this.yToPrice(y);
    }
    if (reg.r === 'plot' && !hit.drawing) { const ih = this.hitIndicator(x, y); if (ih) { hit.ind = ih; this.app.selectIndicator(this, ih); } }
    this.app.showChartMenu(this, e.clientX, e.clientY, hit);
  }

  syncX() {
    if (!this.app.state.settings.syncCross) return;
    const t = this.mouse && this.mouse.x < this.plotW ? this.idxToTime(Math.round(this.xToIdx(this.mouse.x))) : null;
    this.app.crossFrom(this, t);
  }

  // ---------- создание рисунков ----------
  drawDown(x, y) {
    const tool = this.app.tool, T = DRAW.TOOLS[tool], pt = this.snap(x, y);
    if (this.creating) {
      const d = this.creating.d;
      if (this.creating.brush) return;
      d.pts[d.pts.length - 1] = pt;
      if (d.pts.length >= (T.n < 0 ? Infinity : T.n)) this.finishCreate(); else d.pts.push({ ...pt });
      this.invalidate();
      return;
    }
    const d = { id: U.uid(), type: tool, pts: [pt], style: { ...(this.app.state.toolStyles[tool] || DRAW.defaultStyle(tool)) } };
    if (tool === 'brush' || tool === 'highlighter') { this.creating = { d, brush: true, lx: x, ly: y }; d.pts = [{ t: this.idxToTime(this.xToIdx(x)), p: this.yToPrice(y) }]; return; }
    if (T.n === 1) { DRAW.init1(this, d); this.creating = { d }; this.finishCreate(); return; }
    d.pts.push({ ...pt });
    this.creating = { d, x0: x, y0: y, first: true };
    this.invalidate();
  }
  drawMove(x, y) {
    const c = this.creating;
    if (c.brush) {
      if (!this.drag && Math.hypot(x - c.lx, y - c.ly) >= 2) {
        c.d.pts.push({ t: this.idxToTime(this.xToIdx(x)), p: this.yToPrice(y) });
        c.lx = x; c.ly = y;
      }
      return;
    }
    c.d.pts[c.d.pts.length - 1] = this.snap(x, y);
  }
  drawUp(x, y) {
    const c = this.creating;
    if (c.brush) { this.finishCreate(); return; }
    if (c.first) {
      c.first = false;
      if (Math.hypot(x - c.x0, y - c.y0) > 6) {
        const T = DRAW.TOOLS[c.d.type];
        c.d.pts[c.d.pts.length - 1] = this.snap(x, y);
        if (c.d.pts.length >= (T.n < 0 ? Infinity : T.n)) this.finishCreate(); else c.d.pts.push({ ...this.snap(x, y) });
      }
    }
    this.invalidate();
  }
  // завершить ломаную (двойной клик, Enter, Esc или правый клик)
  finishPath() {
    const c = this.creating; if (!c || c.d.type !== 'path') return false;
    const pts = c.d.pts.slice(0, -1).filter((p, i, a) => !i || p.t !== a[i - 1].t || p.p !== a[i - 1].p);
    if (pts.length < 2) { this.creating = null; this.invalidate(); return true; }
    c.d.pts = pts;
    this.finishCreate();
    return true;
  }
  finishCreate() {
    const d = this.creating.d;
    this.creating = null;
    if ((d.type === 'brush' || d.type === 'highlighter') && d.pts.length < 2) { this.invalidate(); return; }
    this.app.addDrawing(this.sym, d, this);
  }
}
