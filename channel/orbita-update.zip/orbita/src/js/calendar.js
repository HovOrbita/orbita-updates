'use strict';
// Календарь важных событий для крипты: решения ФРС, инфляция США (CPI), занятость (NFP) + свои события.
// Даты — из официальных расписаний ФРС и Бюро трудовой статистики США (время там — восточное, ET);
// здесь всё пересчитывается в ваше местное время с учётом перехода США на летнее время.
const Calendar = (() => {
  // переход США на летнее время: со 2-го воскресенья марта по 1-е воскресенье ноября
  function nthSunday(y, m, n) { const d = new Date(Date.UTC(y, m, 1)); const first = (7 - d.getUTCDay()) % 7 + 1; return first + (n - 1) * 7; }
  function etToUtc(y, m, d, hh, mm) {
    const start = Date.UTC(y, 2, nthSunday(y, 2, 2)), end = Date.UTC(y, 10, nthSunday(y, 10, 1));
    const day = Date.UTC(y, m - 1, d), off = day >= start && day < end ? 4 : 5;
    return Date.UTC(y, m - 1, d, hh + off, mm);
  }
  const ev = (date, hh, mm, kind, title, imp, note) => { const [y, m, d] = date.split('-').map(Number); return { id: `${kind}-${date}`, t: etToUtc(y, m, d, hh, mm), kind, title, imp, note, builtin: true }; };
  const FOMC = ['2026-12-09', '2027-01-27', '2027-03-17', '2027-04-28', '2027-06-09', '2027-07-28', '2027-09-15', '2027-11-17', '2028-01-26'];
  const CPI = ['2026-12-10', '2027-01-13', '2027-02-11', '2027-03-10', '2027-04-13', '2027-05-12', '2027-06-10', '2027-07-14', '2027-08-11', '2027-09-14', '2027-10-14', '2027-11-10', '2027-12-10'];
  const NFP = ['2026-12-04', '2027-01-08', '2027-02-05', '2027-03-05', '2027-04-02', '2027-05-07', '2027-06-04', '2027-07-02', '2027-08-06', '2027-09-03', '2027-10-08', '2027-11-05', '2027-12-03'];
  const BUILTIN = [
    ...FOMC.map(d => ev(d, 14, 0, 'fomc', 'Решение по ставке', 3, 'В 14:30 по Вашингтону — пресс-конференция главы ФРС. Самое сильное событие для крипты.')),
    ev('2027-10-27', 14, 0, 'fomc', 'Заседание по стратегии', 1, 'В этот раз решения по ставке не будет — обсуждают долгосрочную стратегию.'),
    ...CPI.map(d => ev(d, 8, 30, 'cpi', 'Инфляция США', 3, 'Выше ожиданий — обычно давит на крипту, ниже — помогает.')),
    ...NFP.map(d => ev(d, 8, 30, 'nfp', 'Занятость США', 2, 'Отчёт о рабочих местах — часто резкое движение в первые минуты.')),
  ];
  const KIND = { fomc: { ic: 'ФРС', c: '#e8c547' }, cpi: { ic: 'CPI', c: '#f0556a' }, nfp: { ic: 'NFP', c: '#5b8def' }, own: { ic: '★', c: '#b48cff' } };
  const say = { 60: 'через час', 15: 'через 15 минут' };

  const own = () => App.state.events || (App.state.events = []);
  function all() { return BUILTIN.concat(own().map(e => ({ ...e, kind: 'own', imp: e.imp || 2 }))).sort((a, b) => a.t - b.t); }
  function cfg() { const st = App.state.settings; return st.cal || (st.cal = { voice: true, chip: true }); }

  function left(ms) {
    const m = Math.round(ms / 6e4);
    if (m < 1) return 'сейчас';
    if (m < 60) return `${m} мин`;
    const h = Math.floor(m / 60), mm = m % 60;
    if (h < 24) return `${h} ч ${mm} мин`;
    const d = Math.floor(h / 24), hh = h % 24;
    return `${d} д ${hh} ч`;
  }
  const dayName = t => new Date(t).toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'long' });
  const hm = t => new Date(t).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

  // ---------- вкладка в правой панели ----------
  function isOpen() { const st = App.state.settings; const side = document.getElementById('side'); return !!(st.sideOpen && st.sidePanel === 'cal' && side && !side.classList.contains('auto-hidden')); }
  function render() {
    if (!isOpen()) return;
    const b = Panels.body(), now = Date.now();
    const list = all().filter(e => e.t > now - 6 * 36e5 && e.t < now + 62 * 864e5);
    let html = `<div class="sp-head"><span>Календарь событий</span><button class="ib" id="calAdd" title="Добавить своё событие">${U.icon('plus')}</button></div><div class="cal-list">`;
    if (!list.length) html += '<div class="np-note">Ближайших событий нет. Добавьте своё кнопкой «+».</div>';
    let lastDay = '';
    for (const e of list) {
      const d = dayName(e.t); if (d !== lastDay) { html += `<div class="cal-day">${U.esc(d)}</div>`; lastDay = d; }
      const k = KIND[e.kind] || KIND.own, past = e.t < now, soon = !past && e.t - now < 864e5;
      html += `<div class="cal-row${past ? ' past' : ''}${soon ? ' soon' : ''}" title="${U.esc(e.note || '')}">
        <span class="cal-t">${hm(e.t)}</span>
        <span class="cal-main"><span class="cal-top"><span class="cal-k" style="color:${k.c};border-color:${k.c}">${k.ic}</span><span class="cal-n">${U.esc(e.title)}</span><span class="cal-imp">${'●'.repeat(e.imp || 1)}</span></span>
          <span class="cal-l">${past ? 'прошло' : 'через ' + left(e.t - now)}</span></span>
        ${e.kind === 'own' ? `<button class="ib xs cal-del" data-id="${U.esc(e.id)}" title="Удалить">${U.icon('close', 12)}</button>` : '<span></span>'}</div>`;
    }
    html += `</div><div class="cal-foot"><label class="chk"><input type="checkbox" id="calVoice"${cfg().voice !== false ? ' checked' : ''}> Напоминать голосом за час и за 15 мин</label><div>Даты: ФРС и Бюро трудовой статистики США. Время — ваше местное.</div></div>`;
    const keep = b.querySelector('.cal-list'), sc = keep ? keep.scrollTop : 0;
    b.innerHTML = html;
    const nl = b.querySelector('.cal-list'); if (nl) nl.scrollTop = sc;
    b.querySelector('#calAdd').onclick = () => addOwn();
    b.querySelector('#calVoice').onchange = ev => { cfg().voice = ev.target.checked; App.saveSoon(); };
    b.querySelectorAll('.cal-del').forEach(x => x.onclick = () => { App.state.events = own().filter(y => y.id !== x.dataset.id); App.saveSoon(); render(); chip(); });
  }
  async function addOwn() {
    const name = await U.prompt('Название события (например: разлок токена ARB)', '');
    if (!name || !name.trim()) return;
    const def = new Date(Date.now() + 864e5); def.setMinutes(0, 0, 0);
    const pad = n => String(n).padStart(2, '0');
    const when = await U.prompt('Дата и время (ваше местное), формат ДД.ММ.ГГГГ ЧЧ:ММ', `${pad(def.getDate())}.${pad(def.getMonth() + 1)}.${def.getFullYear()} ${pad(def.getHours())}:00`);
    if (!when) return;
    const m = /^\s*(\d{1,2})\.(\d{1,2})\.(\d{4})\s+(\d{1,2}):(\d{2})\s*$/.exec(when);
    if (!m) { U.toast('Не понял дату. Пример: 25.12.2026 15:30', 'error', 3500); return; }
    const t = new Date(+m[3], +m[2] - 1, +m[1], +m[4], +m[5]).getTime();
    if (!isFinite(t)) { U.toast('Неверная дата', 'error'); return; }
    own().push({ id: U.uid(), title: name.trim(), t, imp: 2 });
    App.saveSoon(); render(); chip();
    U.toast(`Событие добавлено: ${name.trim()}, ${dayName(t)} ${hm(t)}`, 'info', 3000);
  }
  // открыть вкладку календаря справа (так же, как клик по её значку)
  function toggle(v) {
    const btn = document.querySelector('#side-rail [data-tab="cal"]');
    const want = v === undefined ? !isOpen() : v;
    if (want === isOpen()) return;
    if (btn) btn.click();
  }

  // ---------- плашка в верхней панели: ближайшее важное событие в пределах суток ----------
  function chip() {
    const el = document.getElementById('calChip'); if (!el) return;
    const now = Date.now(), next = all().find(e => e.t > now - 30 * 6e4 && e.t < now + 864e5 && (e.imp || 1) >= 2);
    if (!next || cfg().chip === false) { el.hidden = true; return; }
    const k = KIND[next.kind] || KIND.own, inPast = next.t <= now;
    el.hidden = false;
    el.innerHTML = `<span class="cc-dot" style="background:${k.c}"></span>${U.esc(k.ic === '★' ? next.title : k.ic)} · ${inPast ? 'идёт сейчас' : left(next.t - now)}`;
    el.title = `${next.title} — ${dayName(next.t)} в ${hm(next.t)}${next.note ? '\n' + next.note : ''}\nНажмите, чтобы открыть календарь`;
    el.classList.toggle('hot', !inPast && next.t - now < 60 * 6e4);
  }

  // ---------- напоминания (только главное окно) ----------
  const fired = new Set();
  function tick() {
    chip(); render();
    if (!App.isMain) return;
    const now = Date.now();
    for (const e of all()) {
      for (const mins of [60, 15]) {
        const at = e.t - mins * 6e4, key = e.id + ':' + mins;
        if (now >= at && now < at + 90 * 1000 && !fired.has(key)) {
          fired.add(key);
          if ((e.imp || 1) < 2 && e.kind !== 'own') continue;
          U.toast(`${e.title} — ${say[mins]} (в ${hm(e.t)})`, 'alert', 15000);
          if (cfg().voice !== false && typeof Voice !== 'undefined' && Voice.remind) Voice.remind(`Внимание: ${e.title}, ${say[mins]}.`);
        }
      }
    }
  }
  function init() {
    const el = document.getElementById('calChip');
    if (el) el.onclick = () => toggle(true);
    tick(); setInterval(tick, 20000);
  }
  return { init, toggle, render, get open() { return isOpen(); }, all, etToUtc };
})();
