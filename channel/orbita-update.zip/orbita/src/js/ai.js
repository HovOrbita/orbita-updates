'use strict';
// AI-разметка: автоматические уровни (зоны) и трендовые линии.
// Логика перенесена из скринера пробоев (levels.py): зоны по разворотам с учётом старшего ТФ,
// уровни рядом с ценой сверху и снизу, трендовые линии по кончикам теней без пересечения телами.
const AI = (() => {
  const CFG = {
    ATR_PERIOD: 14, CANDLES: 300,
    ZONE_PIVOT: 3, ZONE_CLUSTER_ATR: 0.6, ZONE_MIN_TOUCHES_KEY: 3, ZONE_REACT_ATR: 1.2, ZONE_REACT_BARS: 12,
    ZONE_MAX_CROSSES: 3, ZONE_MAX_H_ATR: 0.4, ZONES_MAX: 3, NEAR_ZONE_ATR: 6.0, NEAR_ZONE_GAP_ATR: 1.5,
    HTF_WEIGHT: 1.5, ZONE_MERGE_ATR: 1.2, ZONE_MIN_GAP_ATR: 2.5,
    TL_LOOKBACK: 150, TL_TOUCH_ATR: 0.3, TL_PIERCE_ATR: 0.6, TL_MIN_GAP: 5, TL_MIN_SLOPE_ATR: 0.01,
    TL_MIN_TRAVEL_ATR: 1.5, TL_MAX_SLOPE_ATR: 0.8, TL_MAX_PER_SIDE: 2, TL_MAX_DIST_ATR: 4.0,
  };
  // старший ТФ для зон (как в скринере, дополнено для остальных интервалов Orbita)
  const HIGHER = { '1m': '15m', '3m': '1h', '5m': '1h', '15m': '1h', '30m': '4h', '1h': '4h', '2h': '1d', '4h': '1d', '6h': '1d', '8h': '1d', '12h': '1d', '1d': '1w' };

  const maxIdx = (lo, hi, f) => { let b = lo; for (let m = lo + 1; m < hi; m++) if (f(m) > f(b)) b = m; return b; };
  const minIdx = (lo, hi, f) => { let b = lo; for (let m = lo + 1; m < hi; m++) if (f(m) < f(b)) b = m; return b; };

  function atr(c, period = CFG.ATR_PERIOD) {
    if (c.length < period + 1) return 0;
    const trs = [];
    for (let i = 1; i < c.length; i++) { const h = c[i].h, l = c[i].l, pc = c[i - 1].c; trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc))); }
    let a = trs.slice(0, period).reduce((s, x) => s + x, 0) / period;
    for (const tr of trs.slice(period)) a = (a * (period - 1) + tr) / period; // сглаживание Уайлдера
    return a;
  }

  function isRound(lo, hi, ref) {
    if (ref <= 0) return false;
    const m = 10 ** (Math.floor(Math.log10(ref)) - 1) * 5;
    return Math.ceil(lo / m) * m <= hi;
  }

  // кандидаты в ключевые зоны: экстремумы с реальным отскоком, кластеры, сила
  function zoneCandidates(c, a, reactAtr, minTouches, hAtr) {
    if (a <= 0 || c.length < 30) return [];
    const k = CFG.ZONE_PIVOT, R = CFG.ZONE_REACT_BARS, react = a * (reactAtr || CFG.ZONE_REACT_ATR);
    minTouches = minTouches || CFG.ZONE_MIN_TOUCHES_KEY;
    const n = c.length, pts = [];
    for (let i = k; i < n - k; i++) {
      const win = c.slice(i - k, i + k + 1), nxt = c.slice(i + 1, i + 1 + R);
      if (c[i].h === Math.max(...win.map(x => x.h))) {
        const r = c[i].h - Math.min(...nxt.map(x => x.l));
        if (r >= react) pts.push([c[i].h, Math.max(c[i].o, c[i].c), i, 'H', r]);
      }
      if (c[i].l === Math.min(...win.map(x => x.l))) {
        const r = Math.max(...nxt.map(x => x.h)) - c[i].l;
        if (r >= react) pts.push([c[i].l, Math.min(c[i].o, c[i].c), i, 'L', r]);
      }
    }
    pts.sort((p, q) => p[0] - q[0] || p[1] - q[1] || p[2] - q[2]);
    const tol = a * CFG.ZONE_CLUSTER_ATR, clusters = []; let cur = [];
    for (const p of pts) { if (cur.length && p[0] - cur[0][0] > tol) { clusters.push(cur); cur = []; } cur.push(p); }
    if (cur.length) clusters.push(cur);

    const maxH = hAtr || a * CFG.ZONE_MAX_H_ATR, minH = Math.min(a * 0.08, maxH * 0.5), zones = [];
    for (const cl of clusters) {
      if (cl.length < minTouches) continue;
      const hs = cl.filter(p => p[3] === 'H'), ls = cl.filter(p => p[3] === 'L'), mirror = hs.length > 0 && ls.length > 0;
      const ext = cl.map(p => p[0]).sort((x, y) => x - y);
      let top, bottom;
      if (hs.length >= 2 * ls.length) { // сопротивление: от теней вниз до тел
        top = ext[Math.floor(0.8 * (ext.length - 1))];
        const bodies = hs.map(p => p[1]).sort((x, y) => x - y);
        bottom = Math.max(bodies[Math.floor(bodies.length / 2)], top - maxH);
      } else if (ls.length >= 2 * hs.length) { // поддержка: от теней вверх до тел
        bottom = ext[Math.floor(0.2 * (ext.length - 1))];
        const bodies = ls.map(p => p[1]).sort((x, y) => x - y);
        top = Math.min(bodies[Math.floor(bodies.length / 2)], bottom + maxH);
      } else { // зеркальная
        const mid = ext[Math.floor(ext.length / 2)], q1 = ext[Math.floor(ext.length / 4)], q3 = ext[Math.floor(3 * ext.length / 4)];
        const half = Math.min(Math.max((q3 - q1) / 2, minH / 2), maxH / 2);
        bottom = mid - half; top = mid + half;
      }
      if (top - bottom < minH) { const m = (top + bottom) / 2; bottom = m - minH / 2; top = m + minH / 2; }
      const mid = (top + bottom) / 2;
      const first = Math.min(...cl.map(p => p[2])), last = Math.max(...cl.map(p => p[2]));
      let crosses = 0;
      for (let m = first; m < n; m++) { const x = c[m]; if (Math.min(x.o, x.c) < mid && mid < Math.max(x.o, x.c)) crosses++; }
      if (crosses > Math.max(CFG.ZONE_MAX_CROSSES, cl.length)) continue;
      const bounce = cl.reduce((s, p) => s + Math.min(p[4] / a, 4), 0) / 2;
      const strength = cl.length + bounce + (mirror ? 2 : 0) + 3 * last / n + (isRound(bottom, top, mid) ? 1 : 0) - 0.7 * crosses;
      zones.push({ price: mid, top, bottom, touches: cl.length, mirror, t0: c[first].t, tLast: c[last].t,
        strength: Math.round(strength * 100) / 100, label: `зона ×${cl.length}` + (mirror ? ' ⇅' : '') });
    }
    return zones;
  }

  function mergeZones(zones, a) {
    zones = zones.slice().sort((x, y) => x.price - y.price);
    const merged = [];
    for (const z of zones) {
      const m = merged[merged.length - 1];
      if (m && z.price - m.price < a * CFG.ZONE_MERGE_ATR) {
        const [main] = m.strength >= z.strength ? [m, z] : [z, m];
        const nz = { ...main };
        nz.touches = m.touches + z.touches; nz.t0 = Math.min(m.t0, z.t0);
        nz.strength = Math.round((m.strength + z.strength * 0.5) * 100) / 100;
        nz.mirror = m.mirror || z.mirror;
        const pre = main.label.split('зона')[0];
        nz.label = `${pre}зона ×${nz.touches}` + (nz.mirror ? ' ⇅' : '');
        merged[merged.length - 1] = nz;
      } else merged.push({ ...z });
    }
    return merged;
  }

  function selectZones(zones, a, price) {
    const gap = a * CFG.ZONE_MIN_GAP_ATR, pick = [];
    const ok = z => pick.every(p => Math.abs(z.price - p.price) >= gap);
    const inside = zones.filter(z => z.bottom <= price && price <= z.top);
    const above = zones.filter(z => z.bottom > price).sort((x, y) => x.bottom - y.bottom);
    const below = zones.filter(z => z.top < price).sort((x, y) => y.top - x.top);
    if (inside.length) pick.push(inside.reduce((b, z) => z.strength > b.strength ? z : b));
    for (const side of [above, below]) {
      const cand = side.slice(0, 3).filter(ok);
      if (cand.length) pick.push(cand.reduce((b, z) => z.strength > b.strength ? z : b));
    }
    for (const z of zones.slice().sort((x, y) => y.strength - x.strength)) {
      if (pick.length >= CFG.ZONES_MAX) break;
      if (!pick.includes(z) && ok(z)) pick.push(z);
    }
    return pick.slice(0, CFG.ZONES_MAX);
  }

  // уровень рядом с ценой есть всегда — и сверху, и снизу (флэт / лоу / хай)
  function nearZones(c, a, price, pick) {
    const near = CFG.NEAR_ZONE_ATR, gap = a * CFG.NEAR_ZONE_GAP_ATR, added = [];
    const free = z => pick.concat(added).every(x => Math.abs(z.price - x.price) >= gap && !(x.bottom <= z.price && z.price <= x.top));
    if (a <= 0 || c.length < 30) return [];
    for (const side of ['below', 'above']) {
      const onSide = z => side === 'below' ? z.top < price : z.bottom > price;
      if (!pick.some(z => onSide(z) && Math.abs(z.price - price) <= near * a)) {
        const soft = mergeZones(zoneCandidates(c, a, 0.6, 2), a).filter(z => onSide(z) && Math.abs(z.price - price) <= near * a && free(z));
        if (soft.length) {
          const z = soft.reduce((b, x) => Math.abs(x.price - price) < Math.abs(b.price - price) ? x : b);
          z.soft = true; z.label = z.label.replace('зона', 'флэт'); added.push(z);
        }
      }
      const k = side === 'below' ? minIdx(0, c.length, m => c[m].l) : maxIdx(0, c.length, m => c[m].h), x = c[k];
      let bot, top;
      if (side === 'below' && x.l < price) { bot = x.l; top = Math.min(Math.min(x.o, x.c), x.l + a * CFG.ZONE_MAX_H_ATR); }
      else if (side === 'above' && x.h > price) { bot = Math.max(Math.max(x.o, x.c), x.h - a * CFG.ZONE_MAX_H_ATR); top = x.h; }
      else continue;
      top = Math.max(top, bot + a * 0.08);
      const z = { price: (top + bot) / 2, top, bottom: bot, touches: 1, mirror: false, t0: x.t, tLast: x.t, strength: 4, soft: true, extreme: true, label: side === 'below' ? 'лоу' : 'хай' };
      if (Math.abs(z.price - price) <= near * a && free(z)) added.push(z);
    }
    return added;
  }

  function keyZones(c, a, price, htf, htfName) {
    const zones = zoneCandidates(c, a);
    if (htf && htf.length >= 30) {
      const ah = atr(htf);
      for (const z of zoneCandidates(htf, ah, null, null, a * CFG.ZONE_MAX_H_ATR * 1.25)) {
        z.strength = Math.round(z.strength * CFG.HTF_WEIGHT * 100) / 100;
        z.label = `${htfName} ${z.label}`; z.htf = true; zones.push(z);
      }
    }
    const pick = selectZones(mergeZones(zones, a), a, price);
    return pick.concat(nearZones(c, a, price, pick));
  }

  // трендовые линии «как руками»
  function trendlines(c, a) {
    const n = c.length;
    if (a <= 0 || n < 40) return [];
    const start = Math.max(0, n - CFG.TL_LOOKBACK), touch = a * CFG.TL_TOUCH_ATR, pierce = a * CFG.TL_PIERCE_ATR, out = [];
    for (const side of ['upper', 'lower']) {
      const key = side === 'upper' ? 'h' : 'l', up = side === 'upper';
      const pivSet = new Set();
      for (const k of [2, 4]) for (let i = Math.max(start, k); i < n - k; i++) {
        const win = c.slice(i - k, i + k + 1).map(x => x[key]);
        if (c[i][key] === (up ? Math.max(...win) : Math.min(...win))) pivSet.add(i);
      }
      const piv = [...pivSet].sort((x, y) => x - y);
      const extreme = up ? maxIdx(start, n, m => c[m].h) : minIdx(start, n, m => c[m].l);
      const cands = [];
      for (let ai = 0; ai < piv.length; ai++) {
        const i = piv[ai];
        for (const j of piv.slice(ai + 1)) {
          if (j - i < CFG.TL_MIN_GAP) continue;
          const slope = (c[j][key] - c[i][key]) / (j - i);
          if ((up && slope >= 0) || (!up && slope <= 0)) continue; // сверху — нисходящая, снизу — восходящая
          const sa = Math.abs(slope) / a;
          if (sa < CFG.TL_MIN_SLOPE_ATR || sa > CFG.TL_MAX_SLOPE_ATR) continue;
          if (Math.abs(slope) * (n - 1 - i) < a * CFG.TL_MIN_TRAVEL_ATR) continue;
          const base = c[i][key];
          let valid = true, pierces = 0;
          for (let m = i; m < n; m++) {
            const lv = base + slope * (m - i);
            const body = up ? Math.max(c[m].o, c[m].c) : Math.min(c[m].o, c[m].c);
            if ((up ? body - lv : lv - body) > 0.05 * a) { valid = false; break; } // тело за линией
            const overWick = up ? c[m][key] - lv : lv - c[m][key];
            if (overWick > pierce) { valid = false; break; }
            if (overWick > touch) pierces++;
          }
          if (!valid) continue;
          const touches = []; let lastT = -99;
          for (const m of piv) {
            if (m < i) continue;
            if (Math.abs(c[m][key] - (base + slope * (m - i))) <= touch && m - lastT >= 3) { touches.push(m); lastT = m; }
          }
          const nt = touches.length;
          if (nt < 2) continue;
          const span = touches[nt - 1] - touches[0], now = base + slope * (n - 1 - i);
          const dist = Math.abs(c[n - 1].c - now) / a;
          if (dist > CFG.TL_MAX_DIST_ATR) continue;
          const age = n - 1 - touches[nt - 1];
          const score = nt * 3 + Math.min(span, 120) / 20 - dist - pierces + (i === extreme ? 4 : 0) + 3 * touches[nt - 1] / n - Math.max(0, age - 60) / 15;
          cands.push({ score, i, slope, touches: nt, now });
        }
      }
      cands.sort((x, y) => y.score - x.score);
      const chosen = [];
      for (const d of cands) {
        if (chosen.length >= CFG.TL_MAX_PER_SIDE) break;
        if (chosen.some(x => Math.abs(d.slope - x.slope) < 0.4 * Math.abs(x.slope) || Math.abs(d.now - x.now) < 0.75 * a || Math.abs(d.i - x.i) < 5)) continue;
        if (chosen.length && d.touches < 3) continue; // вторую линию рисуем только подтверждённую
        chosen.push(d);
      }
      for (const d of chosen) {
        const confirmed = d.touches >= 3;
        out.push({ side, i: d.i, t0: c[d.i].t, p0: c[d.i][key], tNow: c[n - 1].t, pNow: d.now, touches: d.touches, confirmed,
          label: confirmed ? `тренд ×${d.touches}` : 'тренд? (2 касания)' });
      }
    }
    return out;
  }

  // ---------- рисование на графике ----------
  const COL = { res: '#e07a7a', sup: '#5cbf8f', mid: '#d9a94f' };
  function toDrawings(ch, zones, lines, price) {
    const lastT = ch.bars[ch.bars.length - 1].t, out = [];
    for (const z of zones) {
      const col = z.bottom > price ? COL.res : z.top < price ? COL.sup : COL.mid;
      const role = z.bottom > price ? 'сопр.' : z.top < price ? 'подд.' : 'в зоне';
      out.push({ id: U.uid(), type: 'rect', ai: true, pts: [{ t: z.t0, p: z.top }, { t: lastT, p: z.bottom }],
        style: { color: col, width: 1, dash: z.soft ? 1 : 0, fill: true, fa: z.soft ? 0.07 : 0.13, extend: true, label: `AI · ${role} ${z.label}` } });
    }
    for (const L of lines) {
      const col = L.side === 'upper' ? COL.res : COL.sup;
      out.push({ id: U.uid(), type: 'trend', ai: true, pts: [{ t: L.t0, p: L.p0 }, { t: L.tNow, p: L.pNow }],
        style: { color: col, width: L.confirmed ? 1.6 : 1.2, dash: L.confirmed ? 0 : 1, extR: true, label: `AI · ${L.label}` } });
    }
    return out;
  }

  async function run(app, ch) {
    if (!ch || !ch.bars || ch.bars.length < 60) { U.toast('Мало свечей для анализа — подождите загрузку графика', 'info', 2500); return; }
    if (ch.replay) { U.toast('AI-разметка недоступна в режиме повтора', 'info', 2500); return; }
    const all = ch.bars.slice(0, -1); // только закрытые свечи
    const c = all.slice(-(CFG.CANDLES + 1));
    const a = atr(c);
    if (!(a > 0)) { U.toast('Не удалось посчитать волатильность', 'error'); return; }
    const price = ch.bars[ch.bars.length - 1].c;
    let htf = null; const hName = HIGHER[ch.iv];
    if (hName) { try { htf = await Data.klinesLive(ch.sym, hName, CFG.CANDLES) || await Data.klines(ch.sym, hName, null, CFG.CANDLES); } catch { htf = null; } }
    const zones = keyZones(c, a, price, htf, hName || '');
    const lines = trendlines(c, a);
    const sym = ch.sym, arr = app.getDrawings(sym);
    app.pushUndo(sym);
    const keep = arr.filter(d => !d.ai);
    arr.length = 0; arr.push(...keep, ...toDrawings(ch, zones, lines, price));
    ch.selected = null;
    app.drawingsChanged(sym, true);
    const nz = zones.length, nl = lines.length;
    U.toast(nz || nl ? `AI: ${nz} ${plural(nz, 'уровень', 'уровня', 'уровней')}, ${nl} ${plural(nl, 'трендовая', 'трендовые', 'трендовых')}. Правый клик по кнопке AI — убрать` : 'AI: явных уровней и трендовых линий не найдено', 'info', 3500);
  }
  function clear(app, ch) {
    const arr = app.getDrawings(ch.sym), n = arr.filter(d => d.ai).length;
    if (!n) { U.toast('AI-разметки на графике нет'); return; }
    app.pushUndo(ch.sym);
    const keep = arr.filter(d => !d.ai); arr.length = 0; arr.push(...keep);
    ch.selected = null; app.drawingsChanged(ch.sym, true);
    U.toast(`AI-разметка убрана (${n})`, 'info', 2000);
  }
  function plural(n, a, b, c) { const m = n % 100, k = n % 10; return m > 10 && m < 20 ? c : k === 1 ? a : k >= 2 && k <= 4 ? b : c; }
  return { run, clear, atr, keyZones, trendlines, HIGHER, CFG };
})();
