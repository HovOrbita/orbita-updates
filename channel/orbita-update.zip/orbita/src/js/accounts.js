'use strict';
// Мои позиции с бирж (Binance, Bybit, Gate — фьючерсы USDT). Только чтение.
// Раз в 5 секунд забираем позиции (ордера — раз в 15 с) и сами рисуем длинную/короткую позицию на графике монеты:
// вход и размер с биржи, лимитки — как точки входа, тейки и стопы — из ваших ордеров.
const Acct = (() => {
  const EXN = { binance: 'Binance', bybit: 'Bybit', gate: 'Gate' };
  const EXS = { binance: 'BN', bybit: 'BY', gate: 'GT' };
  const has = () => !!(window.orbita && window.orbita.acctFetch);
  let list = [], status = {}, last = {}, orders = {}, tick = 0, timer = null, firstDone = {}, busy = false;

  async function refreshList() { if (!has()) return []; try { list = await window.orbita.acctList(); } catch { list = []; } return list; }
  const connected = () => list.filter(x => x.connected).map(x => x.ex);

  // ---------- сборка «групп»: биржа + монета + направление ----------
  function groups(ex, positions, ords) {
    const out = new Map();
    const get = (id, side) => { const k = `${ex}|${id}|${side}`; if (!out.has(k)) out.set(k, { key: k, ex, id, side, pos: null, limits: [], conds: [] }); return out.get(k); };
    for (const p of positions) get(p.id, p.side).pos = p;
    for (const o of ords || []) {
      if (o.kind === 'limit' && !o.reduce && o.price > 0) {
        // лимитка на вход: покупка → лонг, продажа → шорт
        get(o.id, o.side === 'buy' ? 'long' : 'short').limits.push(o);
      } else if (o.kind === 'cond' || o.reduce) {
        // закрывающий ордер: продажа закрывает лонг, покупка — шорт; направление неизвестно («вся позиция») — к открытой позиции этой монеты
        let side = o.side === 'sell' ? 'long' : o.side === 'buy' ? 'short' : '';
        if (!side) { const p = positions.find(x => x.id === o.id); side = p ? p.side : ''; }
        if (!side) continue;
        get(o.id, side).conds.push(o);
      }
    }
    // группы только из тейков/стопов без позиции и без лимиток — не рисуем
    for (const [k, g] of out) if (!g.pos && !g.limits.length) out.delete(k);
    return out;
  }

  function upsert(g) {
    const long = g.side === 'long', arr = App.getDrawings(g.id), now = Date.now();
    let d = arr.find(x => x.acct && x.acct.key === g.key && x.acct.open);
    const filled = g.pos ? [{ p: g.pos.entry, w: g.pos.notional || g.pos.qty * g.pos.entry }] : [];
    const pend = g.limits.map(o => ({ p: o.price, w: o.price * o.qty || 1 }));
    const ens = filled.concat(pend).filter(e => e.p > 0);
    if (!ens.length) return null;
    const tw = ens.reduce((a, e) => a + e.w, 0) || 1;
    const avg = ens.reduce((a, e) => a + e.p * e.w, 0) / tw, ref = g.pos ? g.pos.entry : avg;
    // тейки/стопы: с позиции (Bybit) или из закрывающих ордеров
    const tps = [], sls = [];
    for (const o of g.conds) {
      const px = o.trigger || o.price; if (!(px > 0)) continue;
      const isTp = o.tpsl ? o.tpsl === 'tp' : (long ? px > ref : px < ref);
      const w = o.qty || (g.pos ? g.pos.qty : 0) || 1; // «вся позиция» — весь объём
      const L = isTp ? tps : sls; if (!L.some(t => Math.abs(t.p - px) < px * 1e-9)) L.push({ p: px, w });
    }
    if (g.pos && g.pos.tp > 0 && !tps.some(t => Math.abs(t.p - g.pos.tp) < 1e-9)) tps.push({ p: g.pos.tp, w: 1 });
    if (g.pos && g.pos.sl > 0 && !sls.length) sls.push({ p: g.pos.sl, w: 1 });
    tps.sort((a, b) => long ? a.p - b.p : b.p - a.p);
    const tpFar = tps.length ? tps[tps.length - 1].p : null;
    const sl = sls.length ? (long ? Math.max(...sls.map(s => s.p)) : Math.min(...sls.map(s => s.p))) : null;
    const prevA = d && d.acct;
    const ext = prevA && Number.isFinite(prevA.ext) ? prevA.ext : 6 * 36e5; // ширину можно менять стрелками ↔
    const end0 = now + ext;
    // время открытия: точное (из истории сделок) — когда уже узнали; до этого — что дала биржа или момент, когда увидели
    const known = prevA && prevA.openAt;
    const guess = g.pos && g.pos.openTime > 0 && g.pos.openTime <= now && g.ex !== 'binance' ? g.pos.openTime : 0;
    const t0 = known || (d && d.pts[0].t) || guess || now;
    const acct = { key: g.key, ex: g.ex, exName: EXN[g.ex], open: true, qty: g.pos ? g.pos.qty : 0, entry: g.pos ? g.pos.entry : 0, upnl: g.pos ? g.pos.upnl : 0,
      mark: g.pos ? g.pos.mark : 0, lev: g.pos ? Math.round(g.pos.lev) || 0 : 0, liq: g.pos ? g.pos.liq : 0, notional: g.pos ? g.pos.notional : 0, upd: now,
      tpSet: !!tpFar, slSet: !!sl, tpN: tps.length, slN: sls.length, openAt: known || 0, openAsked: !!(prevA && prevA.openAsked), ext: prevA && Number.isFinite(prevA.ext) ? prevA.ext : undefined };
    const end = Math.max(end0, t0 + 60000);
    if (!d) {
      d = { id: U.uid(), type: long ? 'long' : 'short', pts: [{ t: t0, p: avg }, { t: end, p: tpFar || ref * (long ? 1.03 : 0.97) }, { t: end, p: sl || ref * (long ? 0.985 : 1.015) }], style: {} };
      arr.push(d);
    }
    const prev = d.acct;
    d.type = long ? 'long' : 'short';
    d.pts[0].p = avg; d.pts[0].t = t0;
    d.pts[1].t = d.pts[2].t = end;
    if (tpFar) d.pts[1].p = tpFar; // если тейк на бирже не стоит — оставляем ваш (можно двигать мышью)
    if (sl) d.pts[2].p = sl;
    d.entries = ens.length > 1 ? ens : undefined;
    d.fills = ens.map((_, i) => i < filled.length);
    d.tps = tps.length > 1 ? tps : undefined;
    d.style = d.style || {}; d.style.amount = tw;
    d.acct = acct; d.closed = undefined;
    return { d, prev };
  }

  // один раз узнаём у биржи точное время открытия позиции (по истории сделок)
  async function askOpenTime(ex, pos, d) {
    d.acct.openAsked = true;
    if (!window.orbita.acctOpenTime) return;
    try {
      const r = await window.orbita.acctOpenTime(ex, { sym: pos.sym, side: pos.side, qty: pos.qty, pside: pos.pside });
      if (r && r.ok && r.t > 0 && r.t <= Date.now()) {
        d.acct.openAt = r.t; d.pts[0].t = r.t;
        App.invalidateSym(pos.id); App.saveSoon();
      }
    } catch { /* останется приблизительное время */ }
  }
  function say(text, kind) { if (App.isMain && typeof Voice !== 'undefined' && Voice.event) Voice.event(kind, text); }
  const fmt = v => U.fmt(v, v);

  // ---------- синхронизация ----------
  async function syncEx(ex, withOrders) {
    const r = await window.orbita.acctFetch(ex, withOrders);
    if (!r || !r.ok) { status[ex] = { ok: false, err: (r && r.error) || 'нет связи', t: Date.now() }; return false; }
    status[ex] = { ok: true, t: r.t };
    last[ex] = r.positions || [];
    if (r.orders) orders[ex] = r.orders;
    const gs = groups(ex, last[ex], orders[ex] || []), seen = new Set(), syms = new Set();
    for (const g of gs.values()) {
      const res = upsert(g); if (!res) continue;
      seen.add(g.key); syms.add(g.id);
      const { d, prev } = res, nm0 = Voice && Voice.coinName ? Voice.coinName(g.id) : Data.label(g.id).base, Nm = nm0[0].toUpperCase() + nm0.slice(1), side = g.side === 'long' ? 'лонг' : 'шорт';
      if (!firstDone[ex]) continue; // при запуске не объявляем то, что уже было открыто
      if (!prev && g.pos) say(`${Nm}, ${EXN[ex]}: открыт ${side}, вход ${fmt(g.pos.entry)}.`, 'fill');
      else if (!prev && !g.pos) say(`${Nm}, ${EXN[ex]}: выставлены лимитки на ${side}.`, 'fill');
      else if (prev && !prev.qty && g.pos) say(`${Nm}, ${EXN[ex]}: лимитка исполнена, вы в сделке. Вход ${fmt(g.pos.entry)}.`, 'fill');
      else if (prev && g.pos && g.pos.qty > prev.qty * 1.0001) say(`${Nm}, ${EXN[ex]}: позиция увеличена. Новая нулевая точка ${fmt(g.pos.entry)}.`, 'fill');
      else if (prev && g.pos && g.pos.qty < prev.qty * 0.9999) say(`${Nm}, ${EXN[ex]}: часть позиции закрыта.`, 'tp');
      d.acct.lastQty = g.pos ? g.pos.qty : 0;
      if (g.pos && !d.acct.openAt && !d.acct.openAsked) askOpenTime(ex, g.pos, d);
    }
    // закрытые: позиции этой биржи, которых больше нет
    for (const [k, arr] of Object.entries(App.state.drawings)) {
      for (const d of arr) {
        if (!d.acct || !d.acct.open || d.acct.ex !== ex || seen.has(d.acct.key)) continue;
        d.acct.open = false; d.acct.closedAt = Date.now();
        d.pts[1].t = d.pts[2].t = Date.now();
        if (firstDone[ex]) {
          const nm0 = Voice && Voice.coinName ? Voice.coinName(d.acct.key.split('|')[1]) : k, Nm = nm0[0].toUpperCase() + nm0.slice(1);
          say(d.acct.qty ? `${Nm}, ${EXN[ex]}: позиция закрыта.` : `${Nm}, ${EXN[ex]}: лимитки сняты.`, d.acct.upnl >= 0 ? 'tp' : 'sl');
        }
        syms.add(d.acct.key.split('|')[1]);
      }
    }
    firstDone[ex] = true;
    for (const s of syms) App.invalidateSym(s);
    return true;
  }
  async function sync() {
    if (busy || !has()) return; busy = true;
    try {
      const exs = connected(); if (!exs.length) return;
      const withOrders = tick % 3 === 0; tick++;
      for (const ex of exs) { try { await syncEx(ex, withOrders || !orders[ex]); } catch (e) { status[ex] = { ok: false, err: e.message, t: Date.now() }; } }
      // общий снимок для других окон (без постоянной записи из-за меняющейся прибыли)
      const snapKey = JSON.stringify(exs.map(ex => [ex, (last[ex] || []).map(p => p.id + p.side + p.qty)]));
      if (snapKey !== App._acctSnapKey) { App._acctSnapKey = snapKey; App.saveSoon(); }
      if (Panels && App.state.settings.sidePanel === 'acct') renderPanel();
    } finally { busy = false; }
  }
  async function start() {
    clearInterval(timer);
    await refreshList();
    if (!App.isMain || !connected().length) { renderPanel(); if (!App.isMain && connected().length) timer = setInterval(renderPanel, 5000); return; }
    sync(); timer = setInterval(sync, 5000);
  }

  // ---------- вкладка «Мои позиции» в правой панели ----------
  function isOpen() { const st = App.state.settings, side = document.getElementById('side'); return !!(st.sideOpen && st.sidePanel === 'acct' && side && !side.classList.contains('auto-hidden')); }
  function renderPanel() {
    if (!isOpen()) return;
    const b = Panels.body(), exs = connected();
    let html = `<div class="sp-head"><span>Мои позиции</span><button class="ib" id="acSet" title="Подключить биржи (ключ только для чтения)">${U.icon('gear')}</button></div>`;
    if (!has()) html += '<div class="np-note">Подключение бирж работает в программе для Windows.</div>';
    else if (!exs.length) html += `<div class="ac-empty"><div class="ac-big">Ваши сделки — сразу на графике</div>
      <div class="muted">Подключите Binance, Bybit или Gate ключом <b>только для чтения</b>: Orbita сама нарисует открытые позиции, лимитки, тейки и стопы и будет показывать прибыль.</div>
      <button class="btn primary" id="acGo">Подключить биржу</button></div>`;
    else {
      const rows = [];
      if (!App.isMain) { // доп. окно: берём позиции из общих рисунков (их обновляет главное окно)
        html += '<div class="np-note sm">Позиции обновляет главное окно Orbita.</div>';
        for (const arr of Object.values(App.state.drawings)) for (const d of arr) if (d.acct && d.acct.open && d.acct.qty > 0) {
          const [ex, id] = d.acct.key.split('|');
          rows.push({ ex, p: { id, side: d.type === 'long' ? 'long' : 'short', lev: d.acct.lev, entry: d.acct.entry, qty: d.acct.qty, notional: d.acct.notional, mark: d.acct.mark } });
        }
      } else {
      html += '<div class="ac-st">' + exs.map(ex => { const s = status[ex]; const ago = s ? Math.max(0, Math.round((Date.now() - s.t) / 1000)) : null;
        return `<span class="ac-x ${s ? (s.ok ? 'ok' : 'bad') : ''}" title="${s && !s.ok ? U.esc(s.err) : ''}">${EXN[ex]} ${!s ? '…' : s.ok ? `✓ ${ago} с` : '⚠ ошибка'}</span>`; }).join('') + '</div>';
      const errs = exs.filter(ex => status[ex] && !status[ex].ok);
      if (errs.length) html += errs.map(ex => `<div class="ac-err">${EXN[ex]}: ${U.esc(status[ex].err)}</div>`).join('');
      for (const ex of exs) for (const p of last[ex] || []) rows.push({ ex, p });
      }
      if (!rows.length) html += '<div class="np-note">Открытых позиций нет.</div>';
      html += '<div class="ac-list">' + rows.map(({ ex, p }) => {
        const lb = Data.label(p.id), av = coinAvatar(lb.base), long = p.side === 'long';
        const cur = App.prices[p.id] || p.mark, pct = (cur - p.entry) / p.entry * 100 * (long ? 1 : -1);
        const usd = p.qty * (cur - p.entry) * (long ? 1 : -1);
        const lim = (orders[ex] || []).filter(o => o.id === p.id && o.kind === 'limit' && !o.reduce).length;
        const dd = (App.state.drawings[App.dKey(p.id)] || []).find(x => x.acct && x.acct.open && x.acct.key === `${ex}|${p.id}|${p.side}`);
        const tN = dd ? dd.acct.tpN || 0 : 0, sN = dd ? dd.acct.slN || 0 : 0;
        return `<div class="ac-row" data-id="${U.esc(p.id)}" title="Открыть график">
          <span class="wl-av" style="background:${av.bg}">${U.esc(av.t)}</span>
          <span class="ac-main"><span class="ac-top"><b>${U.esc(lb.base)}</b><span class="ac-side ${long ? 'l' : 's'}">${long ? 'ЛОНГ' : 'ШОРТ'}${p.lev ? ' x' + Math.round(p.lev) : ''}</span><span class="ex-mini">${EXS[ex]}</span></span>
            <span class="ac-sub">вход ${fmt(p.entry)} · $${U.fmtNum(p.notional, 0)}${lim ? ` · лимиток ${lim}` : ''}${tN ? ` · тейков ${tN}` : ''}${sN ? ` · стоп` : ''}</span></span>
          <span class="ac-pnl ${usd >= 0 ? 'up' : 'dn'}"><b>${usd >= 0 ? '+' : '−'}$${U.fmtNum(Math.abs(usd), Math.abs(usd) >= 100 ? 0 : 2)}</b><span>${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%</span></span></div>`;
      }).join('') + '</div>';
    }
    b.innerHTML = html;
    const go = b.querySelector('#acSet'); if (go) go.onclick = () => openDialog();
    const go2 = b.querySelector('#acGo'); if (go2) go2.onclick = () => openDialog();
    b.querySelectorAll('.ac-row').forEach(r => r.onclick = () => App.setSymbol(r.dataset.id));
  }

  // ---------- окно подключения ----------
  const HOWTO = {
    binance: 'Binance → Профиль → <b>Управление API</b> → Создать API (системный ключ). Оставьте включённым <b>только «Разрешить чтение»</b> (Enable Reading) — торговлю и вывод не включайте. Желательно ограничить ключ вашим IP.',
    bybit: 'Bybit → Профиль → <b>API</b> → Создать новый ключ → «Системный». Выберите <b>«Только чтение»</b> (Read-Only) и отметьте контракты (ордера и позиции).',
    gate: 'Gate → Профиль → <b>Управление API</b> → Создать ключ. Для бессрочных фьючерсов (Perpetual Futures) выберите <b>только чтение</b>, остальные разделы — без доступа.',
  };
  async function openDialog() {
    await refreshList();
    const m = U.modal({ title: 'Подключение бирж', width: 520 });
    const sec = x => `<div class="ac-ex" data-ex="${x.ex}">
        <div class="ac-exh"><b>${x.name}</b> <span class="muted">фьючерсы USDT</span><span class="ac-stat ${x.connected ? 'ok' : ''}">${x.connected ? `подключено · ${U.esc(x.key)}` : 'не подключено'}</span></div>
        <details><summary>Как создать ключ только для чтения</summary><div class="muted sm">${HOWTO[x.ex]}</div></details>
        <div class="two"><label>API Key<input class="inp" data-k autocomplete="off" spellcheck="false" placeholder="${x.connected ? 'заменить ключ…' : 'вставьте API Key'}"></label>
          <label>Secret<input class="inp" type="password" data-s autocomplete="off" spellcheck="false" placeholder="вставьте Secret"></label></div>
        <div class="ac-btns"><button class="btn primary sm" data-a="save">Сохранить и проверить</button>${x.connected ? '<button class="btn ghost sm" data-a="del">Отключить</button>' : ''}<span class="ac-msg"></span></div>
      </div>`;
    m.body.innerHTML = `<div class="form">
      <div class="ac-safe">🔒 Нужен ключ <b>только для чтения</b>. Orbita умеет лишь смотреть позиции и ордера — открыть, закрыть сделку или вывести деньги она не может. Ключи шифруются средствами Windows и хранятся только на этом компьютере.</div>
      ${list.map(sec).join('')}</div>
      <div class="modal-actions"><button class="btn ghost" data-a="close">Готово</button></div>`;
    m.body.addEventListener('click', async e => {
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'close') { m.close(); start(); return; }
      const box = a.closest('.ac-ex'), ex = box.dataset.ex, msg = box.querySelector('.ac-msg');
      if (a.dataset.a === 'del') {
        if (!(await U.confirm(`Отключить ${EXN[ex]}? Ключ будет удалён с этого компьютера.`))) return;
        await window.orbita.acctDel(ex);
        for (const arr of Object.values(App.state.drawings)) for (const d of arr) if (d.acct && d.acct.ex === ex && d.acct.open) { d.acct.open = false; d.acct.closedAt = Date.now(); }
        App.saveSoon(); m.close(); openDialog(); start(); return;
      }
      const key = box.querySelector('[data-k]').value.trim(), secret = box.querySelector('[data-s]').value.trim();
      if (!key || !secret) { msg.className = 'ac-msg dn'; msg.textContent = 'Вставьте API Key и Secret'; return; }
      a.disabled = true; msg.className = 'ac-msg'; msg.textContent = 'Проверяю ключ…';
      const r = await window.orbita.acctSave(ex, key, secret);
      a.disabled = false;
      if (!r.ok) { msg.className = 'ac-msg dn'; msg.textContent = r.error; return; }
      box.querySelector('[data-k]').value = ''; box.querySelector('[data-s]').value = '';
      box.querySelector('.ac-stat').className = 'ac-stat ok'; box.querySelector('.ac-stat').textContent = `подключено · ${r.key}`;
      if (r.risky && r.risky.length) { msg.className = 'ac-msg warn'; msg.innerHTML = `Подключено, но у ключа включено: <b>${U.esc(r.risky.join(', '))}</b>. Orbita этим не пользуется, но безопаснее создать ключ только для чтения.`; }
      else { msg.className = 'ac-msg up'; msg.textContent = '✓ Подключено. Позиции появятся на графиках через несколько секунд.'; }
      firstDone[ex] = false; start();
    });
  }

  function init() { start(); }
  return { init, start, openDialog, renderPanel, get open() { return isOpen(); }, _groups: groups, _upsert: upsert, _sync: sync };
})();
