'use strict';
const IND = (() => {
  const N = n => new Float64Array(n).fill(NaN);
  const SRC = ['close', 'open', 'high', 'low', 'hl2', 'hlc3', 'ohlc4'];
  function src(b, s) {
    const n = b.length, o = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      const x = b[i];
      o[i] = s === 'open' ? x.o : s === 'high' ? x.h : s === 'low' ? x.l : s === 'hl2' ? (x.h + x.l) / 2
        : s === 'hlc3' ? (x.h + x.l + x.c) / 3 : s === 'ohlc4' ? (x.o + x.h + x.l + x.c) / 4 : x.c;
    }
    return o;
  }
  const col = (b, f) => { const o = new Float64Array(b.length); for (let i = 0; i < b.length; i++) o[i] = f(b[i], i); return o; };

  function sma(s, p) {
    const n = s.length, o = N(n); let sum = 0, c = 0;
    for (let i = 0; i < n; i++) {
      const v = s[i];
      if (v !== v) { sum = 0; c = 0; continue; }
      sum += v; c++;
      if (c > p) { sum -= s[i - p]; c = p; }
      if (c === p) o[i] = sum / p;
    }
    return o;
  }
  function emaK(s, p, k) {
    const n = s.length, o = N(n); let prev = NaN, c = 0, sum = 0;
    for (let i = 0; i < n; i++) {
      const v = s[i];
      if (v !== v) continue;
      if (prev !== prev) { sum += v; c++; if (c === p) { prev = sum / p; o[i] = prev; } continue; }
      prev += k * (v - prev); o[i] = prev;
    }
    return o;
  }
  const ema = (s, p) => emaK(s, p, 2 / (p + 1));
  const rma = (s, p) => emaK(s, p, 1 / p);
  function wma(s, p) {
    const n = s.length, o = N(n), d = p * (p + 1) / 2;
    for (let i = p - 1; i < n; i++) {
      let a = 0, ok = true;
      for (let j = 0; j < p; j++) { const v = s[i - j]; if (v !== v) { ok = false; break; } a += v * (p - j); }
      if (ok) o[i] = a / d;
    }
    return o;
  }
  function stdev(s, p, m) {
    m = m || sma(s, p);
    const n = s.length, o = N(n);
    for (let i = p - 1; i < n; i++) {
      if (m[i] !== m[i]) continue;
      let a = 0; for (let j = i - p + 1; j <= i; j++) { const d = s[j] - m[i]; a += d * d; }
      o[i] = Math.sqrt(a / p);
    }
    return o;
  }
  function roll(s, p, f) {
    const n = s.length, o = N(n);
    for (let i = p - 1; i < n; i++) {
      let m = f === 'max' ? -Infinity : Infinity, ok = true;
      for (let j = i - p + 1; j <= i; j++) { const v = s[j]; if (v !== v) { ok = false; break; } if (f === 'max' ? v > m : v < m) m = v; }
      if (ok) o[i] = m;
    }
    return o;
  }
  const highest = (s, p) => roll(s, p, 'max'), lowest = (s, p) => roll(s, p, 'min');
  function rsum(s, p) { const m = sma(s, p); for (let i = 0; i < m.length; i++) m[i] *= p; return m; }
  function tr(b) {
    const n = b.length, o = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      const x = b[i];
      if (!i) { o[i] = x.h - x.l; continue; }
      const pc = b[i - 1].c;
      o[i] = Math.max(x.h - x.l, Math.abs(x.h - pc), Math.abs(x.l - pc));
    }
    return o;
  }
  const atr = (b, p) => rma(tr(b), p);
  function rsi(s, p) {
    const n = s.length, g = N(n), l = N(n);
    for (let i = 1; i < n; i++) { const d = s[i] - s[i - 1]; if (d !== d) continue; g[i] = d > 0 ? d : 0; l[i] = d < 0 ? -d : 0; }
    const ag = rma(g, p), al = rma(l, p), o = N(n);
    for (let i = 0; i < n; i++) { if (ag[i] !== ag[i]) continue; o[i] = al[i] === 0 ? 100 : 100 - 100 / (1 + ag[i] / al[i]); }
    return o;
  }
  function stochOf(s, hi, lo, p) {
    const hh = highest(hi, p), ll = lowest(lo, p), n = s.length, o = N(n);
    for (let i = 0; i < n; i++) { const r = hh[i] - ll[i]; if (r === r) o[i] = r === 0 ? 50 : 100 * (s[i] - ll[i]) / r; }
    return o;
  }
  const op = (a, b, f) => { const n = a.length, o = N(n); for (let i = 0; i < n; i++) o[i] = f(a[i], typeof b === 'number' ? b : b[i]); return o; };

  const C = { orange: '#f5a623', blue: '#4f8cff', purple: '#a66bff', teal: '#2ec4b6', red: '#f0556a', green: '#22c39a', yellow: '#e8c547', pink: '#ff6fb5', gray: '#8b93a7', cyan: '#3ec7e6' };
  const D = {};
  const def = (id, o) => { D[id] = { id, p: [], levels: [], ...o }; };
  const LEN = (v = 14) => ['length', 'Длина', v];
  const SOURCE = ['source', 'Источник', 'close', SRC];

  // ---------- Тренд / средние ----------
  def('SMA', { name: 'Простая скользящая средняя', short: 'MA', cat: 'Скользящие средние', overlay: true, p: [LEN(20), SOURCE], o: [{ k: 'v', n: 'MA', c: C.orange }], calc: (b, P) => ({ v: sma(src(b, P.source), P.length) }) });
  def('EMA', { name: 'Экспоненциальная скользящая средняя', short: 'EMA', cat: 'Скользящие средние', overlay: true, p: [LEN(21), SOURCE], o: [{ k: 'v', n: 'EMA', c: C.blue }], calc: (b, P) => ({ v: ema(src(b, P.source), P.length) }) });
  def('WMA', { name: 'Взвешенная скользящая средняя', short: 'WMA', cat: 'Скользящие средние', overlay: true, p: [LEN(20), SOURCE], o: [{ k: 'v', n: 'WMA', c: C.purple }], calc: (b, P) => ({ v: wma(src(b, P.source), P.length) }) });
  def('HMA', { name: 'Скользящая средняя Халла', short: 'HMA', cat: 'Скользящие средние', overlay: true, p: [LEN(21), SOURCE], o: [{ k: 'v', n: 'HMA', c: C.teal }], calc: (b, P) => {
    const s = src(b, P.source), h = Math.max(1, Math.round(P.length / 2)), q = Math.max(1, Math.round(Math.sqrt(P.length)));
    return { v: wma(op(wma(s, h), wma(s, P.length), (x, y) => 2 * x - y), q) };
  } });
  def('DEMA', { name: 'Двойная экспоненциальная средняя', short: 'DEMA', cat: 'Скользящие средние', overlay: true, p: [LEN(21), SOURCE], o: [{ k: 'v', n: 'DEMA', c: C.cyan }], calc: (b, P) => {
    const e1 = ema(src(b, P.source), P.length), e2 = ema(e1, P.length); return { v: op(e1, e2, (x, y) => 2 * x - y) };
  } });
  def('TEMA', { name: 'Тройная экспоненциальная средняя', short: 'TEMA', cat: 'Скользящие средние', overlay: true, p: [LEN(21), SOURCE], o: [{ k: 'v', n: 'TEMA', c: C.pink }], calc: (b, P) => {
    const e1 = ema(src(b, P.source), P.length), e2 = ema(e1, P.length), e3 = ema(e2, P.length), n = b.length, o = N(n);
    for (let i = 0; i < n; i++) o[i] = 3 * e1[i] - 3 * e2[i] + e3[i]; return { v: o };
  } });
  def('VWMA', { name: 'Средняя, взвешенная по объёму', short: 'VWMA', cat: 'Скользящие средние', overlay: true, p: [LEN(20)], o: [{ k: 'v', n: 'VWMA', c: C.yellow }], calc: (b, P) => {
    const cv = col(b, x => x.c * x.v), v = col(b, x => x.v); return { v: op(sma(cv, P.length), sma(v, P.length), (x, y) => x / y) };
  } });
  def('ICHI', { name: 'Облако Ишимоку', short: 'Ichimoku', cat: 'Тренд', overlay: true,
    p: [['conv', 'Линия конверсии', 9], ['base', 'Базовая линия', 26], ['spanB', 'Опережающий интервал B', 52], ['disp', 'Смещение', 26]],
    o: [{ k: 'conv', n: 'Tenkan', c: C.blue }, { k: 'base', n: 'Kijun', c: C.red }, { k: 'a', n: 'Span A', c: C.green, off: P => P.disp - 1 }, { k: 'b', n: 'Span B', c: C.red, off: P => P.disp - 1, w: 1 }, { k: 'lag', n: 'Chikou', c: C.purple, off: P => -(P.disp - 1), w: 1 }],
    fills: [{ a: 'a', b: 'b', c: C.green, c2: C.red }],
    calc: (b, P) => {
      const h = col(b, x => x.h), l = col(b, x => x.l);
      const mid = p => op(highest(h, p), lowest(l, p), (x, y) => (x + y) / 2);
      const conv = mid(P.conv), base = mid(P.base);
      return { conv, base, a: op(conv, base, (x, y) => (x + y) / 2), b: mid(P.spanB), lag: col(b, x => x.c) };
    } });
  def('PSAR', { name: 'Параболическая система SAR', short: 'SAR', cat: 'Тренд', overlay: true, p: [['start', 'Начало', 0.02], ['inc', 'Шаг', 0.02], ['max', 'Максимум', 0.2]], o: [{ k: 'v', n: 'SAR', c: C.blue, t: 'dots' }], calc: (b, P) => {
    const n = b.length, o = N(n), cl = new Array(n);
    if (n < 3) return { v: o };
    let up = b[1].c >= b[0].c, af = P.start, ep = up ? b[0].h : b[0].l, sar = up ? b[0].l : b[0].h;
    for (let i = 1; i < n; i++) {
      sar += af * (ep - sar);
      if (up) {
        sar = Math.min(sar, b[i - 1].l, i > 1 ? b[i - 2].l : b[i - 1].l);
        if (b[i].l < sar) { up = false; sar = ep; ep = b[i].l; af = P.start; }
        else if (b[i].h > ep) { ep = b[i].h; af = Math.min(af + P.inc, P.max); }
      } else {
        sar = Math.max(sar, b[i - 1].h, i > 1 ? b[i - 2].h : b[i - 1].h);
        if (b[i].h > sar) { up = true; sar = ep; ep = b[i].h; af = P.start; }
        else if (b[i].l < ep) { ep = b[i].l; af = Math.min(af + P.inc, P.max); }
      }
      o[i] = sar; cl[i] = up ? C.green : C.red;
    }
    return { v: o, _col: { v: cl } };
  } });
  def('ST', { name: 'Супертренд', short: 'Supertrend', cat: 'Тренд', overlay: true, p: [['length', 'Период ATR', 10], ['mult', 'Множитель', 3]], o: [{ k: 'up', n: 'Вверх', c: C.green, w: 2 }, { k: 'dn', n: 'Вниз', c: C.red, w: 2 }], calc: (b, P) => {
    const a = atr(b, P.length), n = b.length, up = N(n), dn = N(n);
    let fu = NaN, fl = NaN, trend = 1;
    for (let i = 0; i < n; i++) {
      if (a[i] !== a[i]) continue;
      const hl = (b[i].h + b[i].l) / 2, bu = hl + P.mult * a[i], bl = hl - P.mult * a[i], pc = i ? b[i - 1].c : b[i].c;
      const nfu = (fu !== fu || bu < fu || pc > fu) ? bu : fu;
      const nfl = (fl !== fl || bl > fl || pc < fl) ? bl : fl;
      if (trend === 1 && b[i].c < nfl) trend = -1; else if (trend === -1 && b[i].c > nfu) trend = 1;
      fu = nfu; fl = nfl;
      if (trend === 1) up[i] = fl; else dn[i] = fu;
    }
    return { up, dn };
  } });
  def('VWAP', { name: 'Средневзвешенная цена по объёму (сессия)', short: 'VWAP', cat: 'Объём', overlay: true, o: [{ k: 'v', n: 'VWAP', c: C.pink, w: 1.5 }], calc: b => {
    const n = b.length, o = N(n); let day = -1, pv = 0, vv = 0;
    for (let i = 0; i < n; i++) {
      const d = Math.floor(b[i].t / 864e5); if (d !== day) { day = d; pv = 0; vv = 0; }
      const tp = (b[i].h + b[i].l + b[i].c) / 3; pv += tp * b[i].v; vv += b[i].v; o[i] = vv ? pv / vv : tp;
    }
    return { v: o };
  } });

  // ---------- Волатильность / каналы ----------
  def('BB', { name: 'Полосы Боллинджера', short: 'BB', cat: 'Волатильность', overlay: true, p: [LEN(20), ['mult', 'Множитель', 2], SOURCE],
    o: [{ k: 'basis', n: 'Средняя', c: C.orange, w: 1 }, { k: 'up', n: 'Верхняя', c: C.blue, w: 1 }, { k: 'lo', n: 'Нижняя', c: C.blue, w: 1 }], fills: [{ a: 'up', b: 'lo', c: C.blue }],
    calc: (b, P) => { const s = src(b, P.source), m = sma(s, P.length), sd = stdev(s, P.length, m); return { basis: m, up: op(m, sd, (x, y) => x + P.mult * y), lo: op(m, sd, (x, y) => x - P.mult * y) }; } });
  def('KC', { name: 'Каналы Кельтнера', short: 'KC', cat: 'Волатильность', overlay: true, p: [LEN(20), ['mult', 'Множитель', 2], ['atrLen', 'Период ATR', 10]],
    o: [{ k: 'basis', n: 'Средняя', c: C.teal, w: 1 }, { k: 'up', n: 'Верхняя', c: C.teal, w: 1 }, { k: 'lo', n: 'Нижняя', c: C.teal, w: 1 }], fills: [{ a: 'up', b: 'lo', c: C.teal }],
    calc: (b, P) => { const m = ema(col(b, x => x.c), P.length), a = atr(b, P.atrLen); return { basis: m, up: op(m, a, (x, y) => x + P.mult * y), lo: op(m, a, (x, y) => x - P.mult * y) }; } });
  def('DC', { name: 'Каналы Дончиана', short: 'DC', cat: 'Волатильность', overlay: true, p: [LEN(20)],
    o: [{ k: 'up', n: 'Верхняя', c: C.blue, w: 1 }, { k: 'mid', n: 'Средняя', c: C.orange, w: 1 }, { k: 'lo', n: 'Нижняя', c: C.blue, w: 1 }], fills: [{ a: 'up', b: 'lo', c: C.blue }],
    calc: (b, P) => { const up = highest(col(b, x => x.h), P.length), lo = lowest(col(b, x => x.l), P.length); return { up, lo, mid: op(up, lo, (x, y) => (x + y) / 2) }; } });
  def('ENV', { name: 'Конверт', short: 'Env', cat: 'Волатильность', overlay: true, p: [LEN(20), ['pct', 'Процент', 2.5], SOURCE],
    o: [{ k: 'basis', n: 'Средняя', c: C.orange, w: 1 }, { k: 'up', n: 'Верхняя', c: C.purple, w: 1 }, { k: 'lo', n: 'Нижняя', c: C.purple, w: 1 }],
    calc: (b, P) => { const m = sma(src(b, P.source), P.length); return { basis: m, up: op(m, 1 + P.pct / 100, (x, k) => x * k), lo: op(m, 1 - P.pct / 100, (x, k) => x * k) }; } });
  def('ATR', { name: 'Средний истинный диапазон', short: 'ATR', cat: 'Волатильность', p: [LEN(14)], o: [{ k: 'v', n: 'ATR', c: C.red }], calc: (b, P) => ({ v: atr(b, P.length) }) });

  // ---------- Объём ----------
  def('VOL', { name: 'Объём', short: 'Объём', cat: 'Объём', overlay: true, vol: true, p: [['ma', 'MA объёма', 20]], o: [{ k: 'v', n: 'Объём', t: 'vol' }, { k: 'ma', n: 'MA', c: C.blue, w: 1 }],
    calc: (b, P) => { const v = col(b, x => x.v); return { v, ma: sma(v, P.ma) }; } });
  def('OBV', { name: 'Балансовый объём', short: 'OBV', cat: 'Объём', o: [{ k: 'v', n: 'OBV', c: C.blue }], calc: b => {
    const n = b.length, o = new Float64Array(n); for (let i = 1; i < n; i++) o[i] = o[i - 1] + (b[i].c > b[i - 1].c ? b[i].v : b[i].c < b[i - 1].c ? -b[i].v : 0); return { v: o };
  } });
  def('MFI', { name: 'Индекс денежного потока', short: 'MFI', range: [0, 100], cat: 'Объём', p: [LEN(14)], o: [{ k: 'v', n: 'MFI', c: C.purple }], levels: [80, 20], lfill: true, calc: (b, P) => {
    const n = b.length, tp = col(b, x => (x.h + x.l + x.c) / 3), pos = new Float64Array(n), neg = new Float64Array(n);
    for (let i = 1; i < n; i++) { const mf = tp[i] * b[i].v; if (tp[i] > tp[i - 1]) pos[i] = mf; else if (tp[i] < tp[i - 1]) neg[i] = mf; }
    const ps = rsum(pos, P.length), ns = rsum(neg, P.length);
    return { v: op(ps, ns, (x, y) => y === 0 ? 100 : 100 - 100 / (1 + x / y)) };
  } });
  def('CMF', { name: 'Денежный поток Чайкина', short: 'CMF', cat: 'Объём', p: [LEN(20)], o: [{ k: 'v', n: 'CMF', c: C.teal }], levels: [0], calc: (b, P) => {
    const mfv = col(b, x => x.h === x.l ? 0 : ((x.c - x.l) - (x.h - x.c)) / (x.h - x.l) * x.v), v = col(b, x => x.v);
    return { v: op(rsum(mfv, P.length), rsum(v, P.length), (x, y) => y ? x / y : 0) };
  } });

  // ---------- Осцилляторы ----------
  def('RSI', { name: 'Индекс относительной силы', short: 'RSI', range: [0, 100], cat: 'Осцилляторы',
    p: [LEN(14), SOURCE, ['maType', 'Тип сглаживающей MA', 'SMA', ['SMA', 'EMA', 'WMA', 'RMA']], ['maLen', 'Длина сглаживающей MA', 14]],
    o: [{ k: 'v', n: 'RSI', c: C.purple, w: 1.5 }, { k: 'ma', n: 'MA по RSI', c: C.yellow, w: 1.2 }],
    levels: [70, 50, 30], lfill: true,
    zones: [{ k: 'v', above: 70, c: C.green }, { k: 'v', below: 30, c: C.red }],
    calc: (b, P) => {
      const r = rsi(src(b, P.source), P.length);
      const f = { SMA: sma, EMA: ema, WMA: wma, RMA: rma }[P.maType] || sma;
      return { v: r, ma: f(r, P.maLen) };
    } });
  def('MACD', { name: 'Схождение/расхождение скользящих средних', short: 'MACD', cat: 'Осцилляторы', p: [['fast', 'Быстрая', 12], ['slow', 'Медленная', 26], ['signal', 'Сигнальная', 9], SOURCE],
    o: [{ k: 'hist', n: 'Гистограмма', t: 'hist', c: C.green }, { k: 'macd', n: 'MACD', c: C.blue }, { k: 'signal', n: 'Сигнал', c: C.orange }],
    calc: (b, P) => {
      const s = src(b, P.source), m = op(ema(s, P.fast), ema(s, P.slow), (x, y) => x - y), sg = ema(m, P.signal), h = op(m, sg, (x, y) => x - y);
      const cl = new Array(h.length);
      for (let i = 0; i < h.length; i++) { const v = h[i], pv = h[i - 1]; cl[i] = v >= 0 ? (!(v < pv) ? C.green : '#86dcc3') : (v < pv || pv !== pv ? C.red : '#f5a3ae'); }
      return { macd: m, signal: sg, hist: h, _col: { hist: cl } };
    } });
  def('STOCH', { name: 'Стохастический осциллятор', short: 'Stoch', range: [0, 100], cat: 'Осцилляторы', p: [['k', '%K длина', 14], ['smooth', '%K сглаживание', 1], ['d', '%D сглаживание', 3]],
    o: [{ k: 'k', n: '%K', c: C.blue }, { k: 'd', n: '%D', c: C.orange }], levels: [80, 20], lfill: true,
    calc: (b, P) => { const k = sma(stochOf(col(b, x => x.c), col(b, x => x.h), col(b, x => x.l), P.k), P.smooth); return { k, d: sma(k, P.d) }; } });
  def('STOCHRSI', { name: 'Стохастический RSI', short: 'Stoch RSI', range: [0, 100], cat: 'Осцилляторы', p: [['rsi', 'Длина RSI', 14], ['stoch', 'Длина стохастика', 14], ['k', 'K', 3], ['d', 'D', 3], SOURCE],
    o: [{ k: 'k', n: 'K', c: C.blue }, { k: 'd', n: 'D', c: C.orange }], levels: [80, 20], lfill: true,
    calc: (b, P) => { const r = rsi(src(b, P.source), P.rsi); const k = sma(stochOf(r, r, r, P.stoch), P.k); return { k, d: sma(k, P.d) }; } });
  def('CCI', { name: 'Индекс товарного канала', short: 'CCI', cat: 'Осцилляторы', p: [LEN(20)], o: [{ k: 'v', n: 'CCI', c: C.teal }], levels: [100, -100], lfill: true, calc: (b, P) => {
    const tp = col(b, x => (x.h + x.l + x.c) / 3), m = sma(tp, P.length), n = b.length, o = N(n);
    for (let i = P.length - 1; i < n; i++) { if (m[i] !== m[i]) continue; let md = 0; for (let j = i - P.length + 1; j <= i; j++) md += Math.abs(tp[j] - m[i]); md /= P.length; o[i] = md ? (tp[i] - m[i]) / (0.015 * md) : 0; }
    return { v: o };
  } });
  def('WPR', { name: 'Процентный диапазон Уильямса', short: '%R', range: [-100, 0], cat: 'Осцилляторы', p: [LEN(14)], o: [{ k: 'v', n: '%R', c: C.purple }], levels: [-20, -80], lfill: true, calc: (b, P) => {
    const hh = highest(col(b, x => x.h), P.length), ll = lowest(col(b, x => x.l), P.length);
    return { v: col(b, (x, i) => hh[i] === ll[i] ? -50 : -100 * (hh[i] - x.c) / (hh[i] - ll[i])) };
  } });
  def('ADX', { name: 'Индекс направленного движения (ADX/DMI)', short: 'ADX', cat: 'Тренд', p: [LEN(14)], o: [{ k: 'adx', n: 'ADX', c: C.orange }, { k: 'pdi', n: '+DI', c: C.green, w: 1 }, { k: 'mdi', n: '−DI', c: C.red, w: 1 }], levels: [25], calc: (b, P) => {
    const n = b.length, pdm = new Float64Array(n), mdm = new Float64Array(n);
    for (let i = 1; i < n; i++) { const u = b[i].h - b[i - 1].h, d = b[i - 1].l - b[i].l; pdm[i] = u > d && u > 0 ? u : 0; mdm[i] = d > u && d > 0 ? d : 0; }
    const trr = rma(tr(b), P.length), pdi = op(rma(pdm, P.length), trr, (x, y) => 100 * x / y), mdi = op(rma(mdm, P.length), trr, (x, y) => 100 * x / y);
    const dx = op(pdi, mdi, (x, y) => x + y === 0 ? 0 : 100 * Math.abs(x - y) / (x + y));
    return { adx: rma(dx, P.length), pdi, mdi };
  } });
  def('MOM', { name: 'Моментум', short: 'MOM', cat: 'Осцилляторы', p: [LEN(10), SOURCE], o: [{ k: 'v', n: 'MOM', c: C.blue }], levels: [0], calc: (b, P) => {
    const s = src(b, P.source), o = N(s.length); for (let i = P.length; i < s.length; i++) o[i] = s[i] - s[i - P.length]; return { v: o };
  } });
  def('ROC', { name: 'Скорость изменения', short: 'ROC', cat: 'Осцилляторы', p: [LEN(9), SOURCE], o: [{ k: 'v', n: 'ROC', c: C.cyan }], levels: [0], calc: (b, P) => {
    const s = src(b, P.source), o = N(s.length); for (let i = P.length; i < s.length; i++) o[i] = 100 * (s[i] - s[i - P.length]) / s[i - P.length]; return { v: o };
  } });
  def('AO', { name: 'Чудесный осциллятор', short: 'AO', cat: 'Осцилляторы', o: [{ k: 'v', n: 'AO', t: 'hist', c: C.green }], levels: [0], calc: b => {
    const hl = col(b, x => (x.h + x.l) / 2), v = op(sma(hl, 5), sma(hl, 34), (x, y) => x - y), cl = new Array(v.length);
    for (let i = 0; i < v.length; i++) cl[i] = v[i] >= v[i - 1] || v[i - 1] !== v[i - 1] ? C.green : C.red;
    return { v, _col: { v: cl } };
  } });
  def('AROON', { name: 'Арун', short: 'Aroon', range: [0, 100], cat: 'Тренд', p: [LEN(14)], o: [{ k: 'up', n: 'Вверх', c: C.orange }, { k: 'dn', n: 'Вниз', c: C.blue }], calc: (b, P) => {
    const n = b.length, up = N(n), dn = N(n), p = P.length;
    for (let i = p; i < n; i++) {
      let hi = i, lo = i;
      for (let j = i - p; j <= i; j++) { if (b[j].h >= b[hi].h) hi = j; if (b[j].l <= b[lo].l) lo = j; }
      up[i] = 100 * (p - (i - hi)) / p; dn[i] = 100 * (p - (i - lo)) / p;
    }
    return { up, dn };
  } });
  def('TRIX', { name: 'TRIX', short: 'TRIX', cat: 'Осцилляторы', p: [LEN(18)], o: [{ k: 'v', n: 'TRIX', c: C.red }], levels: [0], calc: (b, P) => {
    const e = ema(ema(ema(col(b, x => Math.log(x.c)), P.length), P.length), P.length), o = N(e.length);
    for (let i = 1; i < e.length; i++) o[i] = 10000 * (e[i] - e[i - 1]); return { v: o };
  } });
  def('HV', { name: 'Историческая волатильность', short: 'HV', cat: 'Волатильность', p: [LEN(10)], o: [{ k: 'v', n: 'HV', c: C.yellow }], calc: (b, P) => {
    const r = N(b.length); for (let i = 1; i < b.length; i++) r[i] = Math.log(b[i].c / b[i - 1].c);
    const sd = stdev(r, P.length); return { v: op(sd, 100 * Math.sqrt(365), (x, k) => x * k) };
  } });

  function make(type, over = {}) {
    const d = D[type];
    return { id: U.uid(), type, params: Object.fromEntries(d.p.map(x => [x[0], x[2]])), colors: {}, visible: true, weight: 1, ...over };
  }
  function title(inst) {
    const d = D[inst.type]; if (!d) return inst.type;
    const ps = d.p.map(x => inst.params[x[0]]).filter(v => v !== undefined && v !== 'close');
    return `${d.short}${ps.length ? ' ' + ps.join(' ') : ''}`;
  }
  function calc(inst, bars, ctx) {
    const d = D[inst.type];
    if (!d || !bars.length) return {};
    const P = { ...Object.fromEntries(d.p.map(x => [x[0], x[2]])), ...inst.params };
    return d.calc(bars, P, ctx);
  }
  function fmtVal(d, v, ref) {
    if (v == null || v !== v) return '—';
    if (d.vol) return U.fmtVol(v);
    if (d.overlay) return U.fmt(v, ref);
    const a = Math.abs(v);
    if (a >= 1e5) return U.fmtVol(v);
    return v.toFixed(a < 1 ? 4 : 2);
  }
  return { defs: D, SRC, make, title, calc, fmtVal };
})();
