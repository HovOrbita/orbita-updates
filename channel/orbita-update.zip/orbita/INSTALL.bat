@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Orbita Terminal - установка
echo.
echo  === Установка Orbita Terminal ===
echo  Node.js не нужен. Скачивается только сама программа, около 110 МБ.
echo.
if exist "electron\electron.exe" goto shortcut
echo  [1/2] Скачиваю... 1-5 минут, окно не закрывайте.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol='Tls12'; $v='37.0.0'; $f='electron-v'+$v+'-win32-x64.zip'; try { Invoke-WebRequest ('https://github.com/electron/electron/releases/download/v'+$v+'/'+$f) -OutFile 'electron.zip' -UseBasicParsing } catch { Invoke-WebRequest ('https://npmmirror.com/mirrors/electron/'+$v+'/'+$f) -OutFile 'electron.zip' -UseBasicParsing }; Expand-Archive 'electron.zip' -DestinationPath 'electron' -Force; Remove-Item 'electron.zip'"
if not exist "electron\electron.exe" (
  echo.
  echo  Не удалось скачать. Проверьте интернет или включите VPN и запустите INSTALL.bat снова.
  pause
  exit /b
)
:shortcut
echo  [2/2] Создаю ярлык на рабочем столе...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d='%~dp0'.TrimEnd('\'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Orbita Terminal.lnk'); $s.TargetPath=$d+'\electron\electron.exe'; $s.Arguments='\"'+$d+'\"'; $s.WorkingDirectory=$d; $s.Save()"
echo.
echo  Готово! Запускайте ярлыком "Orbita Terminal" на рабочем столе.
echo  Папку orbita не перемещайте, иначе ярлык перестанет работать.
echo.
pause
