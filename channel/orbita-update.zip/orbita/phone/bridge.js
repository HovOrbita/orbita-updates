'use strict';
// «Мостик» для телефона: вместо Electron программа обращается к Orbita на компьютере по домашней сети.
(function () {
  const KEY_LS = 'orbitaPhoneKey';
  let key = '';
  try { const m = /[#&]k=([\w-]+)/.exec(location.hash); if (m) { key = m[1]; localStorage.setItem(KEY_LS, key); } else key = localStorage.getItem(KEY_LS) || ''; } catch { /* приватный режим */ }

  let lost = false;
  function banner(text) {
    let b = document.getElementById('phoneBanner');
    if (!text) { if (b) b.remove(); return; }
    if (!b) { b = document.createElement('div'); b.id = 'phoneBanner'; (document.body || document.documentElement).appendChild(b); }
    b.textContent = text;
  }
  function onFail(status, msg) {
    if (status === 401) banner('Телефон не подключён. Откройте на компьютере Orbita → кнопка «Телефон» и отсканируйте QR-код.');
    else banner(msg || (/^100\.|\.ts\.net$/.test(location.hostname) ? 'Нет связи с компьютером. Проверьте: на iPhone включён Tailscale, компьютер включён и Orbita открыта.' : 'Нет связи с компьютером. Orbita на компьютере должна быть открыта, а телефон — в той же Wi-Fi сети.'));
    lost = true;
  }
  function ok() { if (lost) { lost = false; banner(''); } }

  // синхронный вызов — для загрузки и сохранения состояния (программа ждёт ответ сразу)
  function callSync(ch, args) {
    try {
      const x = new XMLHttpRequest();
      x.open('POST', '/api/call', false);
      x.setRequestHeader('Content-Type', 'application/json');
      x.setRequestHeader('X-Orbita-Key', key);
      x.send(JSON.stringify({ ch, args }));
      const r = JSON.parse(x.responseText || '{}');
      if (x.status !== 200 || !r.ok) { onFail(x.status, r.error); return undefined; }
      ok(); return r.r;
    } catch { onFail(0); return undefined; }
  }
  async function call(ch, ...args) {
    let res;
    try {
      res = await fetch('/api/call', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Orbita-Key': key }, body: JSON.stringify({ ch, args }) });
    } catch { onFail(0); throw new Error('нет связи с компьютером'); }
    const r = await res.json().catch(() => ({}));
    if (!res.ok || !r.ok) { onFail(res.status, r.error); throw new Error(r.error || 'ошибка'); }
    ok(); return r.r;
  }
  const onlyPC = () => Promise.resolve({ ok: false, error: 'Это делается на компьютере' });

  const subs = [];
  let ver = 0;
  async function poll() {
    try {
      const r = await fetch('/api/ver', { headers: { 'X-Orbita-Key': key }, cache: 'no-store' });
      if (r.ok) { ok(); const { v } = await r.json(); if (ver && v !== ver) subs.forEach(f => { try { f(); } catch { /* */ } }); ver = v; }
      else onFail(r.status);
    } catch { onFail(0); }
    setTimeout(poll, document.hidden ? 8000 : 2000);
  }
  setTimeout(poll, 1500);

  window.ORBITA_PHONE = true;
  window.orbita = {
    phone: true,
    fetchJSON: url => call('fetch-json', url),
    fetchText: url => call('fetch-text', url),
    loadState: () => callSync('state-load', []),
    saveState: json => { const r = callSync('state-save', [json]); if (r) ver = 0; return r; }, // своё сохранение не считаем «чужим» изменением
    licStatus: () => call('lic-status'),
    licActivate: onlyPC,
    newWindow: onlyPC,
    acctList: () => call('acct-list'),
    acctSave: onlyPC,
    acctDel: onlyPC,
    acctFetch: (ex, w) => call('acct-fetch', ex, w),
    acctOpenTime: (ex, p) => call('acct-opentime', ex, p),
    updCheck: () => call('upd-check'),
    updInstall: () => Promise.resolve({ ok: false, error: 'Обновление ставится на компьютере — телефон получит его автоматически' }),
    onUpdProgress: () => {},
    onStateChanged: cb => subs.push(cb),
  };
  document.documentElement.classList.add('phone');
})();

// выбрали монету в списке — закрываем список, чтобы был виден график
document.addEventListener('click', e => {
  if (!e.target.closest || !e.target.closest('.wl-row, .ac-row')) return;
  setTimeout(() => { try { if (App.isPhone && App.state.settings.sideOpen) { App.state.settings.sideOpen = false; Panels.render(); } } catch { /* */ } }, 60);
}, true);

// iPhone: щипок двумя пальцами — это масштаб графика, а не увеличение всей страницы
['gesturestart', 'gesturechange'].forEach(t => document.addEventListener(t, e => e.preventDefault(), { passive: false }));
let lastEnd = 0; // двойное касание не должно увеличивать страницу
document.addEventListener('touchend', e => { const n = Date.now(); if (n - lastEnd < 300 && e.target.closest && e.target.closest('.cell')) e.preventDefault(); lastEnd = n; }, { passive: false });
