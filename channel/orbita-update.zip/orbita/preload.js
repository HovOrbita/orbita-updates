'use strict';
const { contextBridge, ipcRenderer } = require('electron');

// Запросы к биржам идут через главный процесс: так не мешают ограничения CORS
// и учитываются системные настройки прокси/VPN.
contextBridge.exposeInMainWorld('orbita', {
  fetchJSON: url => ipcRenderer.invoke('fetch-json', url),
  fetchText: url => ipcRenderer.invoke('fetch-text', url),
  loadState: () => ipcRenderer.sendSync('state-load'),
  saveState: json => ipcRenderer.sendSync('state-save', json),
  licStatus: () => ipcRenderer.invoke('lic-status'),
  licActivate: code => ipcRenderer.invoke('lic-activate', code),
  newWindow: () => ipcRenderer.invoke('win-new'),
  acctList: () => ipcRenderer.invoke('acct-list'),
  acctSave: (ex, key, secret) => ipcRenderer.invoke('acct-save', ex, key, secret),
  acctDel: ex => ipcRenderer.invoke('acct-del', ex),
  acctFetch: (ex, withOrders) => ipcRenderer.invoke('acct-fetch', ex, withOrders),
  acctCloseInfo: (ex, q) => ipcRenderer.invoke('acct-closeinfo', ex, q),
  acctOpenTime: (ex, pos) => ipcRenderer.invoke('acct-opentime', ex, pos),
  updCheck: () => ipcRenderer.invoke('upd-check'),
  updInstall: () => ipcRenderer.invoke('upd-install'),
  onUpdProgress: cb => ipcRenderer.on('upd-progress', (_e, d) => cb(d)),
  phoneStatus: ip => ipcRenderer.invoke('phone-status', ip),
  phoneEnable: (on, ip) => ipcRenderer.invoke('phone-enable', on, ip),
  phoneReset: ip => ipcRenderer.invoke('phone-reset', ip),
  remoteConnect: url => ipcRenderer.invoke('remote-connect', url),
  onStateChanged: cb => ipcRenderer.on('state-changed', () => cb()),
});
